package com.example.printxpress.Activity;

import android.app.DatePickerDialog;
import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.Color;
import android.net.Uri;
import android.os.Bundle;
import android.provider.MediaStore;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.RadioGroup;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;

import com.example.printxpress.R;
import com.example.printxpress.models.FrameOrder;
import com.github.dhaval2404.colorpicker.ColorPickerDialog;
import com.github.dhaval2404.colorpicker.model.ColorShape;
import com.google.android.material.chip.Chip;
import com.google.android.material.chip.ChipGroup;
import com.google.android.material.textfield.TextInputLayout;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.storage.FirebaseStorage;
import com.google.firebase.storage.StorageReference;

import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.List;
import java.util.UUID;

public class FrameOrderActivity extends AppCompatActivity {

    private static final String TAG = "FrameOrderActivity";
    private static final int PICK_IMAGE_REQUEST = 1;

    private ImageView ivPreviewFrame, ivUserPhotoPreview, ivUploadedPhoto;
    private TextView tvQuantity, tvTotalPrice;
    private EditText etFrameText, etAddress, etSpecialInstructions, etCustomSize;
    private ChipGroup cgUsage, cgFrameSize, cgFrameType, cgMaterial, cgFrameColor, cgDesignStyle, cgLayout, cgBackground, cgGlassType, cgOrientation, cgPackaging;
    private CheckBox cbUrgent;
    private Button btnUploadPhoto, btnDeadlineDate, btnPlaceOrder;
    private ImageButton btnAdd, btnMinus;
    private RadioGroup rgDelivery;
    private TextInputLayout tilDeliveryAddress, tilCustomSize, tilFrameText;
    private Toolbar toolbar;

    private List<Uri> imageList = new ArrayList<>();
    private List<String> uploadUrls = new ArrayList<>();
    private String deadlineDate = "";
    private int quantity = 1;
    private double currentTotalPrice = 0;
    private int selectedColor = Color.BLACK;
    private int selectedBackgroundColor = Color.WHITE;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_frame_order);

        initViews();
        setupToolbar();
        setupListeners();

        updateTotal();
        updateFramePreview(cgFrameType.getCheckedChipId());
    }

    private void initViews() {
        ivPreviewFrame = findViewById(R.id.ivPreviewFrame);
        ivUserPhotoPreview = findViewById(R.id.ivUserPhotoPreview);
        ivUploadedPhoto = findViewById(R.id.ivUploadedPhoto);

        tvQuantity = findViewById(R.id.tvQuantity);
        tvTotalPrice = findViewById(R.id.tvTotalPrice);
        etFrameText = findViewById(R.id.etFrameText);
        etAddress = findViewById(R.id.etAddress);
        etSpecialInstructions = findViewById(R.id.etSpecialInstructions);
        etCustomSize = findViewById(R.id.etCustomSize);

        cgUsage = findViewById(R.id.cgUsage);
        cgFrameSize = findViewById(R.id.cgFrameSize);
        cgFrameType = findViewById(R.id.cgFrameType);
        cgMaterial = findViewById(R.id.cgMaterial);
        cgFrameColor = findViewById(R.id.cgFrameColor);
        cgDesignStyle = findViewById(R.id.cgDesignStyle);
        cgLayout = findViewById(R.id.cgLayout);
        cgBackground = findViewById(R.id.cgBackground);
        cgGlassType = findViewById(R.id.cgGlassType);
        cgOrientation = findViewById(R.id.cgOrientation);
        cgPackaging = findViewById(R.id.cgPackaging);

        btnAdd = findViewById(R.id.btnAdd);
        btnMinus = findViewById(R.id.btnMinus);
        cbUrgent = findViewById(R.id.cbUrgent);
        btnUploadPhoto = findViewById(R.id.btnUploadPhoto);
        btnDeadlineDate = findViewById(R.id.btnDeadlineDate);
        btnPlaceOrder = findViewById(R.id.btnPlaceOrder);
        rgDelivery = findViewById(R.id.rgDelivery);
        tilDeliveryAddress = findViewById(R.id.tilDeliveryAddress);
        tilCustomSize = findViewById(R.id.tilCustomSize);
        tilFrameText = findViewById(R.id.tilFrameText);
    }

    private void setupToolbar() {
        toolbar = findViewById(R.id.toolbar);
        if (toolbar != null) {
            setSupportActionBar(toolbar);
            if (getSupportActionBar() != null) getSupportActionBar().setDisplayHomeAsUpEnabled(true);
            toolbar.setNavigationOnClickListener(v -> finish());
        }
    }

    private void setupListeners() {
        btnAdd.setOnClickListener(v -> {
            quantity++;
            tvQuantity.setText(String.valueOf(quantity));
            updateTotal();
        });

        btnMinus.setOnClickListener(v -> {
            if (quantity > 1) {
                quantity--;
                tvQuantity.setText(String.valueOf(quantity));
                updateTotal();
            }
        });

        cgFrameType.setOnCheckedChangeListener((group, checkedId) -> {
            updateFramePreview(checkedId);
            updateTotal();
        });

        cgFrameColor.setOnCheckedChangeListener((group, checkedId) -> {
            if (checkedId == R.id.chipCustomColor) {
                showColorPicker();
            } else {
                updateColorValue(checkedId);
            }
            updateTotal();
        });

        cgFrameSize.setOnCheckedChangeListener((group, checkedId) -> {
            tilCustomSize.setVisibility(checkedId == R.id.chipCustomSize ? View.VISIBLE : View.GONE);
            updateTotal();
        });

        cgLayout.setOnCheckedChangeListener((group, checkedId) -> {
            if (checkedId == R.id.chipSideText) {
                tilFrameText.setHint("Enter Side Text (Mandatory)");
            } else {
                tilFrameText.setHint("Name / Date / Quote (Optional)");
            }
            updateTotal();
        });

        cgBackground.setOnCheckedChangeListener((group, checkedId) -> {
            if (checkedId == R.id.chipCustomBG) {
                showBackgroundColorPicker();
            }
            updateTotal();
        });

        ChipGroup.OnCheckedChangeListener priceListener = (group, checkedId) -> updateTotal();
        cgMaterial.setOnCheckedChangeListener(priceListener);
        cgPackaging.setOnCheckedChangeListener(priceListener);
        cgGlassType.setOnCheckedChangeListener(priceListener);

        rgDelivery.setOnCheckedChangeListener((group, checkedId) -> {
            tilDeliveryAddress.setVisibility(checkedId == R.id.rbDelivery ? View.VISIBLE : View.GONE);
            updateTotal();
        });

        btnUploadPhoto.setOnClickListener(v -> chooseImage());
        btnDeadlineDate.setOnClickListener(v -> showDatePicker());
        cbUrgent.setOnCheckedChangeListener((bv, is) -> updateTotal());
        btnPlaceOrder.setOnClickListener(v -> validateAndProceed());
    }

    private void validateAndProceed() {
        boolean isValid = true;

        if (imageList.isEmpty()) {
            Toast.makeText(this, "Please upload at least one photo", Toast.LENGTH_SHORT).show();
            isValid = false;
        }

        if (cgFrameSize.getCheckedChipId() == R.id.chipCustomSize && etCustomSize.getText().toString().trim().isEmpty()) {
            etCustomSize.setError("Please specify custom size");
            isValid = false;
        }

        if (rgDelivery.getCheckedRadioButtonId() == R.id.rbDelivery && etAddress.getText().toString().trim().isEmpty()) {
            etAddress.setError("Delivery address is required");
            isValid = false;
        }

        if (cgLayout.getCheckedChipId() == R.id.chipSideText && etFrameText.getText().toString().trim().isEmpty()) {
            etFrameText.setError("Side text is mandatory for this layout");
            isValid = false;
        }

        if (isValid) {
            uploadData();
        }
    }

    private void updateFramePreview(int checkedId) {
        if (checkedId == R.id.chipWall) {
            ivPreviewFrame.setImageResource(R.drawable.wallframe);
        } else if (checkedId == R.id.chipTable) {
            ivPreviewFrame.setImageResource(R.drawable.table);
        } else if (checkedId == R.id.chipCollage) {
            ivPreviewFrame.setImageResource(R.drawable.collage);
        } else if (checkedId == R.id.chipLED) {
            ivPreviewFrame.setImageResource(R.drawable.led);
        }
    }

    private void showColorPicker() {
        new ColorPickerDialog.Builder(this)
                .setTitle("Choose Frame Color")
                .setColorShape(ColorShape.SQAURE)
                .setDefaultColor(selectedColor)
                .setColorListener((color, colorHex) -> {
                    selectedColor = color;
                    Toast.makeText(this, "Selected color: " + colorHex, Toast.LENGTH_SHORT).show();
                })
                .show();
    }

    private void showBackgroundColorPicker() {
        new ColorPickerDialog.Builder(this)
                .setTitle("Choose Background Color")
                .setColorShape(ColorShape.SQAURE)
                .setDefaultColor(selectedBackgroundColor)
                .setColorListener((color, colorHex) -> {
                    selectedBackgroundColor = color;
                    Toast.makeText(this, "Selected background: " + colorHex, Toast.LENGTH_SHORT).show();
                })
                .show();
    }

    private void updateColorValue(int checkedId) {
        if (checkedId == R.id.chipBlack) selectedColor = Color.BLACK;
        else if (checkedId == R.id.chipWhite) selectedColor = Color.WHITE;
        else if (checkedId == R.id.chipBrown) selectedColor = Color.parseColor("#5D4037");
        else if (checkedId == R.id.chipGoldSilver) selectedColor = Color.parseColor("#FFD700");
    }

    private void updateTotal() {
        double unitPrice = 800.0; 

        String size = getSelectedChipText(cgFrameSize);
        if (size.contains("5x7")) unitPrice += 200;
        else if (size.contains("8x10")) unitPrice += 500;
        else if (size.contains("A4")) unitPrice += 800;

        String material = getSelectedChipText(cgMaterial);
        if (material.contains("Metal")) unitPrice += 1000;
        else if (material.contains("Acrylic")) unitPrice += 1500;

        String type = getSelectedChipText(cgFrameType);
        if (type.contains("LED")) unitPrice += 2000;

        currentTotalPrice = quantity * unitPrice;

        if (rgDelivery.getCheckedRadioButtonId() == R.id.rbDelivery) currentTotalPrice += 250;
        if (cbUrgent.isChecked()) currentTotalPrice += 500;

        tvTotalPrice.setText("Total Amount: Rs " + String.format("%.2f", currentTotalPrice));
    }

    private String getSelectedChipText(ChipGroup chipGroup) {
        int checkedId = chipGroup.getCheckedChipId();
        if (checkedId != View.NO_ID) {
            if (checkedId == R.id.chipCustomSize) {
                return etCustomSize.getText().toString().isEmpty() ? "Custom size" : etCustomSize.getText().toString();
            }
            if (checkedId == R.id.chipCustomBG) {
                return String.format("#%06X", (0xFFFFFF & selectedBackgroundColor));
            }
            Chip chip = findViewById(checkedId);
            return chip.getText().toString();
        }
        return "";
    }

    private void chooseImage() {
        Intent intent = new Intent(Intent.ACTION_GET_CONTENT);
        intent.setType("image/*");
        intent.putExtra(Intent.EXTRA_ALLOW_MULTIPLE, true);
        startActivityForResult(Intent.createChooser(intent, "Select Photo(s)"), PICK_IMAGE_REQUEST);
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == PICK_IMAGE_REQUEST && resultCode == RESULT_OK && data != null) {
            imageList.clear();
            if (data.getClipData() != null) {
                int count = data.getClipData().getItemCount();
                for (int i = 0; i < count; i++) {
                    imageList.add(data.getClipData().getItemAt(i).getUri());
                }
            } else if (data.getData() != null) {
                imageList.add(data.getData());
            }

            if (!imageList.isEmpty()) {
                ivUploadedPhoto.setVisibility(View.VISIBLE);
                ivUploadedPhoto.setImageURI(imageList.get(0)); 
                btnUploadPhoto.setText(imageList.size() + " Photo(s) Selected");
            }
        }
    }

    private void showDatePicker() {
        final Calendar c = Calendar.getInstance();
        new DatePickerDialog(this, (v, y, m, d) -> {
            deadlineDate = d + "/" + (m + 1) + "/" + y;
            btnDeadlineDate.setText("Required By: " + deadlineDate);
        }, c.get(Calendar.YEAR), c.get(Calendar.MONTH), c.get(Calendar.DAY_OF_MONTH)).show();
    }

    private void uploadData() {
        uploadUrls.clear();
        String orderId = UUID.randomUUID().toString();
        Toast.makeText(this, "Processing Order...", Toast.LENGTH_SHORT).show();
        uploadImagesRecursive(0, orderId);
    }

    private void uploadImagesRecursive(int index, String orderId) {
        if (index >= imageList.size()) {
            proceedToPayment(orderId, String.join(",", uploadUrls));
            return;
        }

        Uri uri = imageList.get(index);
        StorageReference sRef = FirebaseStorage.getInstance().getReference("Designs/" + orderId + "_frame_" + index + ".png");

        try {
            Bitmap bitmap = MediaStore.Images.Media.getBitmap(getContentResolver(), uri);
            ByteArrayOutputStream baos = new ByteArrayOutputStream();
            bitmap.compress(Bitmap.CompressFormat.PNG, 100, baos);
            byte[] data = baos.toByteArray();

            sRef.putBytes(data).addOnSuccessListener(taskSnapshot -> sRef.getDownloadUrl().addOnSuccessListener(downloadUri -> {
                uploadUrls.add(downloadUri.toString());
                uploadImagesRecursive(index + 1, orderId);
            })).addOnFailureListener(e -> {
                Log.e(TAG, "Upload failed for image " + index);
                uploadImagesRecursive(index + 1, orderId);
            });
        } catch (IOException e) {
            Log.e(TAG, e.getMessage());
            uploadImagesRecursive(index + 1, orderId);
        }
    }

    private void proceedToPayment(String orderId, String photoUrls) {
        String frameColorText = getSelectedChipText(cgFrameColor);
        if (cgFrameColor.getCheckedChipId() == R.id.chipCustomColor) {
            frameColorText = String.format("#%06X", (0xFFFFFF & selectedColor));
        }

        FrameOrder order = new FrameOrder(
                orderId, FirebaseAuth.getInstance().getUid(), "Photo Frame", quantity,
                getSelectedChipText(cgUsage), getSelectedChipText(cgFrameSize),
                getSelectedChipText(cgFrameType), getSelectedChipText(cgMaterial),
                frameColorText, photoUrls, getSelectedChipText(cgDesignStyle),
                getSelectedChipText(cgLayout), getSelectedChipText(cgBackground),
                etFrameText.getText().toString(), getSelectedChipText(cgGlassType),
                getSelectedChipText(cgOrientation), getSelectedChipText(cgPackaging),
                (rgDelivery.getCheckedRadioButtonId() == R.id.rbPickup ? "Pickup" : "Delivery"),
                etAddress.getText().toString(), deadlineDate, cbUrgent.isChecked(),
                currentTotalPrice, "Pending", System.currentTimeMillis()
        );

        Intent intent = new Intent(this, PaymentBillingActivity.class);
        intent.putExtra("order_data", order);
        startActivity(intent);
    }
}
