package com.example.printxpress.models;

import java.io.Serializable;

public class KeychainOrder implements Serializable, BaseOrder {
    private String orderId;
    private String userId;
    private String productType;
    private String keychainType;
    private String shape;
    private String size;
    private String material;
    private String attachmentType;
    private String printType;
    private String textMessage;
    private String fontStyle;
    private String backgroundColor;
    private String textColor;
    private String photoUrl;
    private int quantity;
    private String usage;
    private String packaging;
    private String deliveryType;
    private String address;
    private String deadline;
    private boolean isUrgent;
    private String specialInstructions;
    private double totalPrice;
    private String status;
    private long timestamp;

    public KeychainOrder() {}

    public KeychainOrder(String orderId, String userId, String productType, String keychainType, String shape, 
                         String size, String material, String attachmentType, String printType, String textMessage, 
                         String fontStyle, String backgroundColor, String textColor, String photoUrl, 
                         int quantity, String usage, String packaging, String deliveryType, String address, 
                         String deadline, boolean isUrgent, String specialInstructions, double totalPrice, 
                         String status, long timestamp) {
        this.orderId = orderId;
        this.userId = userId;
        this.productType = productType;
        this.keychainType = keychainType;
        this.shape = shape;
        this.size = size;
        this.material = material;
        this.attachmentType = attachmentType;
        this.printType = printType;
        this.textMessage = textMessage;
        this.fontStyle = fontStyle;
        this.backgroundColor = backgroundColor;
        this.textColor = textColor;
        this.photoUrl = photoUrl;
        this.quantity = quantity;
        this.usage = usage;
        this.packaging = packaging;
        this.deliveryType = deliveryType;
        this.address = address;
        this.deadline = deadline;
        this.isUrgent = isUrgent;
        this.specialInstructions = specialInstructions;
        this.totalPrice = totalPrice;
        this.status = status;
        this.timestamp = timestamp;
    }

    @Override
    public String getOrderSummary() {
        return "Type: " + keychainType + " | Size: " + size + " | Qty: " + quantity;
    }

    @Override
    public String getBase64Image() {
        return null;
    }

    public String getOrderId() { return orderId; }
    public void setOrderId(String orderId) { this.orderId = orderId; }

    public String getUserId() { return userId; }
    public void setUserId(String userId) { this.userId = userId; }

    public String getProductType() { return productType; }
    public void setProductType(String productType) { this.productType = productType; }

    public String getKeychainType() { return keychainType; }
    public void setKeychainType(String keychainType) { this.keychainType = keychainType; }

    public String getShape() { return shape; }
    public void setShape(String shape) { this.shape = shape; }

    public String getSize() { return size; }
    public void setSize(String size) { this.size = size; }

    public String getMaterial() { return material; }
    public void setMaterial(String material) { this.material = material; }

    public String getAttachmentType() { return attachmentType; }
    public void setAttachmentType(String attachmentType) { this.attachmentType = attachmentType; }

    public String getPrintType() { return printType; }
    public void setPrintType(String printType) { this.printType = printType; }

    public String getTextMessage() { return textMessage; }
    public void setTextMessage(String textMessage) { this.textMessage = textMessage; }

    public String getFontStyle() { return fontStyle; }
    public void setFontStyle(String fontStyle) { this.fontStyle = fontStyle; }

    public String getBackgroundColor() { return backgroundColor; }
    public void setBackgroundColor(String backgroundColor) { this.backgroundColor = backgroundColor; }

    public String getTextColor() { return textColor; }
    public void setTextColor(String textColor) { this.textColor = textColor; }

    public String getPhotoUrl() { return photoUrl; }
    public void setPhotoUrl(String photoUrl) { this.photoUrl = photoUrl; }

    public int getQuantity() { return quantity; }
    public void setQuantity(int quantity) { this.quantity = quantity; }

    public String getUsage() { return usage; }
    public void setUsage(String usage) { this.usage = usage; }

    public String getPackaging() { return packaging; }
    public void setPackaging(String packaging) { this.packaging = packaging; }

    public String getDeliveryType() { return deliveryType; }
    public void setDeliveryType(String deliveryType) { this.deliveryType = deliveryType; }

    public String getAddress() { return address; }
    public void setAddress(String address) { this.address = address; }

    public String getDeadline() { return deadline; }
    public void setDeadline(String deadline) { this.deadline = deadline; }

    public boolean isUrgent() { return isUrgent; }
    public void setUrgent(boolean urgent) { isUrgent = urgent; }

    public String getSpecialInstructions() { return specialInstructions; }
    public void setSpecialInstructions(String specialInstructions) { this.specialInstructions = specialInstructions; }

    public double getTotalPrice() { return totalPrice; }
    public void setTotalPrice(double totalPrice) { this.totalPrice = totalPrice; }

    public String getStatus() { return status; }
    public void setStatus(String status) { this.status = status; }

    public long getTimestamp() { return timestamp; }
    public void setTimestamp(long timestamp) { this.timestamp = timestamp; }
}
