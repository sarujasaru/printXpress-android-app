package com.example.printxpress.Adapter;

import android.graphics.Typeface;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;
import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;
import com.example.printxpress.R;
import java.util.List;

public class FontAdapter extends RecyclerView.Adapter<FontAdapter.FontViewHolder> {

    private final List<FontModel> fontList;
    private final OnFontClickListener listener;
    private int selectedPosition = 0;

    public interface OnFontClickListener {
        void onFontClick(FontModel font);
    }

    public FontAdapter(List<FontModel> fontList, OnFontClickListener listener) {
        this.fontList = fontList;
        this.listener = listener;
    }

    @NonNull
    @Override
    public FontViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.item_font_preview, parent, false);
        return new FontViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull FontViewHolder holder, int position) {
        FontModel font = fontList.get(position);
        holder.tvFontName.setText(font.name);
        holder.tvFontSample.setTypeface(font.typeface);
        
        // Highlight selected item
        holder.itemView.setSelected(selectedPosition == position);
        if (selectedPosition == position) {
            holder.itemView.setBackgroundResource(R.drawable.badge_background); // Assuming this is a nice rounded bg
        } else {
            holder.itemView.setBackground(null);
        }

        holder.itemView.setOnClickListener(v -> {
            int previousSelected = selectedPosition;
            selectedPosition = holder.getAdapterPosition();
            notifyItemChanged(previousSelected);
            notifyItemChanged(selectedPosition);
            listener.onFontClick(font);
        });
    }

    @Override
    public int getItemCount() {
        return fontList.size();
    }

    public static class FontViewHolder extends RecyclerView.ViewHolder {
        TextView tvFontName, tvFontSample;

        public FontViewHolder(@NonNull View itemView) {
            super(itemView);
            tvFontName = itemView.findViewById(R.id.tvFontPreviewName);
            tvFontSample = itemView.findViewById(R.id.tvFontPreviewSample);
        }
    }

    public static class FontModel {
        public String name;
        public Typeface typeface;

        public FontModel(String name, Typeface typeface) {
            this.name = name;
            this.typeface = typeface;
        }
    }
}
