package com.example.printxpress.Activity;

import android.app.DatePickerDialog;
import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.net.Uri;
import android.os.Bundle;
import android.text.Editable;
import android.text.TextWatcher;
import android.util.Base64;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.RadioGroup;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

import androidx.activity.result.ActivityResultLauncher;
import androidx.activity.result.contract.ActivityResultContracts;
import androidx.appcompat.app.AppCompatActivity;

import com.example.printxpress.Firebase.FirebaseHelper;
import com.example.printxpress.R;
import com.example.printxpress.models.BusinessCardOrder;

import java.io.ByteArrayOutputStream;
import java.io.InputStream;
import java.util.Calendar;
import java.util.UUID;

public class BusinessCardOrderActivity extends AppCompatActivity {

    private EditText etFullName, etJobTitle, etCompanyName, etPhone, etEmail, etWebsite, etOfficeAddress, etDeliveryAddress, etDeadline, etLinkedIn, etFacebook, etInstagram, etSpecialInstructions, etQuantity;
    private RadioGroup rgSides, rgAlignment, rgSize, rgShape, rgDelivery;
    private CheckBox cbQrCode, cbUrgent;
    private Spinner spColorTheme, spFontStyle, spDesignStyle, spPaperType, spSpecialFinish;
    private TextView tvPrice;
    private LinearLayout layoutUploadLogo, layoutUploadPhoto;
    private ImageView ivLogoPreview, ivPhotoPreview, ivBack;
    private Button btnOrder;

    private FirebaseHelper firebaseHelper;
    private String logoBase64 = "", photoBase64 = "";
    private double currentTotalPrice = 0;

    private final ActivityResultLauncher<Intent> logoLauncher = registerForActivityResult(new ActivityResultContracts.StartActivityForResult(), result -> handleImageResult(result, ivLogoPreview, 1));
    private final ActivityResultLauncher<Intent> photoLauncher = registerForActivityResult(new ActivityResultContracts.StartActivityForResult(), result -> handleImageResult(result, ivPhotoPreview, 2));

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_business_card_order);

        firebaseHelper = new FirebaseHelper();

        initViews();
        setupSpinners();
        setupPickers();
        setupListeners();
    }

    private void initViews() {
        ivBack = findViewById(R.id.ivBack);
        etFullName = findViewById(R.id.etFullName);
        etJobTitle = findViewById(R.id.etJobTitle);
        etCompanyName = findViewById(R.id.etCompanyName);
        etPhone = findViewById(R.id.etPhone);
        etEmail = findViewById(R.id.etEmail);
        etWebsite = findViewById(R.id.etWebsite);
        etOfficeAddress = findViewById(R.id.etOfficeAddress);
        rgSides = findViewById(R.id.rgSides);
        rgAlignment = findViewById(R.id.rgAlignment);
        cbQrCode = findViewById(R.id.cbQrCode);
        layoutUploadLogo = findViewById(R.id.layoutUploadLogo);
        layoutUploadPhoto = findViewById(R.id.layoutUploadPhoto);
        ivLogoPreview = findViewById(R.id.ivLogoPreview);
        ivPhotoPreview = findViewById(R.id.ivPhotoPreview);
        spColorTheme = findViewById(R.id.spColorTheme);
        spFontStyle = findViewById(R.id.spFontStyle);
        spDesignStyle = findViewById(R.id.spDesignStyle);
        rgSize = findViewById(R.id.rgSize);
        rgShape = findViewById(R.id.rgShape);
        spPaperType = findViewById(R.id.spPaperType);
        spSpecialFinish = findViewById(R.id.spSpecialFinish);
        etQuantity = findViewById(R.id.etQuantity);
        rgDelivery = findViewById(R.id.rgDelivery);
        etDeliveryAddress = findViewById(R.id.etDeliveryAddress);
        etDeadline = findViewById(R.id.etDeadline);
        cbUrgent = findViewById(R.id.cbUrgent);
        etLinkedIn = findViewById(R.id.etLinkedIn);
        etFacebook = findViewById(R.id.etFacebook);
        etInstagram = findViewById(R.id.etInstagram);
        etSpecialInstructions = findViewById(R.id.etSpecialInstructions);
        tvPrice = findViewById(R.id.tvPrice);
        btnOrder = findViewById(R.id.btnOrder);
    }

    private void setupSpinners() {
        String[] colors = {"Light", "Dark", "Custom"};
        ArrayAdapter<String> cAdapter = new ArrayAdapter<>(this, R.layout.spinner_item, colors);
        cAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        spColorTheme.setAdapter(cAdapter);

        String[] fonts = {"Modern", "Classic", "Bold"};
        ArrayAdapter<String> fAdapter = new ArrayAdapter<>(this, R.layout.spinner_item, fonts);
        fAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        spFontStyle.setAdapter(fAdapter);

        String[] styles = {"Minimal", "Creative", "Corporate"};
        ArrayAdapter<String> sAdapter = new ArrayAdapter<>(this, R.layout.spinner_item, styles);
        sAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        spDesignStyle.setAdapter(sAdapter);

        String[] papers = {"Matte", "Glossy", "Textured"};
        ArrayAdapter<String> pAdapter = new ArrayAdapter<>(this, R.layout.spinner_item, papers);
        pAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        spPaperType.setAdapter(pAdapter);

        String[] finishes = {"None", "Lamination", "Emboss", "Spot UV"};
        ArrayAdapter<String> sfAdapter = new ArrayAdapter<>(this, R.layout.spinner_item, finishes);
        sfAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        spSpecialFinish.setAdapter(sfAdapter);
    }

    private void setupPickers() {
        etDeadline.setOnClickListener(v -> {
            Calendar c = Calendar.getInstance();
            new DatePickerDialog(this, (view, year, month, day) -> {
                etDeadline.setText(day + "/" + (month + 1) + "/" + year);
            }, c.get(Calendar.YEAR), c.get(Calendar.MONTH), c.get(Calendar.DAY_OF_MONTH)).show();
        });
    }

    private void setupListeners() {
        ivBack.setOnClickListener(v -> finish());

        rgSides.setOnCheckedChangeListener((group, checkedId) -> calculatePrice());
        rgSize.setOnCheckedChangeListener((group, checkedId) -> calculatePrice());
        rgShape.setOnCheckedChangeListener((group, checkedId) -> calculatePrice());
        
        spPaperType.setOnItemSelectedListener(new android.widget.AdapterView.OnItemSelectedListener() {
            @Override public void onItemSelected(android.widget.AdapterView<?> parent, View view, int position, long id) { calculatePrice(); }
            @Override public void onNothingSelected(android.widget.AdapterView<?> parent) {}
        });
        
        spSpecialFinish.setOnItemSelectedListener(new android.widget.AdapterView.OnItemSelectedListener() {
            @Override public void onItemSelected(android.widget.AdapterView<?> parent, View view, int position, long id) { calculatePrice(); }
            @Override public void onNothingSelected(android.widget.AdapterView<?> parent) {}
        });

        etQuantity.addTextChangedListener(new TextWatcher() {
            @Override public void beforeTextChanged(CharSequence s, int start, int count, int after) {}
            @Override public void onTextChanged(CharSequence s, int start, int before, int count) { calculatePrice(); }
            @Override public void afterTextChanged(Editable s) {}
        });

        cbUrgent.setOnCheckedChangeListener((buttonView, isChecked) -> calculatePrice());

        rgDelivery.setOnCheckedChangeListener((group, checkedId) -> {
            etDeliveryAddress.setVisibility(checkedId == R.id.rbDelivery ? View.VISIBLE : View.GONE);
            calculatePrice();
        });

        layoutUploadLogo.setOnClickListener(v -> openGallery(logoLauncher));
        layoutUploadPhoto.setOnClickListener(v -> openGallery(photoLauncher));

        btnOrder.setOnClickListener(v -> validateAndProceedToPayment());
    }

    private void calculatePrice() {
        double baseRate = 5.0; // Base Price per card in LKR
        
        if (rgSides.getCheckedRadioButtonId() == R.id.rbDoubleSide) baseRate += 3.0;
        if (rgSize.getCheckedRadioButtonId() == R.id.rbSquareSize) baseRate += 2.0;
        if (rgShape.getCheckedRadioButtonId() == R.id.rbRoundedCorners) baseRate += 2.0;
        
        String paper = spPaperType.getSelectedItem().toString();
        if (paper.equals("Glossy")) baseRate += 2.0;
        else if (paper.equals("Textured")) baseRate += 5.0;
        
        String finish = spSpecialFinish.getSelectedItem().toString();
        if (finish.equals("Lamination")) baseRate += 2.0;
        else if (finish.equals("Emboss")) baseRate += 5.0;
        else if (finish.equals("Spot UV")) baseRate += 8.0;

        int qty = 0;
        try {
            String qtyStr = etQuantity.getText().toString().trim();
            if (!qtyStr.isEmpty()) {
                qty = Integer.parseInt(qtyStr);
            }
        } catch (NumberFormatException e) {
            qty = 0;
        }
        
        currentTotalPrice = baseRate * qty;

        if (rgDelivery.getCheckedRadioButtonId() == R.id.rbDelivery) {
            currentTotalPrice += 350;
        }

        if (cbUrgent.isChecked()) {
            currentTotalPrice += 500;
        }
        tvPrice.setText("Estimated Price: Rs " + (int)currentTotalPrice + ".00");
    }

    private void openGallery(ActivityResultLauncher<Intent> launcher) {
        Intent intent = new Intent(Intent.ACTION_PICK);
        intent.setType("image/*");
        launcher.launch(intent);
    }

    private void handleImageResult(androidx.activity.result.ActivityResult result, ImageView preview, int type) {
        if (result.getResultCode() == RESULT_OK && result.getData() != null) {
            Uri uri = result.getData().getData();
            String base64 = encodeImage(uri);
            if (type == 1) logoBase64 = base64;
            else if (type == 2) photoBase64 = base64;
            Toast.makeText(this, "Image selected successfully", Toast.LENGTH_SHORT).show();
        }
    }

    private String encodeImage(Uri uri) {
        try {
            InputStream is = getContentResolver().openInputStream(uri);
            Bitmap bitmap = BitmapFactory.decodeStream(is);
            if (bitmap == null) return "";
            Bitmap scaled = Bitmap.createScaledBitmap(bitmap, 600, (int) (600.0 * bitmap.getHeight() / bitmap.getWidth()), true);
            ByteArrayOutputStream baos = new ByteArrayOutputStream();
            scaled.compress(Bitmap.CompressFormat.JPEG, 70, baos);
            return Base64.encodeToString(baos.toByteArray(), Base64.DEFAULT);
        } catch (Exception e) { return ""; }
    }

    private void validateAndProceedToPayment() {
        String name = etFullName.getText().toString().trim();
        String company = etCompanyName.getText().toString().trim();
        String phone = etPhone.getText().toString().trim();
        String qty = etQuantity.getText().toString().trim();

        if (name.isEmpty() || company.isEmpty() || phone.isEmpty() || qty.isEmpty()) {
            Toast.makeText(this, "Please fill required fields", Toast.LENGTH_SHORT).show();
            return;
        }

        String side = rgSides.getCheckedRadioButtonId() == R.id.rbSingleSide ? "Single Side" : "Double Side";
        String align = "Left";
        int alignId = rgAlignment.getCheckedRadioButtonId();
        if (alignId == R.id.rbCenter) align = "Center";
        else if (alignId == R.id.rbRight) align = "Right";

        String size = rgSize.getCheckedRadioButtonId() == R.id.rbStandardSize ? "Standard" : "Square";
        String shape = rgShape.getCheckedRadioButtonId() == R.id.rbStandardShape ? "Standard" : "Rounded Corners";
        String delivery = rgDelivery.getCheckedRadioButtonId() == R.id.rbPickup ? "Pickup" : "Delivery";

        String userId = firebaseHelper.getCurrentUser() != null ? firebaseHelper.getCurrentUser().getUid() : "anonymous";
        String orderId = UUID.randomUUID().toString();

        BusinessCardOrder order = new BusinessCardOrder(
                orderId, userId, name, etJobTitle.getText().toString().trim(), company,
                phone, etEmail.getText().toString().trim(), etWebsite.getText().toString().trim(),
                etOfficeAddress.getText().toString().trim(), side, align, cbQrCode.isChecked(),
                logoBase64, photoBase64, spColorTheme.getSelectedItem().toString(),
                spFontStyle.getSelectedItem().toString(), spDesignStyle.getSelectedItem().toString(),
                size, shape, spPaperType.getSelectedItem().toString(),
                spSpecialFinish.getSelectedItem().toString(), qty,
                delivery, etDeliveryAddress.getText().toString().trim(),
                etDeadline.getText().toString(), cbUrgent.isChecked(),
                etLinkedIn.getText().toString().trim(), etFacebook.getText().toString().trim(),
                etInstagram.getText().toString().trim(), etSpecialInstructions.getText().toString().trim(),
                System.currentTimeMillis(), currentTotalPrice, "Pending"
        );

        Intent intent = new Intent(this, PaymentBillingActivity.class);
        intent.putExtra("order_data", order);
        startActivity(intent);
    }
}
