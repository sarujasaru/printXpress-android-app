package com.example.printxpress.Adapter;

import android.graphics.Color;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.example.printxpress.R;
import com.example.printxpress.models.Order;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;
import java.util.Locale;

public class OrderAdapter extends RecyclerView.Adapter<OrderAdapter.OrderViewHolder> {

    private List<Order> orderList;

    public OrderAdapter(List<Order> orderList) {
        this.orderList = orderList;
    }

    @NonNull
    @Override
    public OrderViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.item_order, parent, false);
        return new OrderViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull OrderViewHolder holder, int position) {
        Order order = orderList.get(position);
        
        // Displaying product details
        holder.tvProductName.setText(order.getDisplayName());
        holder.tvOrderSummary.setText(order.getDisplaySummary());
        holder.tvQuantity.setText(order.getDisplayQuantity());
        holder.tvTotalPrice.setText(String.format(Locale.getDefault(), "Rs %.2f", order.getTotalPrice()));

        // Order ID display
        holder.tvOrderId.setText("ID: #" + order.getOrderId());

        // Address display logic
        String fullAddress = order.getDisplayAddress();
        if (fullAddress != null && !fullAddress.isEmpty()) {
            holder.tvAddress.setText(fullAddress);
            holder.layoutAddress.setVisibility(View.VISIBLE);
        } else {
            holder.layoutAddress.setVisibility(View.GONE);
        }
        
        // Status display logic: Red text, No background
        String status = order.getStatus();
        if (status == null || status.isEmpty()) status = "Pending";
        holder.tvStatus.setText(status);
        
        if (status.equalsIgnoreCase("Confirmed")) {
            holder.tvStatus.setTextColor(Color.RED);
        } else {
            holder.tvStatus.setTextColor(Color.parseColor("#F59E0B")); // Orange for Pending
        }
        holder.tvStatus.setBackground(null);
        holder.tvStatus.setPadding(0, 0, 0, 0);

        // Date formatting: converting timestamp to readable date
        String dateStr = order.getOrderDate();
        if (dateStr == null || dateStr.isEmpty()) {
            if (order.getTimestamp() > 0) {
                SimpleDateFormat sdf = new SimpleDateFormat("dd MMM yyyy, HH:mm", Locale.getDefault());
                dateStr = sdf.format(new Date(order.getTimestamp()));
            } else {
                dateStr = "N/A";
            }
        }
        holder.tvOrderDate.setText(dateStr);
    }

    @Override
    public int getItemCount() {
        return orderList.size();
    }

    public static class OrderViewHolder extends RecyclerView.ViewHolder {
        TextView tvProductName, tvOrderSummary, tvQuantity, tvTotalPrice, tvOrderDate, tvStatus, tvOrderId, tvAddress;
        View layoutAddress;

        public OrderViewHolder(@NonNull View itemView) {
            super(itemView);
            tvProductName = itemView.findViewById(R.id.tvProductName);
            tvOrderSummary = itemView.findViewById(R.id.tvOrderSummary);
            tvQuantity = itemView.findViewById(R.id.tvQuantity);
            tvTotalPrice = itemView.findViewById(R.id.tvTotalPrice);
            tvOrderDate = itemView.findViewById(R.id.tvOrderDate);
            tvStatus = itemView.findViewById(R.id.tvStatus);
            tvOrderId = itemView.findViewById(R.id.tvOrderId);
            tvAddress = itemView.findViewById(R.id.tvAddress);
            layoutAddress = itemView.findViewById(R.id.layoutAddress);
        }
    }
}
