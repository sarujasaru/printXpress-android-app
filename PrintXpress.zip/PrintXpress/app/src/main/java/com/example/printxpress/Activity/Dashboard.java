package com.example.printxpress.Activity;

import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;
import android.view.ContextThemeWrapper;
import android.view.View;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.PopupMenu;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.cardview.widget.CardView;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;
import androidx.viewpager2.widget.ViewPager2;

import com.example.printxpress.Adapter.OfferAdapter;
import com.example.printxpress.Firebase.FirebaseHelper;
import com.example.printxpress.R;
import com.example.printxpress.models.Notification;
import com.example.printxpress.models.Offer;
import com.example.printxpress.models.User;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.ValueEventListener;

import java.util.ArrayList;
import java.util.List;

public class Dashboard extends AppCompatActivity {

    private TextView tvWelcome, tvNotificationBadge;
    private ImageView btnMenu;
    private FrameLayout btnNotification;
    private ViewPager2 offerSlider;
    private CardView cardPosters, cardBanners, cardBusinessCard, cardFlyers, cardStickers, cardCustomized;
    private FirebaseHelper firebaseHelper;
    private List<Offer> offerList;
    private OfferAdapter offerAdapter;
    private Handler sliderHandler = new Handler();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_dashboard);
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });

        tvWelcome = findViewById(R.id.tvWelcome);
        tvNotificationBadge = findViewById(R.id.tvNotificationBadge);
        btnMenu = findViewById(R.id.btnMenu);
        btnNotification = findViewById(R.id.btnNotification);
        offerSlider = findViewById(R.id.offerSlider);
        cardPosters = findViewById(R.id.cardPosters);
        cardBanners = findViewById(R.id.cardBanners);
        cardBusinessCard = findViewById(R.id.cardBusinessCard);
        cardFlyers = findViewById(R.id.cardFlyers);
        cardStickers = findViewById(R.id.cardStickers);
        cardCustomized = findViewById(R.id.cardCustomized);

        firebaseHelper = new FirebaseHelper();
        offerList = new ArrayList<>();
        offerAdapter = new OfferAdapter(offerList);
        offerSlider.setAdapter(offerAdapter);

        loadUserData();
        loadOffers();
        loadNotificationCount();

        btnMenu.setOnClickListener(v -> showPopupMenu());
        btnNotification.setOnClickListener(v -> {
            startActivity(new Intent(Dashboard.this, NotificationsActivity.class));
        });

        cardPosters.setOnClickListener(v -> {
            startActivity(new Intent(Dashboard.this, PosterOrderActivity.class));
        });

        cardBanners.setOnClickListener(v -> {
            startActivity(new Intent(Dashboard.this, BannerOrderActivity.class));
        });

        cardBusinessCard.setOnClickListener(v -> {
            startActivity(new Intent(Dashboard.this, BusinessCardOrderActivity.class));
        });

        cardFlyers.setOnClickListener(v -> {
            startActivity(new Intent(Dashboard.this, FlyerOrderActivity.class));
        });

        cardStickers.setOnClickListener(v -> {
            startActivity(new Intent(Dashboard.this, StickerOrderActivity.class));
        });

        cardCustomized.setOnClickListener(v -> {
            startActivity(new Intent(Dashboard.this, CustomizedSelectionActivity.class));
        });
    }

    private void loadNotificationCount() {
        if (firebaseHelper.getCurrentUser() == null) return;
        
        String currentUserId = firebaseHelper.getCurrentUser().getUid();
        firebaseHelper.getNotificationsReference().addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot snapshot) {
                int unreadCount = 0;
                for (DataSnapshot dataSnapshot : snapshot.getChildren()) {
                    Notification notification = dataSnapshot.getValue(Notification.class);
                    if (notification != null) {
                        boolean isForMe = "ALL".equals(notification.getUid()) || currentUserId.equals(notification.getUid());
                        if (isForMe && !notification.isRead()) {
                            unreadCount++;
                        }
                    }
                }
                
                if (unreadCount > 0) {
                    tvNotificationBadge.setVisibility(View.VISIBLE);
                    tvNotificationBadge.setText(String.valueOf(unreadCount));
                } else {
                    tvNotificationBadge.setVisibility(View.GONE);
                }
            }

            @Override
            public void onCancelled(@NonNull DatabaseError error) {}
        });
    }

    private void loadOffers() {
        firebaseHelper.getOffersReference().addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot snapshot) {
                int oldSize = offerList.size();
                offerList.clear();
                for (DataSnapshot data : snapshot.getChildren()) {
                    Offer offer = data.getValue(Offer.class);
                    if (offer != null) {
                        offerList.add(offer);
                    }
                }
                offerAdapter.notifyDataSetChanged();
                
                if (!offerList.isEmpty() && oldSize == 0) {
                    offerSlider.setCurrentItem(offerList.size() * 100, false);
                    startAutoSlider();
                }
            }

            @Override
            public void onCancelled(@NonNull DatabaseError error) {
                Toast.makeText(Dashboard.this, "Failed to load offers", Toast.LENGTH_SHORT).show();
            }
        });
    }

    private void startAutoSlider() {
        sliderHandler.removeCallbacks(sliderRunnable);
        sliderHandler.postDelayed(sliderRunnable, 4000); // 4 seconds
    }

    private Runnable sliderRunnable = new Runnable() {
        @Override
        public void run() {
            if (!offerList.isEmpty()) {
                offerSlider.setCurrentItem(offerSlider.getCurrentItem() + 1);
                sliderHandler.postDelayed(this, 4000); // 4 seconds
            }
        }
    };

    @Override
    protected void onPause() {
        super.onPause();
        sliderHandler.removeCallbacks(sliderRunnable);
    }

    @Override
    protected void onResume() {
        super.onResume();
        if (!offerList.isEmpty()) {
            startAutoSlider();
        }
        loadNotificationCount();
    }

    private void showPopupMenu() {
        ContextThemeWrapper wrapper = new ContextThemeWrapper(this, R.style.CustomPopupMenu);
        PopupMenu popupMenu = new PopupMenu(wrapper, btnMenu);
        popupMenu.getMenuInflater().inflate(R.menu.dashboard_menu, popupMenu.getMenu());

        popupMenu.setOnMenuItemClickListener(item -> {
            int itemId = item.getItemId();
            if (itemId == R.id.menu_profile) {
                startActivity(new Intent(Dashboard.this, ProfileActivity.class));
                return true;
            } else if (itemId == R.id.menu_history) {
                startActivity(new Intent(Dashboard.this, OrderHistoryActivity.class));
                return true;
            } else if (itemId == R.id.menu_view_book) {
                startActivity(new Intent(Dashboard.this, ViewBookActivity.class));
                return true;
            } else if (itemId == R.id.menu_public_form) {
                startActivity(new Intent(Dashboard.this, PublicFormActivity.class));
                return true;
            }
            return false;
        });

        popupMenu.show();
    }

    private void loadUserData() {
        if (firebaseHelper.getCurrentUser() != null) {
            String uid = firebaseHelper.getCurrentUser().getUid();
            firebaseHelper.getUserReference(uid).addValueEventListener(new ValueEventListener() {
                @Override
                public void onDataChange(@NonNull DataSnapshot snapshot) {
                    if (snapshot.exists()) {
                        User user = snapshot.getValue(User.class);
                        if (user != null) {
                            tvWelcome.setText("Welcome, " + user.getUsername() + "!");
                        }
                    }
                }

                @Override
                public void onCancelled(@NonNull DatabaseError error) {
                    Toast.makeText(Dashboard.this, "Failed to load user data", Toast.LENGTH_SHORT).show();
                }
            });
        }
    }
}
