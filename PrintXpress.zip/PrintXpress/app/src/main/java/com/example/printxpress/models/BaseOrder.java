package com.example.printxpress.models;

import java.io.Serializable;

public interface BaseOrder extends Serializable {
    String getOrderId();
    void setOrderId(String orderId);
    String getUserId();
    void setUserId(String userId);
    double getTotalPrice();
    void setTotalPrice(double totalPrice);
    String getStatus();
    void setStatus(String status);
    String getAddress();
    void setAddress(String address);
    String getProductType();
    String getOrderSummary();
    String getPhotoUrl();
    String getBase64Image();
}
