package com.example.printxpress.Activity;

import android.os.Bundle;
import android.view.View;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.example.printxpress.Adapter.NotificationAdapter;
import com.example.printxpress.Firebase.FirebaseHelper;
import com.example.printxpress.R;
import com.example.printxpress.models.Comment;
import com.example.printxpress.models.Notification;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.Query;
import com.google.firebase.database.ValueEventListener;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

public class NotificationsActivity extends AppCompatActivity {

    private RecyclerView rvNotifications;
    private NotificationAdapter adapter;
    private List<Notification> notificationList;
    private FirebaseHelper firebaseHelper;
    private ImageView btnBack;
    private TextView tvNoNotifications;
    private ValueEventListener notificationListener;
    private Query notificationsQuery;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_notifications);

        rvNotifications = findViewById(R.id.rvNotifications);
        btnBack = findViewById(R.id.btnBack);
        tvNoNotifications = findViewById(R.id.tvNoNotifications);

        firebaseHelper = new FirebaseHelper();
        notificationList = new ArrayList<>();
        
        rvNotifications.setLayoutManager(new LinearLayoutManager(this));
        adapter = new NotificationAdapter(notificationList);
        rvNotifications.setAdapter(adapter);

        btnBack.setOnClickListener(v -> finish());

        loadAllNotifications();
    }

    private void loadAllNotifications() {
        if (firebaseHelper.getCurrentUser() == null) return;
        
        String currentUserId = firebaseHelper.getCurrentUser().getUid();
        notificationsQuery = firebaseHelper.getNotificationsReference();

        notificationListener = new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot notifSnapshot) {
                loadCommentReplies(notifSnapshot, currentUserId);
            }

            @Override
            public void onCancelled(@NonNull DatabaseError error) {
                if (!isFinishing()) {
                    Toast.makeText(NotificationsActivity.this, "Failed to load notifications", Toast.LENGTH_SHORT).show();
                }
            }
        };
        
        notificationsQuery.addValueEventListener(notificationListener);
    }

    private void markNotificationsAsRead(DataSnapshot snapshot, String currentUserId) {
        DatabaseReference notifRef = FirebaseDatabase.getInstance().getReference("Notification");
        for (DataSnapshot data : snapshot.getChildren()) {
            Notification notification = data.getValue(Notification.class);
            if (notification != null) {
                String notifId = (notification.getId() != null && !notification.getId().isEmpty()) 
                        ? notification.getId() : data.getKey();
                
                if (notifId != null && !notification.isRead()) {
                    if ("ALL".equals(notification.getUid()) || currentUserId.equals(notification.getUid())) {
                        notifRef.child(notifId).child("read").setValue(true);
                    }
                }
            }
        }
    }

    private void loadCommentReplies(DataSnapshot notifSnapshot, String currentUserId) {
        FirebaseDatabase.getInstance().getReference().child("Comments")
                .orderByChild("userId").equalTo(currentUserId)
                .addListenerForSingleValueEvent(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot commentSnapshot) {
                notificationList.clear();

                // 1. Add General Notifications
                for (DataSnapshot data : notifSnapshot.getChildren()) {
                    Notification notification = data.getValue(Notification.class);
                    if (notification != null) {
                        if ("ALL".equals(notification.getUid()) || currentUserId.equals(notification.getUid())) {
                            notificationList.add(notification);
                        }
                    }
                }

                // 2. Add Comment Replies
                for (DataSnapshot data : commentSnapshot.getChildren()) {
                    Comment comment = data.getValue(Comment.class);
                    if (comment != null && comment.getAdminReply() != null && !comment.getAdminReply().isEmpty()) {
                        Notification replyNotif = new Notification(
                                comment.getCommentId(),
                                "Admin Replied to your Comment",
                                "Reply: " + comment.getAdminReply(),
                                comment.getReplyTimestamp() > 0 ? comment.getReplyTimestamp() : comment.getTimestamp(),
                                "ADMIN",
                                currentUserId
                        );
                        replyNotif.setRead(true);
                        notificationList.add(replyNotif);
                    }
                }

                // Mark as read only when active
                markNotificationsAsRead(notifSnapshot, currentUserId);
                updateUI();
            }

            @Override
            public void onCancelled(@NonNull DatabaseError error) {}
        });
    }

    private void updateUI() {
        Collections.sort(notificationList, (n1, n2) -> Long.compare(n2.getTimestamp(), n1.getTimestamp()));
        if (notificationList.isEmpty()) {
            tvNoNotifications.setVisibility(View.VISIBLE);
        } else {
            tvNoNotifications.setVisibility(View.GONE);
        }
        adapter.notifyDataSetChanged();
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        if (notificationsQuery != null && notificationListener != null) {
            notificationsQuery.removeEventListener(notificationListener);
        }
    }
}
