package com.example.printxpress.Activity;

import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.example.printxpress.Adapter.OrderAdapter;
import com.example.printxpress.Firebase.FirebaseHelper;
import com.example.printxpress.R;
import com.example.printxpress.models.Order;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.ValueEventListener;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

public class ViewBookActivity extends AppCompatActivity {

    private static final String TAG = "ViewBookActivity";
    private RecyclerView rvBookings;
    private OrderAdapter orderAdapter;
    private List<Order> activeOrdersList;
    private FirebaseHelper firebaseHelper;
    private LinearLayout layoutNoBookings;
    private ImageView btnBack;
    private TextView tvNoData;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_view_book);

        initViews();

        firebaseHelper = new FirebaseHelper();
        activeOrdersList = new ArrayList<>();
        orderAdapter = new OrderAdapter(activeOrdersList);

        rvBookings.setLayoutManager(new LinearLayoutManager(this));
        rvBookings.setAdapter(orderAdapter);

        btnBack.setOnClickListener(v -> finish());

        loadActiveOrders();
    }

    private void initViews() {
        rvBookings = findViewById(R.id.rvBookings);
        layoutNoBookings = findViewById(R.id.layoutNoBookings);
        btnBack = findViewById(R.id.btnBack);
        tvNoData = findViewById(R.id.tvNoData);
    }

    private void loadActiveOrders() {
        if (firebaseHelper.getCurrentUser() != null) {
            String uid = firebaseHelper.getCurrentUser().getUid();
            
            // Now fetching from "Orders" node instead of "Bookings"
            firebaseHelper.getOrdersReference(uid).addValueEventListener(new ValueEventListener() {
                @Override
                public void onDataChange(@NonNull DataSnapshot snapshot) {
                    activeOrdersList.clear();
                    Log.d(TAG, "Total orders found in DB: " + snapshot.getChildrenCount());

                    for (DataSnapshot dataSnapshot : snapshot.getChildren()) {
                        try {
                            Order order = dataSnapshot.getValue(Order.class);
                            if (order != null) {
                                // Ensure order ID is present
                                if (order.getOrderId() == null) {
                                    order.setOrderId(dataSnapshot.getKey());
                                }
                                
                                String status = order.getStatus();
                                // Filtering: Show Confirmed, Pending, or even if status is not set yet
                                if (status == null || status.isEmpty() || 
                                    status.equalsIgnoreCase("Confirmed") || 
                                    status.equalsIgnoreCase("Pending")) {
                                    activeOrdersList.add(order);
                                }
                            }
                        } catch (Exception e) {
                            Log.e(TAG, "Error parsing order: " + e.getMessage());
                        }
                    }
                    
                    // Sort to show latest orders first
                    Collections.sort(activeOrdersList, (o1, o2) -> Long.compare(o2.getTimestamp(), o1.getTimestamp()));
                    
                    if (activeOrdersList.isEmpty()) {
                        layoutNoBookings.setVisibility(View.VISIBLE);
                        if (tvNoData != null) tvNoData.setText("No active bookings found");
                        rvBookings.setVisibility(View.GONE);
                    } else {
                        layoutNoBookings.setVisibility(View.GONE);
                        rvBookings.setVisibility(View.VISIBLE);
                    }
                    orderAdapter.notifyDataSetChanged();
                }

                @Override
                public void onCancelled(@NonNull DatabaseError error) {
                    Toast.makeText(ViewBookActivity.this, "Failed to load active orders", Toast.LENGTH_SHORT).show();
                }
            });
        } else {
            Toast.makeText(this, "Please login first", Toast.LENGTH_SHORT).show();
        }
    }
}
