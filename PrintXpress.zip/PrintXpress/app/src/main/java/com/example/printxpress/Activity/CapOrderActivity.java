package com.example.printxpress.Activity;

import android.app.DatePickerDialog;
import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.graphics.Color;
import android.net.Uri;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.FrameLayout;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.RadioGroup;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;

import com.example.printxpress.R;
import com.example.printxpress.models.CapOrder;
import com.github.dhaval2404.colorpicker.ColorPickerDialog;
import com.github.dhaval2404.colorpicker.model.ColorShape;
import com.google.android.material.chip.Chip;
import com.google.android.material.chip.ChipGroup;
import com.google.android.material.textfield.TextInputLayout;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.storage.FirebaseStorage;
import com.google.firebase.storage.StorageReference;

import java.io.ByteArrayOutputStream;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.List;
import java.util.UUID;

public class CapOrderActivity extends AppCompatActivity {

    private static final String TAG = "CapOrderActivity";
    private static final int PICK_IMAGE_REQUEST = 1;

    private ImageView ivPreviewCap, ivUserLogoPreview, ivUploadedLogo;
    private TextView tvQuantity, tvTotalPrice;
    private EditText etPrintText, etAddress, etSpecialInstructions;
    private ChipGroup cgUsage, cgCapType, cgCapSize, cgCapColor, cgPrintType, cgPlacement, cgDesignSize, cgPeakStyle, cgClosure, cgPackaging;
    private CheckBox cbUrgent;
    private Button btnUploadLogo, btnDeadlineDate, btnPlaceOrder;
    private ImageButton btnAdd, btnMinus;
    private RadioGroup rgDelivery;
    private TextInputLayout tilDeliveryAddress;
    private FrameLayout previewLayoutContainer;
    private Toolbar toolbar;

    private Uri filePath;
    private String deadlineDate = "";
    private int quantity = 1;
    private double currentTotalPrice = 0;
    private int selectedColor = Color.BLACK;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_cap_order);

        initViews();
        setupToolbar();
        setupListeners();

        updateTotal();
        updateCapPreview(cgCapType.getCheckedChipId());
    }

    private void initViews() {
        previewLayoutContainer = findViewById(R.id.previewLayoutContainer);
        ivPreviewCap = findViewById(R.id.ivPreviewCap);
        ivUserLogoPreview = findViewById(R.id.ivUserLogoPreview);
        ivUploadedLogo = findViewById(R.id.ivUploadedLogo);

        tvQuantity = findViewById(R.id.tvQuantity);
        tvTotalPrice = findViewById(R.id.tvTotalPrice);
        etPrintText = findViewById(R.id.etPrintText);
        etAddress = findViewById(R.id.etAddress);
        etSpecialInstructions = findViewById(R.id.etSpecialInstructions);

        cgUsage = findViewById(R.id.cgUsage);
        cgCapType = findViewById(R.id.cgCapType);
        cgCapSize = findViewById(R.id.cgCapSize);
        cgCapColor = findViewById(R.id.cgCapColor);
        cgPrintType = findViewById(R.id.cgPrintType);
        cgPlacement = findViewById(R.id.cgPlacement);
        cgDesignSize = findViewById(R.id.cgDesignSize);
        cgPeakStyle = findViewById(R.id.cgPeakStyle);
        cgClosure = findViewById(R.id.cgClosure);
        cgPackaging = findViewById(R.id.cgPackaging);

        btnAdd = findViewById(R.id.btnAdd);
        btnMinus = findViewById(R.id.btnMinus);
        cbUrgent = findViewById(R.id.cbUrgent);
        btnUploadLogo = findViewById(R.id.btnUploadLogo);
        btnDeadlineDate = findViewById(R.id.btnDeadlineDate);
        btnPlaceOrder = findViewById(R.id.btnPlaceOrder);
        rgDelivery = findViewById(R.id.rgDelivery);
        tilDeliveryAddress = findViewById(R.id.tilDeliveryAddress);
    }

    private void setupToolbar() {
        toolbar = findViewById(R.id.toolbar);
        if (toolbar != null) {
            setSupportActionBar(toolbar);
            if (getSupportActionBar() != null) getSupportActionBar().setDisplayHomeAsUpEnabled(true);
            toolbar.setNavigationOnClickListener(v -> finish());
        }
    }

    private void setupListeners() {
        btnAdd.setOnClickListener(v -> {
            quantity++;
            tvQuantity.setText(String.valueOf(quantity));
            updateTotal();
        });

        btnMinus.setOnClickListener(v -> {
            if (quantity > 1) {
                quantity--;
                tvQuantity.setText(String.valueOf(quantity));
                updateTotal();
            }
        });

        cgCapType.setOnCheckedChangeListener((group, checkedId) -> {
            updateCapPreview(checkedId);
            updateTotal();
        });

        cgCapColor.setOnCheckedChangeListener((group, checkedId) -> {
            if (checkedId == R.id.chipCustomColor) {
                showColorPicker();
            } else {
                updateColorValue(checkedId);
            }
            updateTotal();
        });

        ChipGroup.OnCheckedChangeListener priceListener = (group, checkedId) -> updateTotal();
        cgCapSize.setOnCheckedChangeListener(priceListener);
        cgPrintType.setOnCheckedChangeListener(priceListener);
        cgDesignSize.setOnCheckedChangeListener(priceListener);
        cgPackaging.setOnCheckedChangeListener(priceListener);

        rgDelivery.setOnCheckedChangeListener((group, checkedId) -> {
            tilDeliveryAddress.setVisibility(checkedId == R.id.rbDelivery ? View.VISIBLE : View.GONE);
            updateTotal();
        });

        btnUploadLogo.setOnClickListener(v -> chooseImage());
        btnDeadlineDate.setOnClickListener(v -> showDatePicker());
        cbUrgent.setOnCheckedChangeListener((bv, is) -> updateTotal());
        btnPlaceOrder.setOnClickListener(v -> validateAndProceedToPayment());
    }

    private void showColorPicker() {
        new ColorPickerDialog.Builder(this)
                .setTitle("Choose Cap Color")
                .setColorShape(ColorShape.SQAURE)
                .setDefaultColor(selectedColor)
                .setColorListener((color, colorHex) -> {
                    selectedColor = color;
                    Toast.makeText(this, "Selected color: " + colorHex, Toast.LENGTH_SHORT).show();
                })
                .show();
    }

    private void updateColorValue(int checkedId) {
        if (checkedId == R.id.chipBlack) {
            selectedColor = Color.BLACK;
        } else if (checkedId == R.id.chipWhite) {
            selectedColor = Color.WHITE;
        } else if (checkedId == R.id.chipRed) {
            selectedColor = Color.RED;
        } else if (checkedId == R.id.chipBlue) {
            selectedColor = Color.BLUE;
        }
    }

    private void updateCapPreview(int checkedId) {
        if (checkedId == R.id.chipBaseball) {
            ivPreviewCap.setImageResource(R.drawable.baseball);
        } else if (checkedId == R.id.chipSnapback) {
            ivPreviewCap.setImageResource(R.drawable.sanapcap);
        } else if (checkedId == R.id.chipTrucker) {
            ivPreviewCap.setImageResource(R.drawable.trackercap);
        } else if (checkedId == R.id.chipDad) {
            ivPreviewCap.setImageResource(R.drawable.dadcap);
        } else if (checkedId == R.id.chipSports) {
            ivPreviewCap.setImageResource(R.drawable.sportscap);
        }
    }

    private void updateTotal() {
        double unitPrice = 450.0; // Base Price

        String capType = getSelectedChipText(cgCapType);
        if (capType.contains("Snapback")) unitPrice += 150;
        else if (capType.contains("Trucker")) unitPrice += 100;

        String pack = getSelectedChipText(cgPackaging);
        if (pack.contains("Premium")) unitPrice += 100;

        currentTotalPrice = quantity * unitPrice;

        if (rgDelivery.getCheckedRadioButtonId() == R.id.rbDelivery) currentTotalPrice += 200;
        if (cbUrgent.isChecked()) currentTotalPrice += 300;

        tvTotalPrice.setText("Estimated Price: Rs " + String.format("%.2f", currentTotalPrice));
    }

    private void chooseImage() {
        Intent intent = new Intent(Intent.ACTION_GET_CONTENT);
        intent.setType("image/*");
        startActivityForResult(Intent.createChooser(intent, "Select Logo"), PICK_IMAGE_REQUEST);
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == PICK_IMAGE_REQUEST && resultCode == RESULT_OK && data != null && data.getData() != null) {
            filePath = data.getData();
            Toast.makeText(this, "Logo selected successfully!", Toast.LENGTH_SHORT).show();
        }
    }

    private void showDatePicker() {
        final Calendar c = Calendar.getInstance();
        new DatePickerDialog(this, (v, y, m, d) -> {
            deadlineDate = d + "/" + (m + 1) + "/" + y;
            btnDeadlineDate.setText(deadlineDate);
        }, c.get(Calendar.YEAR), c.get(Calendar.MONTH), c.get(Calendar.DAY_OF_MONTH)).show();
    }

    private void validateAndProceedToPayment() {
        if (rgDelivery.getCheckedRadioButtonId() == R.id.rbDelivery && etAddress.getText().toString().isEmpty()) {
            Toast.makeText(this, "Enter delivery address", Toast.LENGTH_SHORT).show();
            return;
        }
        uploadData();
    }

    private void uploadData() {
        String orderId = UUID.randomUUID().toString();

        List<String> placements = new ArrayList<>();
        for (int i = 0; i < cgPlacement.getChildCount(); i++) {
            Chip chip = (Chip) cgPlacement.getChildAt(i);
            if (chip.isChecked()) placements.add(chip.getText().toString());
        }

        String capColor = getSelectedChipText(cgCapColor);
        if (cgCapColor.getCheckedChipId() == R.id.chipCustomColor) {
            capColor = String.format("#%06X", (0xFFFFFF & selectedColor));
        }

        CapOrder order = new CapOrder(
                orderId, FirebaseAuth.getInstance().getUid(), "Cap", quantity,
                getSelectedChipText(cgUsage), getSelectedChipText(cgCapType), getSelectedChipText(cgCapSize),
                capColor, etPrintText.getText().toString(),
                getSelectedChipText(cgPrintType), placements, getSelectedChipText(cgDesignSize),
                getSelectedChipText(cgPeakStyle), getSelectedChipText(cgClosure),
                getSelectedChipText(cgPackaging),
                (rgDelivery.getCheckedRadioButtonId() == R.id.rbPickup) ? "Pickup" : "Delivery",
                etAddress.getText().toString(), deadlineDate, cbUrgent.isChecked(),
                etSpecialInstructions.getText().toString(), "Pending", System.currentTimeMillis()
        );
        order.setTotalPrice(currentTotalPrice);

        Bitmap finalBitmap = getBitmapFromView(previewLayoutContainer);
        ByteArrayOutputStream baos = new ByteArrayOutputStream();
        finalBitmap.compress(Bitmap.CompressFormat.PNG, 100, baos);
        byte[] data = baos.toByteArray();

        StorageReference sRef = FirebaseStorage.getInstance().getReference("Designs/" + orderId + "_cap.png");
        sRef.putBytes(data).addOnSuccessListener(taskSnapshot -> sRef.getDownloadUrl().addOnSuccessListener(uri -> {
            order.setLogoUrl(uri.toString());
            proceedToPayment(order);
        })).addOnFailureListener(e -> proceedToPayment(order));
    }

    private void proceedToPayment(CapOrder order) {
        Intent intent = new Intent(this, PaymentBillingActivity.class);
        intent.putExtra("order_data", order);
        startActivity(intent);
    }

    private String getSelectedChipText(ChipGroup cg) {
        int id = cg.getCheckedChipId();
        return (id != View.NO_ID) ? ((Chip) findViewById(id)).getText().toString() : "";
    }

    private Bitmap getBitmapFromView(View view) {
        Bitmap bitmap = Bitmap.createBitmap(view.getWidth(), view.getHeight(), Bitmap.Config.ARGB_8888);
        Canvas canvas = new Canvas(bitmap);
        view.draw(canvas);
        return bitmap;
    }
}
