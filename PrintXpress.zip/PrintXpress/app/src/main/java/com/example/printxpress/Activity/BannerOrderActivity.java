package com.example.printxpress.Activity;

import android.app.DatePickerDialog;
import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.net.Uri;
import android.os.Bundle;
import android.text.Editable;
import android.text.TextWatcher;
import android.util.Base64;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.RadioGroup;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

import androidx.activity.result.ActivityResultLauncher;
import androidx.activity.result.contract.ActivityResultContracts;
import androidx.appcompat.app.AppCompatActivity;

import com.example.printxpress.Firebase.FirebaseHelper;
import com.example.printxpress.R;
import com.example.printxpress.models.BannerOrder;

import java.io.ByteArrayOutputStream;
import java.io.InputStream;
import java.util.Calendar;
import java.util.UUID;

public class BannerOrderActivity extends AppCompatActivity {

    private EditText etBannerTitle, etLanguage, etCustomSize, etMainHeading, etSubHeading, etDescription, etOfferDetails, etDateTime, etAddress, etContactNumber, etColorTheme, etFontStyle, etDesignNotes, etQuantity, etDeliveryAddress, etDeadline;
    private Spinner spPurpose;
    private RadioGroup rgSize, rgMaterial, rgDelivery;
    private TextView tvPrice;
    private CheckBox cbEyelets, cbRope, cbStand, cbUrgent;
    private LinearLayout layoutUploadLogo, layoutUploadProduct, layoutUploadPerson, layoutUploadExample;
    private ImageView ivLogoPreview, ivProductPreview, ivPersonPreview, ivExamplePreview, ivBack;
    private Button btnOrder;

    private FirebaseHelper firebaseHelper;
    private String logoBase64 = "", productBase64 = "", personBase64 = "", exampleBase64 = "";
    private double currentTotalPrice = 0;

    private final ActivityResultLauncher<Intent> logoLauncher = registerForActivityResult(new ActivityResultContracts.StartActivityForResult(), result -> handleImageResult(result, ivLogoPreview, 1));
    private final ActivityResultLauncher<Intent> productLauncher = registerForActivityResult(new ActivityResultContracts.StartActivityForResult(), result -> handleImageResult(result, ivProductPreview, 2));
    private final ActivityResultLauncher<Intent> personLauncher = registerForActivityResult(new ActivityResultContracts.StartActivityForResult(), result -> handleImageResult(result, ivPersonPreview, 3));
    private final ActivityResultLauncher<Intent> exampleLauncher = registerForActivityResult(new ActivityResultContracts.StartActivityForResult(), result -> handleImageResult(result, ivExamplePreview, 4));

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_banner_order);

        firebaseHelper = new FirebaseHelper();

        initViews();
        setupSpinners();
        setupPickers();
        setupListeners();
    }

    private void initViews() {
        ivBack = findViewById(R.id.ivBack);
        etBannerTitle = findViewById(R.id.etBannerTitle);
        spPurpose = findViewById(R.id.spPurpose);
        etLanguage = findViewById(R.id.etLanguage);
        rgSize = findViewById(R.id.rgSize);
        etCustomSize = findViewById(R.id.etCustomSize);
        tvPrice = findViewById(R.id.tvPrice);
        rgMaterial = findViewById(R.id.rgMaterial);
        etMainHeading = findViewById(R.id.etMainHeading);
        etSubHeading = findViewById(R.id.etSubHeading);
        etDescription = findViewById(R.id.etDescription);
        etOfferDetails = findViewById(R.id.etOfferDetails);
        etDateTime = findViewById(R.id.etDateTime);
        etAddress = findViewById(R.id.etAddress);
        etContactNumber = findViewById(R.id.etContactNumber);
        layoutUploadLogo = findViewById(R.id.layoutUploadLogo);
        layoutUploadProduct = findViewById(R.id.layoutUploadProduct);
        layoutUploadPerson = findViewById(R.id.layoutUploadPerson);
        ivLogoPreview = findViewById(R.id.ivLogoPreview);
        ivProductPreview = findViewById(R.id.ivProductPreview);
        ivPersonPreview = findViewById(R.id.ivPersonPreview);
        etColorTheme = findViewById(R.id.etColorTheme);
        etFontStyle = findViewById(R.id.etFontStyle);
        layoutUploadExample = findViewById(R.id.layoutUploadExample);
        ivExamplePreview = findViewById(R.id.ivExamplePreview);
        etDesignNotes = findViewById(R.id.etDesignNotes);
        cbEyelets = findViewById(R.id.cbEyelets);
        cbRope = findViewById(R.id.cbRope);
        cbStand = findViewById(R.id.cbStand);
        etQuantity = findViewById(R.id.etQuantity);
        rgDelivery = findViewById(R.id.rgDelivery);
        etDeliveryAddress = findViewById(R.id.etDeliveryAddress);
        etDeadline = findViewById(R.id.etDeadline);
        cbUrgent = findViewById(R.id.cbUrgent);
        btnOrder = findViewById(R.id.btnOrder);
    }

    private void setupSpinners() {
        String[] purposes = {"Select Purpose", "Shop opening", "Offer / Sale", "Event", "Political / Awareness", "Others"};
        ArrayAdapter<String> pAdapter = new ArrayAdapter<>(this, R.layout.spinner_item, purposes);
        pAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        spPurpose.setAdapter(pAdapter);
    }

    private void setupPickers() {
        etDeadline.setOnClickListener(v -> {
            Calendar c = Calendar.getInstance();
            new DatePickerDialog(this, (view, year, month, day) -> {
                etDeadline.setText(day + "/" + (month + 1) + "/" + year);
            }, c.get(Calendar.YEAR), c.get(Calendar.MONTH), c.get(Calendar.DAY_OF_MONTH)).show();
        });
    }

    private void setupListeners() {
        ivBack.setOnClickListener(v -> finish());

        rgSize.setOnCheckedChangeListener((group, checkedId) -> {
            etCustomSize.setVisibility(checkedId == R.id.rbCustomSize ? View.VISIBLE : View.GONE);
            calculatePrice();
        });

        rgMaterial.setOnCheckedChangeListener((group, checkedId) -> calculatePrice());

        etQuantity.addTextChangedListener(new TextWatcher() {
            @Override public void beforeTextChanged(CharSequence s, int start, int count, int after) {}
            @Override public void onTextChanged(CharSequence s, int start, int before, int count) { calculatePrice(); }
            @Override public void afterTextChanged(Editable s) {}
        });

        etCustomSize.addTextChangedListener(new TextWatcher() {
            @Override public void beforeTextChanged(CharSequence s, int start, int count, int after) {}
            @Override public void onTextChanged(CharSequence s, int start, int before, int count) { calculatePrice(); }
            @Override public void afterTextChanged(Editable s) {}
        });

        cbUrgent.setOnCheckedChangeListener((buttonView, isChecked) -> calculatePrice());
        cbEyelets.setOnCheckedChangeListener((buttonView, isChecked) -> calculatePrice());
        cbRope.setOnCheckedChangeListener((buttonView, isChecked) -> calculatePrice());
        cbStand.setOnCheckedChangeListener((buttonView, isChecked) -> calculatePrice());

        rgDelivery.setOnCheckedChangeListener((group, checkedId) -> {
            etDeliveryAddress.setVisibility(checkedId == R.id.rbDelivery ? View.VISIBLE : View.GONE);
            calculatePrice();
        });

        layoutUploadLogo.setOnClickListener(v -> openGallery(logoLauncher));
        layoutUploadProduct.setOnClickListener(v -> openGallery(productLauncher));
        layoutUploadPerson.setOnClickListener(v -> openGallery(personLauncher));
        layoutUploadExample.setOnClickListener(v -> openGallery(exampleLauncher));

        btnOrder.setOnClickListener(v -> validateAndProceedToPayment());
    }

    private void calculatePrice() {
        double sqft = 0;
        int selectedSizeId = rgSize.getCheckedRadioButtonId();
        if (selectedSizeId == R.id.rb2x4) sqft = 8;
        else if (selectedSizeId == R.id.rb3x6) sqft = 18;
        else if (selectedSizeId == R.id.rb4x8) sqft = 32;
        else if (selectedSizeId == R.id.rbCustomSize) {
            String custom = etCustomSize.getText().toString().toLowerCase();
            if (custom.contains("x")) {
                try {
                    String[] parts = custom.split("x");
                    sqft = Double.parseDouble(parts[0].trim()) * Double.parseDouble(parts[1].trim());
                } catch (Exception e) { sqft = 0; }
            }
        }

        double ratePerSqft = 150; // Default Flex LKR
        int materialId = rgMaterial.getCheckedRadioButtonId();
        if (materialId == R.id.rbVinyl) ratePerSqft = 250;
        else if (materialId == R.id.rbMatte) ratePerSqft = 400;

        if (cbEyelets.isChecked()) ratePerSqft += 10;
        if (cbRope.isChecked()) ratePerSqft += 5;
        if (cbStand.isChecked()) ratePerSqft += 50;

        int qty = 1;
        try { qty = Integer.parseInt(etQuantity.getText().toString()); } catch (Exception e) {}

        currentTotalPrice = sqft * ratePerSqft * qty;

        if (rgDelivery.getCheckedRadioButtonId() == R.id.rbDelivery) {
            currentTotalPrice += 350;
        }

        if (cbUrgent.isChecked()) {
            currentTotalPrice += 500;
        }

        tvPrice.setText("Estimated Price: Rs " + (int)currentTotalPrice + ".00");
    }

    private void openGallery(ActivityResultLauncher<Intent> launcher) {
        Intent intent = new Intent(Intent.ACTION_PICK);
        intent.setType("image/*");
        launcher.launch(intent);
    }

    private void handleImageResult(androidx.activity.result.ActivityResult result, ImageView preview, int type) {
        if (result.getResultCode() == RESULT_OK && result.getData() != null) {
            Uri uri = result.getData().getData();
            String base64 = encodeImage(uri);
            if (type == 1) logoBase64 = base64;
            else if (type == 2) productBase64 = base64;
            else if (type == 3) personBase64 = base64;
            else if (type == 4) exampleBase64 = base64;
            Toast.makeText(this, "Image selected successfully", Toast.LENGTH_SHORT).show();
        }
    }

    private String encodeImage(Uri uri) {
        try {
            InputStream is = getContentResolver().openInputStream(uri);
            Bitmap bitmap = BitmapFactory.decodeStream(is);
            if (bitmap == null) return "";
            Bitmap scaled = Bitmap.createScaledBitmap(bitmap, 800, (int)(800.0 * bitmap.getHeight() / bitmap.getWidth()), true);
            ByteArrayOutputStream baos = new ByteArrayOutputStream();
            scaled.compress(Bitmap.CompressFormat.JPEG, 60, baos);
            return Base64.encodeToString(baos.toByteArray(), Base64.DEFAULT);
        } catch (Exception e) { return ""; }
    }

    private void validateAndProceedToPayment() {
        String title = etBannerTitle.getText().toString().trim();
        String purpose = spPurpose.getSelectedItem().toString();
        String qty = etQuantity.getText().toString().trim();

        if (title.isEmpty() || purpose.equals("Select Purpose") || qty.isEmpty()) {
            Toast.makeText(this, "Please fill required fields", Toast.LENGTH_SHORT).show();
            return;
        }

        int sizeId = rgSize.getCheckedRadioButtonId();
        if (sizeId == R.id.rbCustomSize && etCustomSize.getText().toString().trim().isEmpty()) {
            Toast.makeText(this, "Please enter your custom size", Toast.LENGTH_SHORT).show();
            return;
        }

        String size = "";
        if (sizeId == R.id.rb2x4) size = "2ft x 4ft";
        else if (sizeId == R.id.rb3x6) size = "3ft x 6ft";
        else if (sizeId == R.id.rb4x8) size = "4ft x 8ft";
        else size = "Custom: " + etCustomSize.getText().toString();

        String material = "Flex";
        int matId = rgMaterial.getCheckedRadioButtonId();
        if (matId == R.id.rbVinyl) material = "Vinyl";
        else if (matId == R.id.rbMatte) material = "Matte/Glossy";

        String delivery = rgDelivery.getCheckedRadioButtonId() == R.id.rbDelivery ? "Delivery" : "Pickup";

        String userId = firebaseHelper.getCurrentUser() != null ? firebaseHelper.getCurrentUser().getUid() : "anonymous";
        String orderId = UUID.randomUUID().toString();

        BannerOrder order = new BannerOrder(
                orderId, userId, title, purpose, etLanguage.getText().toString(),
                size, material, etMainHeading.getText().toString(), etSubHeading.getText().toString(),
                etDescription.getText().toString(), etOfferDetails.getText().toString(),
                etDateTime.getText().toString(), etAddress.getText().toString(),
                etContactNumber.getText().toString(), logoBase64, productBase64, personBase64,
                etColorTheme.getText().toString(), etFontStyle.getText().toString(),
                exampleBase64, etDesignNotes.getText().toString(),
                cbEyelets.isChecked(), cbRope.isChecked(), cbStand.isChecked(),
                qty, delivery, etDeliveryAddress.getText().toString(),
                etDeadline.getText().toString(), cbUrgent.isChecked(),
                "", System.currentTimeMillis(), currentTotalPrice, "Pending"
        );

        Intent intent = new Intent(this, PaymentBillingActivity.class);
        intent.putExtra("order_data", order);
        startActivity(intent);
    }
}
