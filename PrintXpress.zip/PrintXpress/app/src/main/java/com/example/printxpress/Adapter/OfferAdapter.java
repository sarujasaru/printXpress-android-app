package com.example.printxpress.Adapter;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.bumptech.glide.Glide;
import com.example.printxpress.R;
import com.example.printxpress.models.Offer;

import java.util.List;

public class OfferAdapter extends RecyclerView.Adapter<OfferAdapter.OfferViewHolder> {

    private List<Offer> offerList;

    public OfferAdapter(List<Offer> offerList) {
        this.offerList = offerList;
    }

    @NonNull
    @Override
    public OfferViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.item_offer_slider, parent, false);
        return new OfferViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull OfferViewHolder holder, int position) {
        if (offerList == null || offerList.isEmpty()) return;
        
        Offer offer = offerList.get(position % offerList.size());
        String url = offer.getImageUrl();
        
        if (url != null) {
            url = url.trim(); // URL-ல் உள்ள தேவையற்ற இடைவெளிகளை நீக்க
        }
        
        Glide.with(holder.itemView.getContext())
                .load(url)
                .placeholder(R.drawable.offer1)
                .error(R.drawable.baseline_arrow_back_24)
                .into(holder.ivOffer);
    }

    @Override
    public int getItemCount() {
        if (offerList == null || offerList.isEmpty()) return 0;
        return Integer.MAX_VALUE;
    }

    public static class OfferViewHolder extends RecyclerView.ViewHolder {
        ImageView ivOffer;

        public OfferViewHolder(@NonNull View itemView) {
            super(itemView);
            ivOffer = itemView.findViewById(R.id.ivOffer);
        }
    }
}
