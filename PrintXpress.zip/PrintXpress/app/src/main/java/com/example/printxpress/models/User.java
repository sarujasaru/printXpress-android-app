package com.example.printxpress.models;

public class User {
    private String Uid;
    private String username;
    private String phoneno;
    private String address;
    private String email;
    private String password;
    private String confirmPassword;

    public User() {
    }

    public User(String Uid, String username, String phoneno, String address, String email, String password, String confirmPassword) {
        this.Uid = Uid;
        this.username = username;
        this.phoneno = phoneno;
        this.address = address;
        this.email = email;
        this.password = password;
        this.confirmPassword = confirmPassword;
    }

    public String getUid() {
        return Uid;
    }

    public void setUid(String uid) {
        Uid = uid;
    }

    public String getUsername() {
        return username;
    }

    public void setUsername(String username) {
        this.username = username;
    }

    public String getPhoneno() {
        return phoneno;
    }

    public void setPhoneno(String phoneno) {
        this.phoneno = phoneno;
    }

    public String getAddress() {
        return address;
    }

    public void setAddress(String address) {
        this.address = address;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public String getPassword() {
        return password;
    }

    public void setPassword(String password) {
        this.password = password;
    }

    public String getConfirmPassword() {
        return confirmPassword;
    }

    public void setConfirmPassword(String confirmPassword) {
        this.confirmPassword = confirmPassword;
    }
}
