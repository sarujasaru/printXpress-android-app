package com.example.printxpress.Activity;

import android.app.DatePickerDialog;
import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.PorterDuff;
import android.graphics.Typeface;
import android.net.Uri;
import android.os.Bundle;
import android.text.Editable;
import android.text.TextWatcher;
import android.util.Log;
import android.view.MotionEvent;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.RadioGroup;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;

import com.example.printxpress.R;
import com.example.printxpress.models.TshirtOrder;
import com.github.dhaval2404.colorpicker.ColorPickerDialog;
import com.github.dhaval2404.colorpicker.model.ColorShape;
import com.google.android.material.chip.Chip;
import com.google.android.material.chip.ChipGroup;
import com.google.android.material.textfield.TextInputLayout;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.storage.FirebaseStorage;
import com.google.firebase.storage.StorageReference;

import java.io.ByteArrayOutputStream;
import java.util.Calendar;
import java.util.HashMap;
import java.util.Map;
import java.util.UUID;

public class TshirtOrderActivity extends AppCompatActivity {

    private static final String TAG = "TshirtOrderActivity";
    private static final int PICK_IMAGE_REQUEST = 1;

    private ImageView ivPreviewTshirt, ivUserDesignPreview, ivUploadedDesign;
    private TextView tvUserTextPreview, tvTotalQuantity, tvTotalPrice;
    private EditText etPrintText, etAddress, etSpecialInstructions;
    private ChipGroup cgNeckStyle, cgGender, cgMaterial, cgTshirtColor, cgPlacement, cgPrintType, cgDesignSize, cgUsage, cgPackaging, cgBudget;
    private CheckBox cbUrgent;
    private Button btnUploadDesign, btnDeadlineDate, btnPlaceOrder;
    private Spinner spFontStyle, spTextColor;
    private RadioGroup rgDelivery;
    private TextInputLayout tilDeliveryAddress;
    private FrameLayout previewLayoutContainer;
    private Toolbar toolbar;

    private Uri filePath;
    private String deadlineDate = "";
    private int totalQty = 0;
    private double currentTotalPrice = 0;
    private String customSelectedColor = "#FFFFFF";

    private View viewS, viewM, viewL, viewXL, viewXXL;
    private Map<String, Integer> sizeQuantities = new HashMap<>();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        try {
            setContentView(R.layout.activity_tshirt_order);
            initViews();
            setupToolbar();
            setupSpinners();
            setupSizePickers();
            setupListeners();

            if (tvUserTextPreview != null) setupDragListener(tvUserTextPreview);
            if (ivUserDesignPreview != null) setupDragListener(ivUserDesignPreview);

        } catch (Exception e) {
            Log.e(TAG, "Error: " + e.getMessage());
            finish();
        }
    }

    private void setupToolbar() {
        toolbar = findViewById(R.id.toolbar);
        if (toolbar != null) {
            setSupportActionBar(toolbar);
            if (getSupportActionBar() != null) getSupportActionBar().setDisplayHomeAsUpEnabled(true);
            toolbar.setNavigationOnClickListener(v -> finish());
        }
    }

    private void initViews() {
        previewLayoutContainer = findViewById(R.id.previewLayoutContainer);
        ivPreviewTshirt = findViewById(R.id.ivPreviewTshirt);
        ivUploadedDesign = findViewById(R.id.ivUploadedDesign);
        tvTotalQuantity = findViewById(R.id.tvTotalQuantity);
        tvTotalPrice = findViewById(R.id.tvTotalPrice);
        etPrintText = findViewById(R.id.etPrintText);
        etAddress = findViewById(R.id.etAddress);
        etSpecialInstructions = findViewById(R.id.etSpecialInstructions);
        cgNeckStyle = findViewById(R.id.cgNeckStyle);
        cgGender = findViewById(R.id.cgGender);
        cgMaterial = findViewById(R.id.cgMaterial);
        cgTshirtColor = findViewById(R.id.cgTshirtColor);
        cgPlacement = findViewById(R.id.cgPlacement);
        cgPrintType = findViewById(R.id.cgPrintType);
        cgDesignSize = findViewById(R.id.cgDesignSize);
        cgUsage = findViewById(R.id.cgUsage);
        cgPackaging = findViewById(R.id.cgPackaging);
        cgBudget = findViewById(R.id.cgBudget);
        cbUrgent = findViewById(R.id.cbUrgent);
        btnUploadDesign = findViewById(R.id.btnUploadDesign);
        btnDeadlineDate = findViewById(R.id.btnDeadlineDate);
        btnPlaceOrder = findViewById(R.id.btnPlaceOrder);
        spFontStyle = findViewById(R.id.spFontStyle);
        spTextColor = findViewById(R.id.spTextColor);
        rgDelivery = findViewById(R.id.rgDelivery);
        tilDeliveryAddress = findViewById(R.id.tilDeliveryAddress);

        viewS = findViewById(R.id.sizeS);
        viewM = findViewById(R.id.sizeM);
        viewL = findViewById(R.id.sizeL);
        viewXL = findViewById(R.id.sizeXL);
        viewXXL = findViewById(R.id.sizeXXL);

        if (viewS != null && viewS.findViewById(R.id.tvSizeLabel) != null) ((TextView) viewS.findViewById(R.id.tvSizeLabel)).setText("S");
        if (viewM != null && viewM.findViewById(R.id.tvSizeLabel) != null) ((TextView) viewM.findViewById(R.id.tvSizeLabel)).setText("M");
        if (viewL != null && viewL.findViewById(R.id.tvSizeLabel) != null) ((TextView) viewL.findViewById(R.id.tvSizeLabel)).setText("L");
        if (viewXL != null && viewXL.findViewById(R.id.tvSizeLabel) != null) ((TextView) viewXL.findViewById(R.id.tvSizeLabel)).setText("XL");
        if (viewXXL != null && viewXXL.findViewById(R.id.tvSizeLabel) != null) ((TextView) viewXXL.findViewById(R.id.tvSizeLabel)).setText("XXL");
    }

    private void setupSpinners() {
        String[] fonts = {"Default", "Serif", "Monospace", "Bold"};
        String[] colors = {"Black", "White", "Red", "Blue", "Gold"};

        ArrayAdapter<String> fontAdapter = new ArrayAdapter<>(this, R.layout.spinner_item, fonts);
        fontAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        if (spFontStyle != null) spFontStyle.setAdapter(fontAdapter);

        ArrayAdapter<String> colorAdapter = new ArrayAdapter<>(this, R.layout.spinner_item, colors);
        colorAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        if (spTextColor != null) spTextColor.setAdapter(colorAdapter);
    }

    private void setupSizePickers() {
        if (viewS != null) setupSingleSizePicker(viewS, "S");
        if (viewM != null) setupSingleSizePicker(viewM, "M");
        if (viewL != null) setupSingleSizePicker(viewL, "L");
        if (viewXL != null) setupSingleSizePicker(viewXL, "XL");
        if (viewXXL != null) setupSingleSizePicker(viewXXL, "XXL");
    }

    private void setupSingleSizePicker(View view, String size) {
        TextView tvQty = view.findViewById(R.id.tvQuantity);
        if (tvQty == null) return;
        sizeQuantities.put(size, 0);
        View btnAdd = view.findViewById(R.id.btnAdd);
        View btnMinus = view.findViewById(R.id.btnMinus);
        
        if (btnAdd != null) {
            btnAdd.setOnClickListener(v -> {
                int current = sizeQuantities.get(size);
                sizeQuantities.put(size, current + 1);
                tvQty.setText(String.valueOf(current + 1));
                updateTotal();
            });
        }
        if (btnMinus != null) {
            btnMinus.setOnClickListener(v -> {
                int current = sizeQuantities.get(size);
                if (current > 0) {
                    sizeQuantities.put(size, current - 1);
                    tvQty.setText(String.valueOf(current - 1));
                    updateTotal();
                }
            });
        }
    }

    private void updateTotal() {
        totalQty = 0;
        for (int qty : sizeQuantities.values()) totalQty += qty;
        if (tvTotalQuantity != null) tvTotalQuantity.setText("Total Quantity: " + totalQty);

        double baseUnitPrice = 1500.0; // Base Price in LKR

        // Neck Style Adjustment
        int neckId = cgNeckStyle.getCheckedChipId();
        if (neckId == R.id.chipCollar) baseUnitPrice += 350;
        else if (neckId == R.id.chipVneck) baseUnitPrice += 200;

        // Material Adjustment
        int matId = cgMaterial.getCheckedChipId();
        if (matId == R.id.chipCotton) baseUnitPrice += 250;
        else if (matId == R.id.chipDryfit) baseUnitPrice += 150;

        // Print Type Adjustment
        int printId = cgPrintType.getCheckedChipId();
        if (printId == R.id.chipScreen) baseUnitPrice += 200;
        else if (printId == R.id.chipHeat) baseUnitPrice += 350;
        else if (printId == R.id.chipEmbroidery) baseUnitPrice += 500;

        // Budget Adjustment
        int budId = cgBudget.getCheckedChipId();
        if (budId == R.id.chipBLow) baseUnitPrice -= 150;
        else if (budId == R.id.chipBPremium) baseUnitPrice += 400;

        currentTotalPrice = totalQty * baseUnitPrice;

        // Packaging Adjustment (Flat)
        if (cgPackaging.getCheckedChipId() == R.id.chipGiftWrap) {
            currentTotalPrice += 200;
        }

        // Delivery Fee (LKR)
        if (rgDelivery != null && rgDelivery.getCheckedRadioButtonId() == R.id.rbDelivery) {
            currentTotalPrice += 350;
        }

        // Urgent Fee (Flat)
        if (cbUrgent != null && cbUrgent.isChecked()) {
            currentTotalPrice += 500;
        }

        if (tvTotalPrice != null) {
            tvTotalPrice.setText("Rs " + String.format("%.2f", currentTotalPrice));
        }
    }

    private void setupListeners() {
        if (etPrintText != null) {
            etPrintText.addTextChangedListener(new TextWatcher() {
                @Override public void beforeTextChanged(CharSequence s, int start, int count, int after) {}
                @Override public void onTextChanged(CharSequence s, int start, int before, int count) {
                    if (tvUserTextPreview != null) tvUserTextPreview.setText(s.toString());
                }
                @Override public void afterTextChanged(Editable s) {}
            });
        }

        if (spFontStyle != null) {
            spFontStyle.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
                @Override public void onItemSelected(AdapterView<?> p, View v, int pos, long id) {
                    String font = p.getItemAtPosition(pos).toString();
                    if (tvUserTextPreview == null) return;
                    switch (font) {
                        case "Serif": tvUserTextPreview.setTypeface(Typeface.SERIF); break;
                        case "Monospace": tvUserTextPreview.setTypeface(Typeface.MONOSPACE); break;
                        case "Bold": tvUserTextPreview.setTypeface(Typeface.DEFAULT_BOLD); break;
                        default: tvUserTextPreview.setTypeface(Typeface.DEFAULT); break;
                    }
                }
                @Override public void onNothingSelected(AdapterView<?> p) {}
            });
        }

        if (spTextColor != null) {
            spTextColor.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
                @Override public void onItemSelected(AdapterView<?> p, View v, int pos, long id) {
                    String color = p.getItemAtPosition(pos).toString();
                    if (tvUserTextPreview == null) return;
                    switch (color) {
                        case "Red": tvUserTextPreview.setTextColor(Color.RED); break;
                        case "Blue": tvUserTextPreview.setTextColor(Color.BLUE); break;
                        case "White": tvUserTextPreview.setTextColor(Color.WHITE); break;
                        case "Gold": tvUserTextPreview.setTextColor(Color.parseColor("#FFD700")); break;
                        default: tvUserTextPreview.setTextColor(Color.BLACK); break;
                    }
                }
                @Override public void onNothingSelected(AdapterView<?> p) {}
            });
        }

        ChipGroup.OnCheckedChangeListener priceListener = (group, checkedId) -> updateTotal();

        if (cgNeckStyle != null) {
            cgNeckStyle.setOnCheckedChangeListener((group, checkedId) -> {
                updateTshirtImage();
                updateTotal();
            });
        }

        if (cgGender != null) {
            cgGender.setOnCheckedChangeListener((group, checkedId) -> {
                updateTshirtImage();
            });
        }

        if (cgMaterial != null) cgMaterial.setOnCheckedChangeListener(priceListener);
        if (cgPrintType != null) cgPrintType.setOnCheckedChangeListener(priceListener);
        if (cgPackaging != null) cgPackaging.setOnCheckedChangeListener(priceListener);
        if (cgBudget != null) cgBudget.setOnCheckedChangeListener(priceListener);

        if (rgDelivery != null) {
            rgDelivery.setOnCheckedChangeListener((group, checkedId) -> {
                if (tilDeliveryAddress != null) {
                    tilDeliveryAddress.setVisibility(checkedId == R.id.rbDelivery ? View.VISIBLE : View.GONE);
                }
                updateTotal();
            });
        }

        if (cgTshirtColor != null) {
            cgTshirtColor.setOnCheckedChangeListener((group, checkedId) -> {
                if (checkedId == R.id.chipCustomColor) {
                    showColorPickerDialog();
                } else {
                    updateTshirtPreviewColor();
                }
            });
        }

        if (btnUploadDesign != null) btnUploadDesign.setOnClickListener(v -> chooseImage());
        if (btnDeadlineDate != null) btnDeadlineDate.setOnClickListener(v -> showDatePicker());
        if (cbUrgent != null) cbUrgent.setOnCheckedChangeListener((bv, is) -> updateTotal());
        if (btnPlaceOrder != null) btnPlaceOrder.setOnClickListener(v -> validateAndProceedToPayment());
    }

    private void updateTshirtImage() {
        if (ivPreviewTshirt == null) return;
        int neckId = cgNeckStyle.getCheckedChipId();
        int genderId = cgGender.getCheckedChipId();

        if (neckId == R.id.chipRound) {
            if (genderId == R.id.chipWomen) {
                ivPreviewTshirt.setImageResource(R.drawable.roundgirl);
            } else {
                ivPreviewTshirt.setImageResource(R.drawable.roundboy);
            }
        } else if (neckId == R.id.chipCollar) {
            if (genderId == R.id.chipWomen) {
                ivPreviewTshirt.setImageResource(R.drawable.colargirl);
            } else {
                ivPreviewTshirt.setImageResource(R.drawable.colorboy);
            }
        } else if (neckId == R.id.chipVneck) {
            if (genderId == R.id.chipWomen) {
                ivPreviewTshirt.setImageResource(R.drawable.vgirl);
            } else {
                ivPreviewTshirt.setImageResource(R.drawable.menv);
            }
        }
        updateTshirtPreviewColor();
    }

    private void updateTshirtPreviewColor() {
        if (ivPreviewTshirt == null || cgTshirtColor == null) return;
        int checkedId = cgTshirtColor.getCheckedChipId();

        if (checkedId == R.id.chipWhite || checkedId == View.NO_ID) {
            ivPreviewTshirt.setColorFilter(null);
        } else if (checkedId == R.id.chipCustomColor) {
            try {
                int colorInt = Color.parseColor(customSelectedColor);
                if (colorInt == Color.WHITE) {
                    ivPreviewTshirt.setColorFilter(null);
                } else {
                    ivPreviewTshirt.setColorFilter(colorInt, PorterDuff.Mode.MULTIPLY);
                }
            } catch (Exception e) {
                ivPreviewTshirt.setColorFilter(null);
            }
        } else {
            String colorName = getSelectedChipText(cgTshirtColor);
            int colorInt = Color.WHITE;
            switch (colorName) {
                case "Black": colorInt = Color.BLACK; break;
                case "Red": colorInt = Color.RED; break;
                case "Blue": colorInt = Color.BLUE; break;
                default: colorInt = Color.WHITE; break;
            }

            if (colorInt == Color.WHITE) {
                ivPreviewTshirt.setColorFilter(null);
            } else {
                ivPreviewTshirt.setColorFilter(colorInt, PorterDuff.Mode.MULTIPLY);
            }
        }
    }

    private void showColorPickerDialog() {
        new ColorPickerDialog.Builder(this)
                .setTitle("Choose T-Shirt Color")
                .setColorShape(ColorShape.SQAURE)
                .setDefaultColor(Color.WHITE)
                .setColorListener((color, colorHex) -> {
                    customSelectedColor = colorHex;
                    updateTshirtPreviewColor();
                    Toast.makeText(this, "Selected Color: " + colorHex, Toast.LENGTH_SHORT).show();
                })
                .show();
    }

    private void setupDragListener(View view) {
        view.setOnTouchListener(new View.OnTouchListener() {
            float dX, dY;
            @Override
            public boolean onTouch(View v, MotionEvent event) {
                switch (event.getAction()) {
                    case MotionEvent.ACTION_DOWN:
                        dX = v.getX() - event.getRawX();
                        dY = v.getY() - event.getRawY();
                        break;
                    case MotionEvent.ACTION_MOVE:
                        v.setX(event.getRawX() + dX);
                        v.setY(event.getRawY() + dY);
                        break;
                    default:
                        return false;
                }
                return true;
            }
        });
    }

    private Bitmap getBitmapFromView(View view) {
        Bitmap bitmap = Bitmap.createBitmap(view.getWidth(), view.getHeight(), Bitmap.Config.ARGB_8888);
        Canvas canvas = new Canvas(bitmap);
        view.draw(canvas);
        return bitmap;
    }

    private void chooseImage() {
        Intent intent = new Intent(Intent.ACTION_GET_CONTENT);
        intent.setType("image/*");
        startActivityForResult(Intent.createChooser(intent, "Select Design"), PICK_IMAGE_REQUEST);
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == PICK_IMAGE_REQUEST && resultCode == RESULT_OK && data != null && data.getData() != null) {
            filePath = data.getData();
            Toast.makeText(this, "Design selected successfully!", Toast.LENGTH_SHORT).show();
        }
    }

    private void showDatePicker() {
        final Calendar c = Calendar.getInstance();
        new DatePickerDialog(this, (v, y, m, d) -> {
            deadlineDate = d + "/" + (m + 1) + "/" + y;
            btnDeadlineDate.setText(deadlineDate);
        }, c.get(Calendar.YEAR), c.get(Calendar.MONTH), c.get(Calendar.DAY_OF_MONTH)).show();
    }

    private void validateAndProceedToPayment() {
        if (totalQty == 0) { Toast.makeText(this, "Select at least one shirt", Toast.LENGTH_SHORT).show(); return; }
        if (rgDelivery.getCheckedRadioButtonId() == R.id.rbDelivery && (etAddress == null || etAddress.getText().toString().isEmpty())) { 
            Toast.makeText(this, "Enter delivery address", Toast.LENGTH_SHORT).show(); 
            return; 
        }
        uploadData();
    }

    private void uploadData() {
        String orderId = UUID.randomUUID().toString();
        String finalColor = (cgTshirtColor.getCheckedChipId() == R.id.chipCustomColor) ? customSelectedColor : getSelectedChipText(cgTshirtColor);

        TshirtOrder order = new TshirtOrder(
                orderId, FirebaseAuth.getInstance().getUid(), "T-Shirt", sizeQuantities, totalQty,
                getSelectedChipText(cgNeckStyle), getSelectedChipText(cgGender), getSelectedChipText(cgMaterial),
                finalColor, etPrintText.getText().toString(),
                (spFontStyle != null) ? spFontStyle.getSelectedItem().toString() : "", 
                (spTextColor != null) ? spTextColor.getSelectedItem().toString() : "",
                getSelectedChipText(cgPlacement), getSelectedChipText(cgPrintType), getSelectedChipText(cgDesignSize),
                getSelectedChipText(cgUsage), getSelectedChipText(cgPackaging), getSelectedChipText(cgBudget),
                etAddress.getText().toString(), deadlineDate, cbUrgent.isChecked(),
                etSpecialInstructions.getText().toString(), "Pending", System.currentTimeMillis()
        );
        order.setTotalPrice(currentTotalPrice);

        Bitmap finalDesignBitmap = getBitmapFromView(previewLayoutContainer);
        ByteArrayOutputStream baos = new ByteArrayOutputStream();
        finalDesignBitmap.compress(Bitmap.CompressFormat.PNG, 100, baos);
        byte[] data = baos.toByteArray();

        StorageReference sRef = FirebaseStorage.getInstance().getReference("Designs/" + orderId + "_final.png");
        sRef.putBytes(data).addOnSuccessListener(taskSnapshot -> sRef.getDownloadUrl().addOnSuccessListener(uri -> {
            order.setDesignUrl(uri.toString());
            proceedToPayment(order);
        })).addOnFailureListener(e -> {
            proceedToPayment(order);
        });
    }

    private void proceedToPayment(TshirtOrder order) {
        Intent intent = new Intent(this, PaymentBillingActivity.class);
        intent.putExtra("order_data", order);
        startActivity(intent);
    }

    private String getSelectedChipText(ChipGroup cg) {
        if (cg == null) return "";
        int id = cg.getCheckedChipId();
        return (id != View.NO_ID) ? ((Chip) findViewById(id)).getText().toString() : "";
    }
}
