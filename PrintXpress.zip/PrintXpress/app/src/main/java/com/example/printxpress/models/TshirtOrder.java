package com.example.printxpress.models;

import java.util.Map;

public class TshirtOrder implements BaseOrder {
    private String orderId;
    private String userId;
    private String product;
    private Map<String, Integer> sizeQuantities;
    private int totalQty;
    private String neckStyle;
    private String gender;
    private String material;
    private String tshirtColor;
    private String printText;
    private String fontStyle;
    private String textColor;
    private String placement;
    private String printType;
    private String designSize;
    private String usage;
    private String packaging;
    private String budget;
    private String address;
    private String deadline;
    private boolean isUrgent;
    private String instructions;
    private String status;
    private long timestamp;
    private String designUrl;
    private double totalPrice;

    public TshirtOrder() {
        // Required for Firebase
    }

    public TshirtOrder(String orderId, String userId, String product, Map<String, Integer> sizeQuantities, int totalQty, String neckStyle, String gender, String material, String tshirtColor, String printText, String fontStyle, String textColor, String placement, String printType, String designSize, String usage, String packaging, String budget, String address, String deadline, boolean isUrgent, String instructions, String status, long timestamp) {
        this.orderId = orderId;
        this.userId = userId;
        this.product = product;
        this.sizeQuantities = sizeQuantities;
        this.totalQty = totalQty;
        this.neckStyle = neckStyle;
        this.gender = gender;
        this.material = material;
        this.tshirtColor = tshirtColor;
        this.printText = printText;
        this.fontStyle = fontStyle;
        this.textColor = textColor;
        this.placement = placement;
        this.printType = printType;
        this.designSize = designSize;
        this.usage = usage;
        this.packaging = packaging;
        this.budget = budget;
        this.address = address;
        this.deadline = deadline;
        this.isUrgent = isUrgent;
        this.instructions = instructions;
        this.status = status;
        this.timestamp = timestamp;
    }

    @Override
    public String getProductType() { return "T-Shirt"; }

    @Override
    public String getOrderSummary() {
        return "Qty: " + totalQty + " | Neck: " + neckStyle + " | Material: " + material;
    }

    @Override
    public String getPhotoUrl() { return designUrl; }

    @Override
    public String getBase64Image() { return null; }

    // Getters and Setters
    public String getOrderId() { return orderId; }
    public void setOrderId(String orderId) { this.orderId = orderId; }

    public String getUserId() { return userId; }
    public void setUserId(String userId) { this.userId = userId; }

    public String getProduct() { return product; }
    public void setProduct(String product) { this.product = product; }

    public Map<String, Integer> getSizeQuantities() { return sizeQuantities; }
    public void setSizeQuantities(Map<String, Integer> sizeQuantities) { this.sizeQuantities = sizeQuantities; }

    public int getTotalQty() { return totalQty; }
    public void setTotalQty(int totalQty) { this.totalQty = totalQty; }

    public String getNeckStyle() { return neckStyle; }
    public void setNeckStyle(String neckStyle) { this.neckStyle = neckStyle; }

    public String getGender() { return gender; }
    public void setGender(String gender) { this.gender = gender; }

    public String getMaterial() { return material; }
    public void setMaterial(String material) { this.material = material; }

    public String getTshirtColor() { return tshirtColor; }
    public void setTshirtColor(String tshirtColor) { this.tshirtColor = tshirtColor; }

    public String getPrintText() { return printText; }
    public void setPrintText(String printText) { this.printText = printText; }

    public String getFontStyle() { return fontStyle; }
    public void setFontStyle(String fontStyle) { this.fontStyle = fontStyle; }

    public String getTextColor() { return textColor; }
    public void setTextColor(String textColor) { this.textColor = textColor; }

    public String getPlacement() { return placement; }
    public void setPlacement(String placement) { this.placement = placement; }

    public String getPrintType() { return printType; }
    public void setPrintType(String printType) { this.printType = printType; }

    public String getDesignSize() { return designSize; }
    public void setDesignSize(String designSize) { this.designSize = designSize; }

    public String getUsage() { return usage; }
    public void setUsage(String usage) { this.usage = usage; }

    public String getPackaging() { return packaging; }
    public void setPackaging(String packaging) { this.packaging = packaging; }

    public String getBudget() { return budget; }
    public void setBudget(String budget) { this.budget = budget; }

    public String getAddress() { return address; }
    public void setAddress(String address) { this.address = address; }

    public String getDeadline() { return deadline; }
    public void setDeadline(String deadline) { this.deadline = deadline; }

    public boolean isUrgent() { return isUrgent; }
    public void setUrgent(boolean urgent) { isUrgent = urgent; }

    public String getInstructions() { return instructions; }
    public void setInstructions(String instructions) { this.instructions = instructions; }

    public String getStatus() { return status; }
    public void setStatus(String status) { this.status = status; }

    public long getTimestamp() { return timestamp; }
    public void setTimestamp(long timestamp) { this.timestamp = timestamp; }

    public String getDesignUrl() { return designUrl; }
    public void setDesignUrl(String designUrl) { this.designUrl = designUrl; }

    public double getTotalPrice() { return totalPrice; }
    public void setTotalPrice(double totalPrice) { this.totalPrice = totalPrice; }
}
