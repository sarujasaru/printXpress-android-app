package com.example.printxpress.Activity;

import android.app.DatePickerDialog;
import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.net.Uri;
import android.os.Bundle;
import android.text.Editable;
import android.text.TextWatcher;
import android.util.Base64;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.RadioGroup;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

import androidx.activity.result.ActivityResultLauncher;
import androidx.activity.result.contract.ActivityResultContracts;
import androidx.appcompat.app.AppCompatActivity;

import com.example.printxpress.Firebase.FirebaseHelper;
import com.example.printxpress.R;
import com.example.printxpress.models.FlyerOrder;

import java.io.ByteArrayOutputStream;
import java.io.InputStream;
import java.util.Calendar;
import java.util.Locale;
import java.util.UUID;

public class FlyerOrderActivity extends AppCompatActivity {

    private EditText etFlyerTitle, etMainHeading, etSubHeading, etDescription, etOfferDetails, etDateTime, etAddress, etContactNumber, etColorTheme, etFontStyle, etQuantity, etDeliveryAddress, etDeadline, etSpecialInstructions;
    private Spinner spPurpose, spLanguage, spStyle, spLayout, spDistribution;
    private RadioGroup rgSize, rgOrientation, rgPrintType, rgPaperType, rgDelivery;
    private TextView tvPrice;
    private CheckBox cbUrgent;
    private LinearLayout layoutUploadLogo, layoutUploadProduct, layoutUploadBg;
    private ImageView ivLogoPreview, ivProductPreview, ivBgPreview, ivBack;
    private Button btnOrder;

    private FirebaseHelper firebaseHelper;
    private String logoBase64 = "", productBase64 = "", bgBase64 = "";
    private double currentTotalPrice = 0;

    private final ActivityResultLauncher<Intent> logoLauncher = registerForActivityResult(new ActivityResultContracts.StartActivityForResult(), result -> handleImageResult(result, ivLogoPreview, 1));
    private final ActivityResultLauncher<Intent> productLauncher = registerForActivityResult(new ActivityResultContracts.StartActivityForResult(), result -> handleImageResult(result, ivProductPreview, 2));
    private final ActivityResultLauncher<Intent> bgLauncher = registerForActivityResult(new ActivityResultContracts.StartActivityForResult(), result -> handleImageResult(result, ivBgPreview, 3));

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_flyer_order);

        firebaseHelper = new FirebaseHelper();

        initViews();
        setupSpinners();
        setupPickers();
        setupListeners();
    }

    private void initViews() {
        ivBack = findViewById(R.id.ivBack);
        etFlyerTitle = findViewById(R.id.etFlyerTitle);
        spPurpose = findViewById(R.id.spPurpose);
        spLanguage = findViewById(R.id.spLanguage);
        rgSize = findViewById(R.id.rgSize);
        rgOrientation = findViewById(R.id.rgOrientation);
        etMainHeading = findViewById(R.id.etMainHeading);
        etSubHeading = findViewById(R.id.etSubHeading);
        etDescription = findViewById(R.id.etDescription);
        etOfferDetails = findViewById(R.id.etOfferDetails);
        etDateTime = findViewById(R.id.etDateTime);
        etAddress = findViewById(R.id.etAddress);
        etContactNumber = findViewById(R.id.etContactNumber);
        layoutUploadLogo = findViewById(R.id.layoutUploadLogo);
        layoutUploadProduct = findViewById(R.id.layoutUploadProduct);
        layoutUploadBg = findViewById(R.id.layoutUploadBg);
        ivLogoPreview = findViewById(R.id.ivLogoPreview);
        ivProductPreview = findViewById(R.id.ivProductPreview);
        ivBgPreview = findViewById(R.id.ivBgPreview);
        etColorTheme = findViewById(R.id.etColorTheme);
        spStyle = findViewById(R.id.spStyle);
        etFontStyle = findViewById(R.id.etFontStyle);
        spLayout = findViewById(R.id.spLayout);
        rgPrintType = findViewById(R.id.rgPrintType);
        rgPaperType = findViewById(R.id.rgPaperType);
        etQuantity = findViewById(R.id.etQuantity);
        spDistribution = findViewById(R.id.spDistribution);
        rgDelivery = findViewById(R.id.rgDelivery);
        etDeliveryAddress = findViewById(R.id.etDeliveryAddress);
        etDeadline = findViewById(R.id.etDeadline);
        cbUrgent = findViewById(R.id.cbUrgent);
        etSpecialInstructions = findViewById(R.id.etSpecialInstructions);
        tvPrice = findViewById(R.id.tvPrice);
        btnOrder = findViewById(R.id.btnOrder);
    }

    private void setupSpinners() {
        String[] purposes = {"Purpose: Select", "Promotion / Offer", "Event", "Business Marketing", "Personal"};
        String[] languages = {"Language: English", "Language: Tamil", "Language: Both"};
        String[] styles = {"Style: Minimal", "Style: Creative", "Style: Corporate"};
        String[] layouts = {"Layout: Image top / Text bottom", "Layout: Image left / Text right", "Layout: Full background image"};
        String[] distributions = {"Distribution: Select", "Distribution: Hand-to-hand", "Distribution: Newspaper insert", "Distribution: Shop display"};

        setupSpinner(spPurpose, purposes);
        setupSpinner(spLanguage, languages);
        setupSpinner(spStyle, styles);
        setupSpinner(spLayout, layouts);
        setupSpinner(spDistribution, distributions);
    }

    private void setupSpinner(Spinner spinner, String[] items) {
        ArrayAdapter<String> adapter = new ArrayAdapter<>(this, R.layout.spinner_item, items);
        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        spinner.setAdapter(adapter);
    }

    private void setupPickers() {
        etDeadline.setOnClickListener(v -> {
            Calendar c = Calendar.getInstance();
            new DatePickerDialog(this, (view, year, month, day) -> {
                etDeadline.setText(String.format(Locale.getDefault(), "%02d/%02d/%d", day, month + 1, year));
            }, c.get(Calendar.YEAR), c.get(Calendar.MONTH), c.get(Calendar.DAY_OF_MONTH)).show();
        });
    }

    private void setupListeners() {
        ivBack.setOnClickListener(v -> finish());

        RadioGroup.OnCheckedChangeListener groupListener = (group, checkedId) -> calculatePrice();
        rgSize.setOnCheckedChangeListener(groupListener);
        rgPrintType.setOnCheckedChangeListener(groupListener);
        rgPaperType.setOnCheckedChangeListener(groupListener);
        rgDelivery.setOnCheckedChangeListener((group, checkedId) -> {
            etDeliveryAddress.setVisibility(checkedId == R.id.rbDelivery ? View.VISIBLE : View.GONE);
            calculatePrice();
        });

        cbUrgent.setOnCheckedChangeListener((buttonView, isChecked) -> calculatePrice());

        AdapterView.OnItemSelectedListener spinnerListener = new AdapterView.OnItemSelectedListener() {
            @Override public void onItemSelected(AdapterView<?> parent, View view, int position, long id) { calculatePrice(); }
            @Override public void onNothingSelected(AdapterView<?> parent) {}
        };
        spDistribution.setOnItemSelectedListener(spinnerListener);

        etQuantity.addTextChangedListener(new TextWatcher() {
            @Override public void beforeTextChanged(CharSequence s, int start, int count, int after) {}
            @Override public void onTextChanged(CharSequence s, int start, int before, int count) { calculatePrice(); }
            @Override public void afterTextChanged(Editable s) {}
        });

        layoutUploadLogo.setOnClickListener(v -> openGallery(logoLauncher));
        layoutUploadProduct.setOnClickListener(v -> openGallery(productLauncher));
        layoutUploadBg.setOnClickListener(v -> openGallery(bgLauncher));

        btnOrder.setOnClickListener(v -> validateAndProceedToPayment());
    }

    private void calculatePrice() {
        double unitPrice = 0;
        int sizeId = rgSize.getCheckedRadioButtonId();
        if (sizeId == R.id.rbA5) unitPrice = 15.0; // LKR
        else if (sizeId == R.id.rbA4) unitPrice = 30.0; // LKR
        else if (sizeId == R.id.rbA3) unitPrice = 60.0; // LKR

        if (rgPrintType.getCheckedRadioButtonId() == R.id.rbColor) unitPrice += 15.0; // LKR

        int paperId = rgPaperType.getCheckedRadioButtonId();
        if (paperId == R.id.rbGlossy) unitPrice += 10.0; // LKR
        else if (paperId == R.id.rbMatte) unitPrice += 12.0; // LKR

        int qty = 0;
        try {
            String qtyStr = etQuantity.getText().toString().trim();
            if (!qtyStr.isEmpty()) qty = Integer.parseInt(qtyStr);
        } catch (Exception e) {}

        currentTotalPrice = unitPrice * qty;

        if (!spDistribution.getSelectedItem().toString().equals("Distribution: Select")) {
            currentTotalPrice += 250;
        }

        if (rgDelivery.getCheckedRadioButtonId() == R.id.rbDelivery) {
            currentTotalPrice += 350;
        }

        if (cbUrgent.isChecked()) {
            currentTotalPrice += 500;
        }
        tvPrice.setText(String.format(Locale.getDefault(), "Estimated Price: Rs %.2f", currentTotalPrice));
    }

    private void openGallery(ActivityResultLauncher<Intent> launcher) {
        Intent intent = new Intent(Intent.ACTION_PICK);
        intent.setType("image/*");
        launcher.launch(intent);
    }

    private void handleImageResult(androidx.activity.result.ActivityResult result, ImageView preview, int type) {
        if (result.getResultCode() == RESULT_OK && result.getData() != null) {
            Uri uri = result.getData().getData();
            String base64 = encodeImage(uri);
            if (type == 1) logoBase64 = base64;
            else if (type == 2) productBase64 = base64;
            else if (type == 3) bgBase64 = base64;
            Toast.makeText(this, "Image selected successfully", Toast.LENGTH_SHORT).show();
        }
    }

    private String encodeImage(Uri uri) {
        try {
            InputStream is = getContentResolver().openInputStream(uri);
            Bitmap bitmap = BitmapFactory.decodeStream(is);
            if (bitmap == null) return "";
            Bitmap scaled = Bitmap.createScaledBitmap(bitmap, 800, (int) (800.0 * bitmap.getHeight() / bitmap.getWidth()), true);
            ByteArrayOutputStream baos = new ByteArrayOutputStream();
            scaled.compress(Bitmap.CompressFormat.JPEG, 60, baos);
            return Base64.encodeToString(baos.toByteArray(), Base64.DEFAULT);
        } catch (Exception e) { return ""; }
    }

    private void validateAndProceedToPayment() {
        String title = etFlyerTitle.getText().toString().trim();
        String qtyStr = etQuantity.getText().toString().trim();

        if (title.isEmpty() || qtyStr.isEmpty()) {
            Toast.makeText(this, "Please fill required fields (Title, Quantity)", Toast.LENGTH_SHORT).show();
            return;
        }

        String size = "A4";
        int sizeId = rgSize.getCheckedRadioButtonId();
        if (sizeId == R.id.rbA5) size = "A5";
        else if (sizeId == R.id.rbA3) size = "A3";

        String orientation = rgOrientation.getCheckedRadioButtonId() == R.id.rbPortrait ? "Portrait" : "Landscape";
        String printType = rgPrintType.getCheckedRadioButtonId() == R.id.rbColor ? "Color" : "Black & White";
        
        String paperType = "Normal";
        int pId = rgPaperType.getCheckedRadioButtonId();
        if (pId == R.id.rbGlossy) paperType = "Glossy";
        else if (pId == R.id.rbMatte) paperType = "Matte";

        String delivery = rgDelivery.getCheckedRadioButtonId() == R.id.rbDelivery ? "Delivery" : "Pickup";

        String userId = firebaseHelper.getCurrentUser() != null ? firebaseHelper.getCurrentUser().getUid() : "anonymous";
        String orderId = UUID.randomUUID().toString();

        FlyerOrder order = new FlyerOrder(
                orderId, userId, title, getSelectedItem(spPurpose), getSelectedItem(spLanguage),
                size, orientation, etMainHeading.getText().toString(), etSubHeading.getText().toString(),
                etDescription.getText().toString(), etOfferDetails.getText().toString(),
                etDateTime.getText().toString(), etAddress.getText().toString(),
                etContactNumber.getText().toString(), logoBase64, productBase64, bgBase64,
                etColorTheme.getText().toString(), getSelectedItem(spStyle), etFontStyle.getText().toString(),
                getSelectedItem(spLayout), printType, paperType, qtyStr,
                getSelectedItem(spDistribution), delivery, etDeliveryAddress.getText().toString(),
                etDeadline.getText().toString(), cbUrgent.isChecked(),
                etSpecialInstructions.getText().toString(), System.currentTimeMillis(), currentTotalPrice, "Pending"
        );

        Intent intent = new Intent(this, PaymentBillingActivity.class);
        intent.putExtra("order_data", order);
        startActivity(intent);
    }

    private String getSelectedItem(Spinner spinner) {
        return spinner.getSelectedItem().toString();
    }
}
