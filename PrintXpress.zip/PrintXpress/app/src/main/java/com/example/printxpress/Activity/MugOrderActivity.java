package com.example.printxpress.Activity;

import android.app.DatePickerDialog;
import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.graphics.Color;
import android.net.Uri;
import android.os.Bundle;
import android.provider.MediaStore;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.FrameLayout;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.RadioGroup;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;

import com.example.printxpress.R;
import com.example.printxpress.models.MugOrder;
import com.github.dhaval2404.colorpicker.ColorPickerDialog;
import com.github.dhaval2404.colorpicker.model.ColorShape;
import com.google.android.material.chip.Chip;
import com.google.android.material.chip.ChipGroup;
import com.google.android.material.textfield.TextInputLayout;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.storage.FirebaseStorage;
import com.google.firebase.storage.StorageReference;

import java.io.ByteArrayOutputStream;
import java.util.Calendar;
import java.util.UUID;

public class MugOrderActivity extends AppCompatActivity {

    private static final String TAG = "MugOrderActivity";
    private static final int PICK_IMAGE_REQUEST = 1;

    private ImageView ivPreviewMug, ivUserDesignPreview, ivUploadedDesign;
    private TextView tvQuantity, tvTotalPrice;
    private EditText etPrintText, etAddress, etSpecialInstructions;
    private ChipGroup cgMugType, cgMugSize, cgMugColor, cgDesignStyle, cgPlacement, cgPrintType, cgBgTheme, cgUsage, cgPackaging;
    private CheckBox cbUrgent;
    private Button btnUploadImage, btnDeadlineDate, btnPlaceOrder;
    private ImageButton btnAdd, btnMinus;
    private RadioGroup rgDelivery;
    private TextInputLayout tilDeliveryAddress;
    private FrameLayout previewLayoutContainer;
    private Toolbar toolbar;

    private Uri filePath;
    private String deadlineDate = "";
    private int quantity = 1;
    private double currentTotalPrice = 0;
    private String customBgColor = "#FFFFFF";
    private int selectedMugColor = Color.WHITE;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_mug_order);

        initViews();
        setupToolbar();
        setupListeners();

        updateTotal();
        updateMugPreview();
    }

    private void initViews() {
        previewLayoutContainer = findViewById(R.id.previewLayoutContainer);
        ivPreviewMug = findViewById(R.id.ivPreviewMug);
        ivUserDesignPreview = findViewById(R.id.ivUserDesignPreview);
        ivUploadedDesign = findViewById(R.id.ivUploadedDesign);

        tvQuantity = findViewById(R.id.tvQuantity);
        tvTotalPrice = findViewById(R.id.tvTotalPrice);
        etPrintText = findViewById(R.id.etPrintText);
        etAddress = findViewById(R.id.etAddress);
        etSpecialInstructions = findViewById(R.id.etSpecialInstructions);
        
        cgMugType = findViewById(R.id.cgMugType);
        cgMugSize = findViewById(R.id.cgMugSize);
        cgMugColor = findViewById(R.id.cgMugColor);
        cgDesignStyle = findViewById(R.id.cgDesignStyle);
        cgPlacement = findViewById(R.id.cgPlacement);
        cgPrintType = findViewById(R.id.cgPrintType);
        cgBgTheme = findViewById(R.id.cgBgTheme);
        cgUsage = findViewById(R.id.cgUsage);
        cgPackaging = findViewById(R.id.cgPackaging);

        btnAdd = findViewById(R.id.btnAdd);
        btnMinus = findViewById(R.id.btnMinus);
        cbUrgent = findViewById(R.id.cbUrgent);
        btnUploadImage = findViewById(R.id.btnUploadImage);
        btnDeadlineDate = findViewById(R.id.btnDeadlineDate);
        btnPlaceOrder = findViewById(R.id.btnPlaceOrder);
        rgDelivery = findViewById(R.id.rgDelivery);
        tilDeliveryAddress = findViewById(R.id.tilDeliveryAddress);
    }

    private void setupToolbar() {
        toolbar = findViewById(R.id.toolbar);
        if (toolbar != null) {
            setSupportActionBar(toolbar);
            if (getSupportActionBar() != null) getSupportActionBar().setDisplayHomeAsUpEnabled(true);
            toolbar.setNavigationOnClickListener(v -> finish());
        }
    }

    private void setupListeners() {
        btnAdd.setOnClickListener(v -> {
            quantity++;
            tvQuantity.setText(String.valueOf(quantity));
            updateTotal();
        });

        btnMinus.setOnClickListener(v -> {
            if (quantity > 1) {
                quantity--;
                tvQuantity.setText(String.valueOf(quantity));
                updateTotal();
            }
        });

        cgMugType.setOnCheckedChangeListener((group, checkedId) -> {
            updateMugPreview();
            updateTotal();
        });

        cgMugColor.setOnCheckedChangeListener((group, checkedId) -> {
            if (checkedId == R.id.chipColored) {
                showMugColorPickerDialog();
            } else {
                updateMugColorValue(checkedId);
            }
            updateTotal();
        });

        ChipGroup.OnCheckedChangeListener priceListener = (group, checkedId) -> updateTotal();
        cgMugSize.setOnCheckedChangeListener(priceListener);
        cgPlacement.setOnCheckedChangeListener(priceListener);
        cgPrintType.setOnCheckedChangeListener(priceListener);
        cgPackaging.setOnCheckedChangeListener(priceListener);

        cgBgTheme.setOnCheckedChangeListener((group, checkedId) -> {
            if (checkedId == R.id.chipCustomBg) {
                showColorPickerDialog();
            }
            updateTotal();
        });

        rgDelivery.setOnCheckedChangeListener((group, checkedId) -> {
            tilDeliveryAddress.setVisibility(checkedId == R.id.rbDelivery ? View.VISIBLE : View.GONE);
            updateTotal();
        });

        btnUploadImage.setOnClickListener(v -> chooseImage());
        btnDeadlineDate.setOnClickListener(v -> showDatePicker());
        cbUrgent.setOnCheckedChangeListener((bv, is) -> updateTotal());
        btnPlaceOrder.setOnClickListener(v -> validateAndProceedToPayment());
    }

    private void showMugColorPickerDialog() {
        new ColorPickerDialog.Builder(this)
                .setTitle("Choose Mug Color")
                .setColorShape(ColorShape.SQAURE)
                .setDefaultColor(selectedMugColor)
                .setColorListener((color, colorHex) -> {
                    selectedMugColor = color;
                    Toast.makeText(this, "Selected color: " + colorHex, Toast.LENGTH_SHORT).show();
                })
                .show();
    }

    private void updateMugColorValue(int checkedId) {
        if (checkedId == R.id.chipWhite) {
            selectedMugColor = Color.WHITE;
        } else if (checkedId == R.id.chipBlack) {
            selectedMugColor = Color.BLACK;
        }
    }

    private void updateMugPreview() {
        int checkedId = cgMugType.getCheckedChipId();
        if (checkedId == R.id.chipNormalMug) {
            ivPreviewMug.setImageResource(R.drawable.normal2);
        } else if (checkedId == R.id.chipMagicMug) {
            ivPreviewMug.setImageResource(R.drawable.magicmug);
        } else if (checkedId == R.id.chipColorMug) {
            ivPreviewMug.setImageResource(R.drawable.colormug2);
        } else if (checkedId == R.id.chipTravelMug) {
            ivPreviewMug.setImageResource(R.drawable.travellingmug);
        } else if (checkedId == R.id.chipGlassMug) {
            ivPreviewMug.setImageResource(R.drawable.glass);
        } else if (checkedId == R.id.chipFrostedMug) {
            ivPreviewMug.setImageResource(R.drawable.frostedglassmug);
        } else if (checkedId == R.id.chipMetallicMug) {
            ivPreviewMug.setImageResource(R.drawable.metalicmug);
        } else if (checkedId == R.id.chipSpoonMug) {
            ivPreviewMug.setImageResource(R.drawable.spoonmug2);
        }
    }

    private void showColorPickerDialog() {
        new ColorPickerDialog.Builder(this)
                .setTitle("Choose Background Color")
                .setColorShape(ColorShape.SQAURE)
                .setDefaultColor(Color.WHITE)
                .setColorListener((color, colorHex) -> {
                    customBgColor = colorHex;
                    Toast.makeText(this, "Selected: " + colorHex, Toast.LENGTH_SHORT).show();
                })
                .show();
    }

    private void updateTotal() {
        double unitPrice = 850.0; // Base Price

        String mugType = getSelectedChipText(cgMugType);
        if (mugType.contains("Magic")) unitPrice += 400;
        else if (mugType.contains("Travel")) unitPrice += 600;
        else if (mugType.contains("Metalic")) unitPrice += 750;

        String size = getSelectedChipText(cgMugSize);
        if (size.contains("500ml")) unitPrice += 200;

        String pack = getSelectedChipText(cgPackaging);
        if (pack.contains("box")) unitPrice += 150;

        currentTotalPrice = quantity * unitPrice;

        if (rgDelivery.getCheckedRadioButtonId() == R.id.rbDelivery) currentTotalPrice += 300;
        if (cbUrgent.isChecked()) currentTotalPrice += 400;

        tvTotalPrice.setText("Estimated Price: Rs " + String.format("%.2f", currentTotalPrice));
    }

    private void chooseImage() {
        Intent intent = new Intent(Intent.ACTION_GET_CONTENT);
        intent.setType("image/*");
        startActivityForResult(Intent.createChooser(intent, "Select Photo"), PICK_IMAGE_REQUEST);
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == PICK_IMAGE_REQUEST && resultCode == RESULT_OK && data != null && data.getData() != null) {
            filePath = data.getData();
            Toast.makeText(this, "Photo selected successfully!", Toast.LENGTH_SHORT).show();
        }
    }

    private void showDatePicker() {
        final Calendar c = Calendar.getInstance();
        new DatePickerDialog(this, (v, y, m, d) -> {
            deadlineDate = d + "/" + (m + 1) + "/" + y;
            btnDeadlineDate.setText(deadlineDate);
        }, c.get(Calendar.YEAR), c.get(Calendar.MONTH), c.get(Calendar.DAY_OF_MONTH)).show();
    }

    private void validateAndProceedToPayment() {
        if (rgDelivery.getCheckedRadioButtonId() == R.id.rbDelivery && etAddress.getText().toString().isEmpty()) {
            Toast.makeText(this, "Enter delivery address", Toast.LENGTH_SHORT).show();
            return;
        }
        uploadData();
    }

    private void uploadData() {
        String orderId = UUID.randomUUID().toString();

        MugOrder order = new MugOrder(
                orderId, FirebaseAuth.getInstance().getUid(), "Mug", quantity,
                getSelectedChipText(cgUsage), getSelectedChipText(cgMugType), getSelectedChipText(cgMugSize),
                getSelectedChipText(cgMugColor), etPrintText.getText().toString(),
                getSelectedChipText(cgDesignStyle), getSelectedChipText(cgPlacement),
                getSelectedChipText(cgPrintType), 
                (cgBgTheme.getCheckedChipId() == R.id.chipCustomBg) ? customBgColor : getSelectedChipText(cgBgTheme),
                getSelectedChipText(cgPackaging),
                (rgDelivery.getCheckedRadioButtonId() == R.id.rbPickup) ? "Pickup" : "Delivery",
                etAddress.getText().toString(), deadlineDate, cbUrgent.isChecked(),
                etSpecialInstructions.getText().toString(), "Pending", System.currentTimeMillis()
        );
        order.setTotalPrice(currentTotalPrice);

        Bitmap finalBitmap = getBitmapFromView(previewLayoutContainer);
        ByteArrayOutputStream baos = new ByteArrayOutputStream();
        finalBitmap.compress(Bitmap.CompressFormat.PNG, 100, baos);
        byte[] data = baos.toByteArray();

        StorageReference sRef = FirebaseStorage.getInstance().getReference("Designs/" + orderId + "_mug.png");
        sRef.putBytes(data).addOnSuccessListener(taskSnapshot -> sRef.getDownloadUrl().addOnSuccessListener(uri -> {
            order.setDesignUrl(uri.toString());
            proceedToPayment(order);
        })).addOnFailureListener(e -> proceedToPayment(order));
    }

    private void proceedToPayment(MugOrder order) {
        Intent intent = new Intent(this, PaymentBillingActivity.class);
        intent.putExtra("order_data", order);
        startActivity(intent);
    }

    private String getSelectedChipText(ChipGroup cg) {
        int id = cg.getCheckedChipId();
        return (id != View.NO_ID) ? ((Chip) findViewById(id)).getText().toString() : "";
    }

    private Bitmap getBitmapFromView(View view) {
        Bitmap bitmap = Bitmap.createBitmap(view.getWidth(), view.getHeight(), Bitmap.Config.ARGB_8888);
        Canvas canvas = new Canvas(bitmap);
        view.draw(canvas);
        return bitmap;
    }
}
