package com.example.printxpress.models;

public class StickerOrder implements BaseOrder {
    private String orderId;
    private String userId;
    private String title;
    private String purpose;
    private String language;
    private String size;
    private String customSize;
    private String shape;
    private String customShape;
    private String textContent;
    private String logoBase64;
    private String designFileBase64;
    private String material;
    private String finish;
    private String cutType;
    private String colorType;
    private String quantity;
    private String usageType;
    private String deliveryType;
    private String address;
    private String deadline;
    private boolean isUrgent;
    private String specialInstructions;
    private long timestamp;
    private double totalPrice;
    private String status;

    public StickerOrder() {}

    public StickerOrder(String orderId, String userId, String title, String purpose, String language, String size, String customSize, String shape, String customShape, String textContent, String logoBase64, String designFileBase64, String material, String finish, String cutType, String colorType, String quantity, String usageType, String deliveryType, String address, String deadline, boolean isUrgent, String specialInstructions, long timestamp, double totalPrice, String status) {
        this.orderId = orderId;
        this.userId = userId;
        this.title = title;
        this.purpose = purpose;
        this.language = language;
        this.size = size;
        this.customSize = customSize;
        this.shape = shape;
        this.customShape = customShape;
        this.textContent = textContent;
        this.logoBase64 = logoBase64;
        this.designFileBase64 = designFileBase64;
        this.material = material;
        this.finish = finish;
        this.cutType = cutType;
        this.colorType = colorType;
        this.quantity = quantity;
        this.usageType = usageType;
        this.deliveryType = deliveryType;
        this.address = address;
        this.deadline = deadline;
        this.isUrgent = isUrgent;
        this.specialInstructions = specialInstructions;
        this.timestamp = timestamp;
        this.totalPrice = totalPrice;
        this.status = status;
    }

    @Override
    public String getProductType() { return "Sticker: " + title; }

    @Override
    public String getOrderSummary() {
        return "Size: " + size + " | Shape: " + shape + " | Qty: " + quantity;
    }

    @Override
    public String getPhotoUrl() { return null; }

    @Override
    public String getBase64Image() {
        return (designFileBase64 != null && !designFileBase64.isEmpty()) ? designFileBase64 : logoBase64;
    }

    public String getOrderId() { return orderId; }
    public void setOrderId(String orderId) { this.orderId = orderId; }
    public String getUserId() { return userId; }
    public void setUserId(String userId) { this.userId = userId; }
    public String getTitle() { return title; }
    public void setTitle(String title) { this.title = title; }
    public String getPurpose() { return purpose; }
    public void setPurpose(String purpose) { this.purpose = purpose; }
    public String getLanguage() { return language; }
    public void setLanguage(String language) { this.language = language; }
    public String getSize() { return size; }
    public void setSize(String size) { this.size = size; }
    public String getCustomSize() { return customSize; }
    public void setCustomSize(String customSize) { this.customSize = customSize; }
    public String getShape() { return shape; }
    public void setShape(String shape) { this.shape = shape; }
    public String getCustomShape() { return customShape; }
    public void setCustomShape(String customShape) { this.customShape = customShape; }
    public String getTextContent() { return textContent; }
    public void setTextContent(String textContent) { this.textContent = textContent; }
    public String getLogoBase64() { return logoBase64; }
    public void setLogoBase64(String logoBase64) { this.logoBase64 = logoBase64; }
    public String getDesignFileBase64() { return designFileBase64; }
    public void setDesignFileBase64(String designFileBase64) { this.designFileBase64 = designFileBase64; }
    public String getMaterial() { return material; }
    public void setMaterial(String material) { this.material = material; }
    public String getFinish() { return finish; }
    public void setFinish(String finish) { this.finish = finish; }
    public String getCutType() { return cutType; }
    public void setCutType(String cutType) { this.cutType = cutType; }
    public String getColorType() { return colorType; }
    public void setColorType(String colorType) { this.colorType = colorType; }
    public String getQuantity() { return quantity; }
    public void setQuantity(String quantity) { this.quantity = quantity; }
    public String getUsageType() { return usageType; }
    public void setUsageType(String usageType) { this.usageType = usageType; }
    public String getDeliveryType() { return deliveryType; }
    public void setDeliveryType(String deliveryType) { this.deliveryType = deliveryType; }
    public String getAddress() { return address; }
    public void setAddress(String address) { this.address = address; }
    public String getDeadline() { return deadline; }
    public void setDeadline(String deadline) { this.deadline = deadline; }
    public boolean isUrgent() { return isUrgent; }
    public void setUrgent(boolean urgent) { isUrgent = urgent; }
    public String getSpecialInstructions() { return specialInstructions; }
    public void setSpecialInstructions(String specialInstructions) { this.specialInstructions = specialInstructions; }
    public long getTimestamp() { return timestamp; }
    public void setTimestamp(long timestamp) { this.timestamp = timestamp; }
    public double getTotalPrice() { return totalPrice; }
    public void setTotalPrice(double totalPrice) { this.totalPrice = totalPrice; }
    public String getStatus() { return status; }
    public void setStatus(String status) { this.status = status; }
}
