package com.example.printxpress.Activity;

import android.app.DatePickerDialog;
import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.Color;
import android.net.Uri;
import android.os.Bundle;
import android.provider.MediaStore;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.FrameLayout;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.RadioGroup;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;

import com.example.printxpress.R;
import com.example.printxpress.models.KeychainOrder;
import com.github.dhaval2404.colorpicker.ColorPickerDialog;
import com.github.dhaval2404.colorpicker.model.ColorShape;
import com.google.android.material.chip.Chip;
import com.google.android.material.chip.ChipGroup;
import com.google.android.material.chip.ChipGroup.OnCheckedChangeListener;
import com.google.android.material.textfield.TextInputEditText;
import com.google.android.material.textfield.TextInputLayout;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.storage.FirebaseStorage;
import com.google.firebase.storage.StorageReference;

import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.util.Calendar;
import java.util.UUID;

public class KeychainOrderActivity extends AppCompatActivity {

    private static final String TAG = "KeychainOrderActivity";
    private static final int PICK_IMAGE_REQUEST = 1;

    private ChipGroup cgKeychainType, cgShape, cgSize, cgMaterial, cgAttachment, cgPrintType, cgUsage, cgPackaging;
    private TextInputEditText etTextMessage, etFontStyle, etBackgroundColor, etTextColor, etAddress, etSpecialInstructions;
    private TextInputLayout tilDeliveryAddress;
    private Button btnUploadImage, btnPlaceOrder, btnDeadlineDate;
    private ImageButton btnAdd, btnMinus;
    private TextView tvQuantity, tvTotalPrice;
    private ImageView ivPreviewKeychain, ivUserDesignPreview, ivUploadedDesign;
    private FrameLayout previewLayoutContainer;
    private RadioGroup rgDelivery;
    private CheckBox cbUrgent;
    private Toolbar toolbar;

    private Uri imageUri;
    private int quantity = 1;
    private double currentTotalPrice = 150.0;
    private String deadlineDate = "";
    private int selectedBgColor = Color.WHITE;
    private int selectedTextColor = Color.BLACK;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_keychain_order);

        initViews();
        setupToolbar();
        setupListeners();
        updateTotal();
        updateKeychainPreview();
    }

    private void initViews() {
        toolbar = findViewById(R.id.toolbar);
        previewLayoutContainer = findViewById(R.id.previewLayoutContainer);
        cgKeychainType = findViewById(R.id.cgKeychainType);
        cgShape = findViewById(R.id.cgShape);
        cgSize = findViewById(R.id.cgSize);
        cgMaterial = findViewById(R.id.cgMaterial);
        cgAttachment = findViewById(R.id.cgAttachment);
        cgPrintType = findViewById(R.id.cgPrintType);
        cgUsage = findViewById(R.id.cgUsage);
        cgPackaging = findViewById(R.id.cgPackaging);

        etTextMessage = findViewById(R.id.etTextMessage);
        etFontStyle = findViewById(R.id.etFontStyle);
        etBackgroundColor = findViewById(R.id.etBackgroundColor);
        etTextColor = findViewById(R.id.etTextColor);
        etAddress = findViewById(R.id.etAddress);
        etSpecialInstructions = findViewById(R.id.etSpecialInstructions);
        tilDeliveryAddress = findViewById(R.id.tilDeliveryAddress);

        btnUploadImage = findViewById(R.id.btnUploadImage);
        btnPlaceOrder = findViewById(R.id.btnPlaceOrder);
        btnAdd = findViewById(R.id.btnAdd);
        btnMinus = findViewById(R.id.btnMinus);
        btnDeadlineDate = findViewById(R.id.btnDeadlineDate);
        tvQuantity = findViewById(R.id.tvQuantity);
        tvTotalPrice = findViewById(R.id.tvTotalPrice);
        ivPreviewKeychain = findViewById(R.id.ivPreviewKeychain);
        ivUserDesignPreview = findViewById(R.id.ivUserDesignPreview);
        ivUploadedDesign = findViewById(R.id.ivUploadedDesign);
        rgDelivery = findViewById(R.id.rgDelivery);
        cbUrgent = findViewById(R.id.cbUrgent);
    }

    private void setupToolbar() {
        if (toolbar != null) {
            setSupportActionBar(toolbar);
            if (getSupportActionBar() != null) {
                getSupportActionBar().setDisplayHomeAsUpEnabled(true);
            }
            toolbar.setNavigationOnClickListener(v -> finish());
        }
    }

    private void setupListeners() {
        btnAdd.setOnClickListener(v -> {
            quantity++;
            tvQuantity.setText(String.valueOf(quantity));
            updateTotal();
        });

        btnMinus.setOnClickListener(v -> {
            if (quantity > 1) {
                quantity--;
                tvQuantity.setText(String.valueOf(quantity));
                updateTotal();
            }
        });

        btnUploadImage.setOnClickListener(v -> chooseImage());
        btnDeadlineDate.setOnClickListener(v -> showDatePicker());
        etBackgroundColor.setOnClickListener(v -> showColorPicker(true));
        etTextColor.setOnClickListener(v -> showColorPicker(false));

        rgDelivery.setOnCheckedChangeListener((group, checkedId) -> {
            tilDeliveryAddress.setVisibility(checkedId == R.id.rbDelivery ? View.VISIBLE : View.GONE);
            updateTotal();
        });

        cbUrgent.setOnCheckedChangeListener((buttonView, isChecked) -> updateTotal());

        cgKeychainType.setOnCheckedChangeListener((group, checkedId) -> {
            updateKeychainPreview();
            updateTotal();
        });

        OnCheckedChangeListener priceChangeListener = (group, checkedId) -> updateTotal();
        cgSize.setOnCheckedChangeListener(priceChangeListener);
        cgMaterial.setOnCheckedChangeListener(priceChangeListener);
        cgPackaging.setOnCheckedChangeListener(priceChangeListener);

        btnPlaceOrder.setOnClickListener(v -> validateAndProceedToPayment());
    }

    private void updateKeychainPreview() {
        int checkedId = cgKeychainType.getCheckedChipId();
        if (checkedId == R.id.chipPhoto) ivPreviewKeychain.setImageResource(R.drawable.photokey);
        else if (checkedId == R.id.chipLED) ivPreviewKeychain.setImageResource(R.drawable.ledkey2);
        else if (checkedId == R.id.chipName) ivPreviewKeychain.setImageResource(R.drawable.namelogo2);
        else if (checkedId == R.id.chipLogo) ivPreviewKeychain.setImageResource(R.drawable.logokey2);
        else if (checkedId == R.id.chipBottleOpener) ivPreviewKeychain.setImageResource(R.drawable.bottle);
        else ivPreviewKeychain.setImageResource(R.drawable.key);
    }

    private void chooseImage() {
        Intent intent = new Intent(Intent.ACTION_GET_CONTENT);
        intent.setType("image/*");
        startActivityForResult(Intent.createChooser(intent, "Select Photo"), PICK_IMAGE_REQUEST);
    }

    private void showDatePicker() {
        final Calendar c = Calendar.getInstance();
        int year = c.get(Calendar.YEAR);
        int month = c.get(Calendar.MONTH);
        int day = c.get(Calendar.DAY_OF_MONTH);

        DatePickerDialog datePickerDialog = new DatePickerDialog(this,
                (view, year1, monthOfYear, dayOfMonth) -> {
                    deadlineDate = dayOfMonth + "/" + (monthOfYear + 1) + "/" + year1;
                    btnDeadlineDate.setText(deadlineDate);
                }, year, month, day);
        datePickerDialog.show();
    }

    private void showColorPicker(boolean isBackground) {
        new ColorPickerDialog.Builder(this)
                .setTitle(isBackground ? "Choose Background Color" : "Choose Text Color")
                .setColorShape(ColorShape.SQAURE)
                .setDefaultColor(isBackground ? selectedBgColor : selectedTextColor)
                .setColorListener((color, colorHex) -> {
                    if (isBackground) {
                        selectedBgColor = color;
                        etBackgroundColor.setText(colorHex);
                        etBackgroundColor.setTextColor(color);
                    } else {
                        selectedTextColor = color;
                        etTextColor.setText(colorHex);
                        etTextColor.setTextColor(color);
                    }
                })
                .show();
    }

    private void updateTotal() {
        double unitPrice = 150.0;
        String material = getSelectedChipText(cgMaterial);
        if (material.contains("Metal")) unitPrice += 100;
        else if (material.contains("Wood")) unitPrice += 50;
        else if (material.contains("Acrylic")) unitPrice += 30;

        String size = getSelectedChipText(cgSize);
        if (size.contains("Medium")) unitPrice += 20;
        else if (size.contains("Large")) unitPrice += 50;

        String pack = getSelectedChipText(cgPackaging);
        if (pack.contains("Gift")) unitPrice += 40;

        String type = getSelectedChipText(cgKeychainType);
        if (type.contains("LED")) unitPrice += 150;

        currentTotalPrice = unitPrice * quantity;
        if (cbUrgent.isChecked()) currentTotalPrice += 100;
        if (rgDelivery.getCheckedRadioButtonId() == R.id.rbDelivery) currentTotalPrice += 50;

        tvTotalPrice.setText("Estimated Price: Rs " + String.format("%.2f", currentTotalPrice));
    }

    private String getSelectedChipText(ChipGroup chipGroup) {
        if (chipGroup == null) return "";
        int checkedId = chipGroup.getCheckedChipId();
        if (checkedId != View.NO_ID) {
            Chip chip = findViewById(checkedId);
            return (chip != null) ? chip.getText().toString() : "";
        }
        return "";
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == PICK_IMAGE_REQUEST && resultCode == RESULT_OK && data != null && data.getData() != null) {
            imageUri = data.getData();
            // Removed image preview as requested
            Toast.makeText(this, "Design selected successfully!", Toast.LENGTH_SHORT).show();
        }
    }

    private void validateAndProceedToPayment() {
        FirebaseUser user = FirebaseAuth.getInstance().getCurrentUser();
        if (user == null) {
            Toast.makeText(this, "Please login first!", Toast.LENGTH_SHORT).show();
            return;
        }

        if (rgDelivery.getCheckedRadioButtonId() == R.id.rbDelivery && etAddress.getText().toString().trim().isEmpty()) {
            Toast.makeText(this, "Please enter your delivery address", Toast.LENGTH_SHORT).show();
            return;
        }
        if (deadlineDate.isEmpty()) {
            Toast.makeText(this, "Please select a required deadline date", Toast.LENGTH_SHORT).show();
            return;
        }
        uploadData();
    }

    private void uploadData() {
        btnPlaceOrder.setEnabled(false);
        String orderId = UUID.randomUUID().toString();
        
        if (imageUri == null) {
            proceedToPayment(orderId, "");
            return;
        }

        Toast.makeText(this, "Uploading image...", Toast.LENGTH_SHORT).show();
        // Simplified path reference
        StorageReference sRef = FirebaseStorage.getInstance().getReference("Designs/" + orderId + "_keychain.png");

        try {
            Bitmap bitmap = MediaStore.Images.Media.getBitmap(getContentResolver(), imageUri);
            ByteArrayOutputStream baos = new ByteArrayOutputStream();
            bitmap.compress(Bitmap.CompressFormat.PNG, 100, baos);
            byte[] data = baos.toByteArray();

            sRef.putBytes(data)
                .addOnSuccessListener(taskSnapshot -> {
                    sRef.getDownloadUrl().addOnSuccessListener(downloadUri -> {
                        proceedToPayment(orderId, downloadUri.toString());
                    }).addOnFailureListener(e -> {
                        Log.e(TAG, "URL Fetch failed: " + e.getMessage());
                        // Even if URL fetch fails, proceed with order (URL can be retrieved later if needed)
                        proceedToPayment(orderId, "");
                    });
                })
                .addOnFailureListener(e -> {
                    btnPlaceOrder.setEnabled(true);
                    Log.e(TAG, "Upload failed: " + e.getMessage());
                    // If it still fails, it might be a Firebase setup issue, but let's try to proceed without the image if necessary
                    Toast.makeText(this, "Upload failed. Checking connection...", Toast.LENGTH_SHORT).show();
                    proceedToPayment(orderId, ""); 
                });

        } catch (IOException e) {
            btnPlaceOrder.setEnabled(true);
            Log.e(TAG, "Bitmap Processing failed: " + e.getMessage());
            proceedToPayment(orderId, "");
        }
    }

    private void proceedToPayment(String orderId, String photoUrl) {
        String userId = FirebaseAuth.getInstance().getCurrentUser().getUid();
        KeychainOrder order = new KeychainOrder(
                orderId, userId, "Keychain", getSelectedChipText(cgKeychainType), getSelectedChipText(cgShape),
                getSelectedChipText(cgSize), getSelectedChipText(cgMaterial), getSelectedChipText(cgAttachment),
                getSelectedChipText(cgPrintType), etTextMessage.getText().toString().trim(), etFontStyle.getText().toString().trim(),
                etBackgroundColor.getText().toString().trim(), etTextColor.getText().toString().trim(),
                photoUrl, quantity, getSelectedChipText(cgUsage), getSelectedChipText(cgPackaging),
                (rgDelivery.getCheckedRadioButtonId() == R.id.rbPickup) ? "Pickup" : "Delivery",
                etAddress.getText().toString().trim(), deadlineDate, cbUrgent.isChecked(),
                etSpecialInstructions.getText().toString().trim(), currentTotalPrice, "Pending", System.currentTimeMillis()
        );

        Intent intent = new Intent(this, PaymentBillingActivity.class);
        intent.putExtra("order_data", order);
        startActivity(intent);
    }
}
