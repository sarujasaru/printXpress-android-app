package com.example.printxpress.Firebase;

import com.example.printxpress.models.User;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.AuthResult;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.Query;
import com.google.firebase.storage.FirebaseStorage;
import com.google.firebase.storage.StorageReference;

public class FirebaseHelper {
    private FirebaseAuth mAuth;
    private DatabaseReference mDatabase;
    private FirebaseStorage mStorage;

    public FirebaseHelper() {
        mAuth = FirebaseAuth.getInstance();
        mDatabase = FirebaseDatabase.getInstance().getReference();
        mStorage = FirebaseStorage.getInstance();
    }

    public Task<AuthResult> registerUser(String email, String password) {
        return mAuth.createUserWithEmailAndPassword(email, password);
    }

    public Task<Void> saveUserDetails(User user) {
        return mDatabase.child("Users").child(user.getUid()).setValue(user);
    }

    public Task<AuthResult> loginUser(String email, String password) {
        return mAuth.signInWithEmailAndPassword(email, password);
    }

    public Task<Void> sendPasswordResetEmail(String email) {
        return mAuth.sendPasswordResetEmail(email);
    }

    public FirebaseUser getCurrentUser() {
        return mAuth.getCurrentUser();
    }

    public DatabaseReference getUserReference(String uid) {
        return mDatabase.child("Users").child(uid);
    }

    public DatabaseReference getUsersRootReference() {
        return mDatabase.child("Users");
    }

    public Query getOrdersReference(String uid) {
        return mDatabase.child("Orders").orderByChild("userId").equalTo(uid);
    }

    public Query getBookingsReference(String uid) {
        return mDatabase.child("Bookings").orderByChild("userId").equalTo(uid);
    }

    public Query getNotificationsReference() {
        return mDatabase.child("Notification").orderByChild("timestamp");
    }

    public DatabaseReference getOffersReference() {
        return mDatabase.child("Offers");
    }

    public StorageReference getStorageReference() {
        return mStorage.getReference();
    }

    public void logout() {
        mAuth.signOut();
    }
}
