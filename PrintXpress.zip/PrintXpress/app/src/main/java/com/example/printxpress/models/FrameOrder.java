package com.example.printxpress.models;

public class FrameOrder implements BaseOrder {
    private String orderId;
    private String userId;
    private String productType;
    private int quantity;
    private String usage;
    private String frameSize;
    private String frameType;
    private String frameMaterial;
    private String frameColor;
    private String photoUrl;
    private String designStyle;
    private String layoutPreference;
    private String backgroundStyle;
    private String textMessage;
    private String glassType;
    private String orientation;
    private String packaging;
    private String deliveryType;
    private String address;
    private String deadline;
    private boolean isUrgent;
    private double totalPrice;
    private String status;
    private long timestamp;

    public FrameOrder() {}

    public FrameOrder(String orderId, String userId, String productType, int quantity, String usage, 
                      String frameSize, String frameType, String frameMaterial, String frameColor, 
                      String photoUrl, String designStyle, String layoutPreference, String backgroundStyle, 
                      String textMessage, String glassType, String orientation, String packaging, 
                      String deliveryType, String address, String deadline, boolean isUrgent, 
                      double totalPrice, String status, long timestamp) {
        this.orderId = orderId;
        this.userId = userId;
        this.productType = productType;
        this.quantity = quantity;
        this.usage = usage;
        this.frameSize = frameSize;
        this.frameType = frameType;
        this.frameMaterial = frameMaterial;
        this.frameColor = frameColor;
        this.photoUrl = photoUrl;
        this.designStyle = designStyle;
        this.layoutPreference = layoutPreference;
        this.backgroundStyle = backgroundStyle;
        this.textMessage = textMessage;
        this.glassType = glassType;
        this.orientation = orientation;
        this.packaging = packaging;
        this.deliveryType = deliveryType;
        this.address = address;
        this.deadline = deadline;
        this.isUrgent = isUrgent;
        this.totalPrice = totalPrice;
        this.status = status;
        this.timestamp = timestamp;
    }

    @Override
    public String getProductType() { return productType; }

    @Override
    public String getOrderSummary() {
        return "Size: " + frameSize + " | Type: " + frameType + " | Qty: " + quantity;
    }

    @Override
    public String getPhotoUrl() { return photoUrl; }

    @Override
    public String getBase64Image() { return null; }

    // Getters and Setters
    public String getOrderId() { return orderId; }
    public void setOrderId(String orderId) { this.orderId = orderId; }

    public String getUserId() { return userId; }
    public void setUserId(String userId) { this.userId = userId; }

    public void setProductType(String productType) { this.productType = productType; }

    public int getQuantity() { return quantity; }
    public void setQuantity(int quantity) { this.quantity = quantity; }

    public String getUsage() { return usage; }
    public void setUsage(String usage) { this.usage = usage; }

    public String getFrameSize() { return frameSize; }
    public void setFrameSize(String frameSize) { this.frameSize = frameSize; }

    public String getFrameType() { return frameType; }
    public void setFrameType(String frameType) { this.frameType = frameType; }

    public String getFrameMaterial() { return frameMaterial; }
    public void setFrameMaterial(String frameMaterial) { this.frameMaterial = frameMaterial; }

    public String getFrameColor() { return frameColor; }
    public void setFrameColor(String frameColor) { this.frameColor = frameColor; }

    public void setPhotoUrl(String photoUrl) { this.photoUrl = photoUrl; }

    public String getDesignStyle() { return designStyle; }
    public void setDesignStyle(String designStyle) { this.designStyle = designStyle; }

    public String getLayoutPreference() { return layoutPreference; }
    public void setLayoutPreference(String layoutPreference) { this.layoutPreference = layoutPreference; }

    public String getBackgroundStyle() { return backgroundStyle; }
    public void setBackgroundStyle(String backgroundStyle) { this.backgroundStyle = backgroundStyle; }

    public String getTextMessage() { return textMessage; }
    public void setTextMessage(String textMessage) { this.textMessage = textMessage; }

    public String getGlassType() { return glassType; }
    public void setGlassType(String glassType) { this.glassType = glassType; }

    public String getOrientation() { return orientation; }
    public void setOrientation(String orientation) { this.orientation = orientation; }

    public String getPackaging() { return packaging; }
    public void setPackaging(String packaging) { this.packaging = packaging; }

    public String getDeliveryType() { return deliveryType; }
    public void setDeliveryType(String deliveryType) { this.deliveryType = deliveryType; }

    public String getAddress() { return address; }
    public void setAddress(String address) { this.address = address; }

    public String getDeadline() { return deadline; }
    public void setDeadline(String deadline) { this.deadline = deadline; }

    public boolean isUrgent() { return isUrgent; }
    public void setUrgent(boolean urgent) { isUrgent = urgent; }

    public double getTotalPrice() { return totalPrice; }
    public void setTotalPrice(double totalPrice) { this.totalPrice = totalPrice; }

    public String getStatus() { return status; }
    public void setStatus(String status) { this.status = status; }

    public long getTimestamp() { return timestamp; }
    public void setTimestamp(long timestamp) { this.timestamp = timestamp; }
}
