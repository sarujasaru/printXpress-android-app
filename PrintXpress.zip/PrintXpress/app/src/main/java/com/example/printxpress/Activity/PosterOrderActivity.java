package com.example.printxpress.Activity;

import android.app.DatePickerDialog;
import android.app.TimePickerDialog;
import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.net.Uri;
import android.os.Bundle;
import android.text.Editable;
import android.text.TextWatcher;
import android.util.Base64;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.RadioGroup;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

import androidx.activity.result.ActivityResultLauncher;
import androidx.activity.result.contract.ActivityResultContracts;
import androidx.appcompat.app.AppCompatActivity;

import com.example.printxpress.Firebase.FirebaseHelper;
import com.example.printxpress.R;
import com.example.printxpress.models.PosterOrder;

import java.io.ByteArrayOutputStream;
import java.io.InputStream;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.List;
import java.util.UUID;

public class PosterOrderActivity extends AppCompatActivity {

    private EditText etTitle, etCustomSize, etMainText, etSubText, etEventDate, etEventTime, etLocation, etContactNumber, etSocialLinks, etColorTheme, etFontStyle, etLanguage, etQuantity, etDeliveryAddress, etDeadlineDate;
    private Spinner spPurpose;
    private RadioGroup rgSize, rgOrientation, rgPrintType, rgDeliveryType;
    private TextView tvPrice;
    private CheckBox cbUrgent;
    private LinearLayout layoutUploadLogo, layoutUploadCustomImages, layoutUploadBgImage, layoutUploadExample;
    private ImageView ivLogoPreview, ivCustomImagesPreview, ivBgImagePreview, ivExamplePreview, ivBack;
    private Button btnOrder;
    private FirebaseHelper firebaseHelper;

    private String logoBase64 = "", customImagesBase64 = "", bgImageBase64 = "", exampleDesignBase64 = "";
    private double currentTotalPrice = 0;

    private final ActivityResultLauncher<Intent> logoPickerLauncher = registerForActivityResult(
            new ActivityResultContracts.StartActivityForResult(),
            result -> {
                if (result.getResultCode() == RESULT_OK && result.getData() != null) {
                    Uri uri = result.getData().getData();
                    ivLogoPreview.setImageURI(uri);
                    ivLogoPreview.setPadding(0, 0, 0, 0);
                    ivLogoPreview.setImageTintList(null);
                    logoBase64 = encodeImageToBase64(uri);
                }
            }
    );

    private final ActivityResultLauncher<Intent> customImagesPickerLauncher = registerForActivityResult(
            new ActivityResultContracts.StartActivityForResult(),
            result -> {
                if (result.getResultCode() == RESULT_OK && result.getData() != null) {
                    Uri uri = result.getData().getData();
                    ivCustomImagesPreview.setImageURI(uri);
                    ivCustomImagesPreview.setPadding(0, 0, 0, 0);
                    ivCustomImagesPreview.setImageTintList(null);
                    customImagesBase64 = encodeImageToBase64(uri);
                }
            }
    );

    private final ActivityResultLauncher<Intent> bgImagePickerLauncher = registerForActivityResult(
            new ActivityResultContracts.StartActivityForResult(),
            result -> {
                if (result.getResultCode() == RESULT_OK && result.getData() != null) {
                    Uri uri = result.getData().getData();
                    ivBgImagePreview.setImageURI(uri);
                    ivBgImagePreview.setPadding(0, 0, 0, 0);
                    ivBgImagePreview.setImageTintList(null);
                    bgImageBase64 = encodeImageToBase64(uri);
                }
            }
    );

    private final ActivityResultLauncher<Intent> examplePickerLauncher = registerForActivityResult(
            new ActivityResultContracts.StartActivityForResult(),
            result -> {
                if (result.getResultCode() == RESULT_OK && result.getData() != null) {
                    Uri uri = result.getData().getData();
                    ivExamplePreview.setImageURI(uri);
                    ivExamplePreview.setPadding(0, 0, 0, 0);
                    ivExamplePreview.setImageTintList(null);
                    exampleDesignBase64 = encodeImageToBase64(uri);
                }
            }
    );

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_poster_order);

        firebaseHelper = new FirebaseHelper();

        // Initialize Views
        ivBack = findViewById(R.id.ivBack);
        etTitle = findViewById(R.id.etTitle);
        spPurpose = findViewById(R.id.spPurpose);
        rgSize = findViewById(R.id.rgSize);
        etCustomSize = findViewById(R.id.etCustomSize);
        rgOrientation = findViewById(R.id.rgOrientation);
        rgPrintType = findViewById(R.id.rgPrintType);
        tvPrice = findViewById(R.id.tvPrice);
        etMainText = findViewById(R.id.etMainText);
        etSubText = findViewById(R.id.etSubText);
        etEventDate = findViewById(R.id.etEventDate);
        etEventTime = findViewById(R.id.etEventTime);
        etLocation = findViewById(R.id.etLocation);
        etContactNumber = findViewById(R.id.etContactNumber);
        etSocialLinks = findViewById(R.id.etSocialLinks);
        layoutUploadLogo = findViewById(R.id.layoutUploadLogo);
        layoutUploadCustomImages = findViewById(R.id.layoutUploadCustomImages);
        layoutUploadBgImage = findViewById(R.id.layoutUploadBgImage);
        ivLogoPreview = findViewById(R.id.ivLogoPreview);
        ivCustomImagesPreview = findViewById(R.id.ivCustomImagesPreview);
        ivBgImagePreview = findViewById(R.id.ivBgImagePreview);
        etColorTheme = findViewById(R.id.etColorTheme);
        etFontStyle = findViewById(R.id.etFontStyle);
        layoutUploadExample = findViewById(R.id.layoutUploadExample);
        ivExamplePreview = findViewById(R.id.ivExamplePreview);
        etLanguage = findViewById(R.id.etLanguage);
        etQuantity = findViewById(R.id.etQuantity);
        rgDeliveryType = findViewById(R.id.rgDeliveryType);
        etDeliveryAddress = findViewById(R.id.etDeliveryAddress);
        etDeadlineDate = findViewById(R.id.etDeadlineDate);
        cbUrgent = findViewById(R.id.cbUrgent);
        btnOrder = findViewById(R.id.btnOrder);

        ivBack.setOnClickListener(v -> finish());

        setupPurposeSpinner();
        setupPickers();
        setupVisibilityLogic();
        setupImagePickers();
        setupPriceListeners();

        btnOrder.setOnClickListener(v -> validateAndProceedToPayment());
    }

    private void setupPriceListeners() {
        rgSize.setOnCheckedChangeListener((group, checkedId) -> {
            etCustomSize.setVisibility(checkedId == R.id.rbCustomSize ? View.VISIBLE : View.GONE);
            calculatePrice();
        });

        rgPrintType.setOnCheckedChangeListener((group, checkedId) -> calculatePrice());

        cbUrgent.setOnCheckedChangeListener((buttonView, isChecked) -> calculatePrice());

        etQuantity.addTextChangedListener(new TextWatcher() {
            @Override public void beforeTextChanged(CharSequence s, int start, int count, int after) {}
            @Override public void onTextChanged(CharSequence s, int start, int before, int count) { calculatePrice(); }
            @Override public void afterTextChanged(Editable s) {}
        });

        etCustomSize.addTextChangedListener(new TextWatcher() {
            @Override public void beforeTextChanged(CharSequence s, int start, int count, int after) {}
            @Override public void onTextChanged(CharSequence s, int start, int before, int count) { calculatePrice(); }
            @Override public void afterTextChanged(Editable s) {}
        });

        rgDeliveryType.setOnCheckedChangeListener((group, checkedId) -> {
            etDeliveryAddress.setVisibility(checkedId == R.id.rbDelivery ? View.VISIBLE : View.GONE);
            calculatePrice();
        });
    }

    private void calculatePrice() {
        double basePrice = 0;
        int selectedSizeId = rgSize.getCheckedRadioButtonId();
        boolean isColor = rgPrintType.getCheckedRadioButtonId() == R.id.rbColor;

        if (selectedSizeId == R.id.rbA4) {
            basePrice = isColor ? 50 : 20; // LKR Rates
        } else if (selectedSizeId == R.id.rbA3) {
            basePrice = isColor ? 100 : 40; // LKR Rates
        } else if (selectedSizeId == R.id.rbCustomSize) {
            String custom = etCustomSize.getText().toString().toLowerCase();
            if (custom.contains("x")) {
                try {
                    String[] parts = custom.split("x");
                    double area = Double.parseDouble(parts[0].trim()) * Double.parseDouble(parts[1].trim());
                    basePrice = area * (isColor ? 1.50 : 0.50); // Per sq inch LKR
                } catch (Exception e) { basePrice = 0; }
            }
        }

        int qty = 1;
        try { qty = Integer.parseInt(etQuantity.getText().toString()); } catch (Exception e) {}

        currentTotalPrice = basePrice * qty;

        if (rgDeliveryType.getCheckedRadioButtonId() == R.id.rbDelivery) {
            currentTotalPrice += 350; // Delivery fee LKR
        }

        if (cbUrgent.isChecked()) {
            currentTotalPrice += 500; // Urgent fee LKR
        }

        tvPrice.setText("Estimated Price: Rs " + String.format("%.2f", currentTotalPrice));
    }

    private String encodeImageToBase64(Uri uri) {
        try {
            InputStream inputStream = getContentResolver().openInputStream(uri);
            Bitmap bitmap = BitmapFactory.decodeStream(inputStream);
            Bitmap scaledBitmap = scaleBitmap(bitmap, 800); 
            ByteArrayOutputStream outputStream = new ByteArrayOutputStream();
            scaledBitmap.compress(Bitmap.CompressFormat.JPEG, 60, outputStream);
            byte[] byteArray = outputStream.toByteArray();
            return Base64.encodeToString(byteArray, Base64.DEFAULT);
        } catch (Exception e) {
            e.printStackTrace();
            return "";
        }
    }

    private Bitmap scaleBitmap(Bitmap bitmap, int maxSize) {
        int width = bitmap.getWidth();
        int height = bitmap.getHeight();
        float bitmapRatio = (float) width / (float) height;
        if (bitmapRatio > 1) {
            width = maxSize;
            height = (int) (width / bitmapRatio);
        } else {
            height = maxSize;
            width = (int) (height * bitmapRatio);
        }
        return Bitmap.createScaledBitmap(bitmap, width, height, true);
    }

    private void setupPurposeSpinner() {
        List<String> purposes = new ArrayList<>();
        purposes.add("Select Purpose");
        purposes.add("Event");
        purposes.add("Business promotion");
        purposes.add("Birthday / Wedding");
        purposes.add("Offer / Advertisement");
        ArrayAdapter<String> adapter = new ArrayAdapter<>(this, R.layout.spinner_item, purposes);
        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        spPurpose.setAdapter(adapter);
    }

    private void setupPickers() {
        etEventDate.setOnClickListener(v -> showDatePicker(etEventDate));
        etDeadlineDate.setOnClickListener(v -> showDatePicker(etDeadlineDate));
        etEventTime.setOnClickListener(v -> showTimePicker());
    }

    private void showDatePicker(EditText target) {
        Calendar c = Calendar.getInstance();
        new DatePickerDialog(this, (view, year, month, day) -> {
            target.setText(day + "/" + (month + 1) + "/" + year);
        }, c.get(Calendar.YEAR), c.get(Calendar.MONTH), c.get(Calendar.DAY_OF_MONTH)).show();
    }

    private void showTimePicker() {
        Calendar c = Calendar.getInstance();
        new TimePickerDialog(this, (view, hour, minute) -> {
            etEventTime.setText(String.format("%02d:%02d", hour, minute));
        }, c.get(Calendar.HOUR_OF_DAY), c.get(Calendar.MINUTE), true).show();
    }

    private void setupVisibilityLogic() {
        rgSize.setOnCheckedChangeListener((group, checkedId) -> {
            etCustomSize.setVisibility(checkedId == R.id.rbCustomSize ? View.VISIBLE : View.GONE);
        });

        rgDeliveryType.setOnCheckedChangeListener((group, checkedId) -> {
            etDeliveryAddress.setVisibility(checkedId == R.id.rbDelivery ? View.VISIBLE : View.GONE);
        });
    }

    private void setupImagePickers() {
        layoutUploadLogo.setOnClickListener(v -> openGallery(logoPickerLauncher));
        layoutUploadCustomImages.setOnClickListener(v -> openGallery(customImagesPickerLauncher));
        layoutUploadBgImage.setOnClickListener(v -> openGallery(bgImagePickerLauncher));
        layoutUploadExample.setOnClickListener(v -> openGallery(examplePickerLauncher));
    }

    private void openGallery(ActivityResultLauncher<Intent> launcher) {
        Intent intent = new Intent(Intent.ACTION_PICK);
        intent.setType("image/*");
        launcher.launch(intent);
    }

    private void validateAndProceedToPayment() {
        String title = etTitle.getText().toString().trim();
        String purpose = spPurpose.getSelectedItem().toString();
        String qtyStr = etQuantity.getText().toString().trim();

        if (title.isEmpty() || purpose.equals("Select Purpose") || qtyStr.isEmpty()) {
            Toast.makeText(this, "Please fill Title, Purpose and Quantity", Toast.LENGTH_SHORT).show();
            return;
        }

        int sizeId = rgSize.getCheckedRadioButtonId();
        if (sizeId == R.id.rbCustomSize && etCustomSize.getText().toString().trim().isEmpty()) {
            Toast.makeText(this, "Please enter your custom size", Toast.LENGTH_SHORT).show();
            return;
        }

        String userId = firebaseHelper.getCurrentUser() != null ? firebaseHelper.getCurrentUser().getUid() : "anonymous";
        String orderId = UUID.randomUUID().toString();

        String size = "A4";
        if (sizeId == R.id.rbA3) size = "A3";
        else if (sizeId == R.id.rbCustomSize) size = "Custom: " + etCustomSize.getText().toString();

        String orientation = rgOrientation.getCheckedRadioButtonId() == R.id.rbPortrait ? "Portrait" : "Landscape";
        String printType = rgPrintType.getCheckedRadioButtonId() == R.id.rbColor ? "Color" : "Black & White";
        String delivery = rgDeliveryType.getCheckedRadioButtonId() == R.id.rbPickup ? "Pickup" : "Delivery";

        PosterOrder order = new PosterOrder(
                orderId, userId, title, purpose, size, orientation, printType,
                etMainText.getText().toString(), etSubText.getText().toString(),
                etEventDate.getText().toString(), etEventTime.getText().toString(),
                etLocation.getText().toString(), etContactNumber.getText().toString(),
                etSocialLinks.getText().toString(), logoBase64, customImagesBase64,
                bgImageBase64, etColorTheme.getText().toString(),
                etFontStyle.getText().toString(), exampleDesignBase64,
                etLanguage.getText().toString(), qtyStr, delivery,
                etDeliveryAddress.getText().toString(), etDeadlineDate.getText().toString(),
                cbUrgent.isChecked(), "", System.currentTimeMillis(), currentTotalPrice, "Pending"
        );

        Intent intent = new Intent(this, PaymentBillingActivity.class);
        intent.putExtra("order_data", order);
        startActivity(intent);
    }
}
