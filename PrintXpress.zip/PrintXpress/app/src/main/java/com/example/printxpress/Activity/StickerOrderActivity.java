package com.example.printxpress.Activity;

import android.app.DatePickerDialog;
import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.net.Uri;
import android.os.Bundle;
import android.text.Editable;
import android.text.TextWatcher;
import android.util.Base64;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.RadioGroup;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

import androidx.activity.result.ActivityResultLauncher;
import androidx.activity.result.contract.ActivityResultContracts;
import androidx.appcompat.app.AppCompatActivity;

import com.example.printxpress.Firebase.FirebaseHelper;
import com.example.printxpress.R;
import com.example.printxpress.models.StickerOrder;

import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.util.Calendar;
import java.util.Locale;
import java.util.UUID;

public class StickerOrderActivity extends AppCompatActivity {

    private EditText etStickerTitle, etCustomSize, etCustomShape, etTextContent, etQuantity, etDeliveryAddress, etDeadline, etSpecialInstructions;
    private Spinner spPurpose, spLanguage, spMaterial, spFinish, spCutType;
    private RadioGroup rgSize, rgShape, rgColorType, rgUsage, rgDelivery;
    private TextView tvPrice;
    private CheckBox cbUrgent;
    private LinearLayout layoutUploadLogo, layoutUploadDesign;
    private ImageView ivLogoPreview, ivDesignPreview, ivBack;
    private Button btnOrder;

    private FirebaseHelper firebaseHelper;
    private String logoBase64 = "", designBase64 = "";
    private double currentTotalPrice = 0;

    private final ActivityResultLauncher<Intent> logoLauncher = registerForActivityResult(new ActivityResultContracts.StartActivityForResult(), result -> handleImageResult(result, ivLogoPreview, 1));
    private final ActivityResultLauncher<Intent> designLauncher = registerForActivityResult(new ActivityResultContracts.StartActivityForResult(), result -> handleImageResult(result, ivDesignPreview, 2));

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_sticker_order);

        firebaseHelper = new FirebaseHelper();

        initViews();
        setupSpinners();
        setupPickers();
        setupListeners();
    }

    private void initViews() {
        ivBack = findViewById(R.id.ivBack);
        etStickerTitle = findViewById(R.id.etStickerTitle);
        spPurpose = findViewById(R.id.spPurpose);
        spLanguage = findViewById(R.id.spLanguage);
        rgSize = findViewById(R.id.rgSize);
        etCustomSize = findViewById(R.id.etCustomSize);
        rgShape = findViewById(R.id.rgShape);
        etCustomShape = findViewById(R.id.etCustomShape);
        etTextContent = findViewById(R.id.etTextContent);
        layoutUploadLogo = findViewById(R.id.layoutUploadLogo);
        layoutUploadDesign = findViewById(R.id.layoutUploadDesign);
        ivLogoPreview = findViewById(R.id.ivLogoPreview);
        ivDesignPreview = findViewById(R.id.ivDesignPreview);
        spMaterial = findViewById(R.id.spMaterial);
        spFinish = findViewById(R.id.spFinish);
        spCutType = findViewById(R.id.spCutType);
        rgColorType = findViewById(R.id.rgColorType);
        etQuantity = findViewById(R.id.etQuantity);
        rgUsage = findViewById(R.id.rgUsage);
        rgDelivery = findViewById(R.id.rgDelivery);
        etDeliveryAddress = findViewById(R.id.etDeliveryAddress);
        etDeadline = findViewById(R.id.etDeadline);
        cbUrgent = findViewById(R.id.cbUrgent);
        etSpecialInstructions = findViewById(R.id.etSpecialInstructions);
        tvPrice = findViewById(R.id.tvPrice);
        btnOrder = findViewById(R.id.btnOrder);
    }

    private void setupSpinners() {
        String[] purposes = {"Purpose: Select", "Branding (logo sticker)", "Product labeling", "Decoration", "Packaging"};
        String[] languages = {"Language: English", "Language: Tamil", "Language: Both", "No Text"};
        String[] materials = {"Material: Paper", "Material: Vinyl (Waterproof)", "Material: Transparent", "Material: Holographic"};
        String[] finishes = {"Finish: Matte", "Finish: Glossy", "Finish: Laminated"};
        String[] cutTypes = {"Cut Type: Kiss cut", "Cut Type: Die cut", "Cut Type: Sheet cut"};

        setupSpinner(spPurpose, purposes);
        setupSpinner(spLanguage, languages);
        setupSpinner(spMaterial, materials);
        setupSpinner(spFinish, finishes);
        setupSpinner(spCutType, cutTypes);
    }

    private void setupSpinner(Spinner spinner, String[] items) {
        ArrayAdapter<String> adapter = new ArrayAdapter<>(this, R.layout.spinner_item, items);
        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        spinner.setAdapter(adapter);
    }

    private void setupPickers() {
        etDeadline.setOnClickListener(v -> {
            Calendar c = Calendar.getInstance();
            new DatePickerDialog(this, (view, year, month, day) -> {
                etDeadline.setText(String.format(Locale.getDefault(), "%02d/%02d/%d", day, month + 1, year));
            }, c.get(Calendar.YEAR), c.get(Calendar.MONTH), c.get(Calendar.DAY_OF_MONTH)).show();
        });
    }

    private void setupListeners() {
        ivBack.setOnClickListener(v -> finish());

        rgSize.setOnCheckedChangeListener((group, checkedId) -> {
            etCustomSize.setVisibility(checkedId == R.id.rbCustomSize ? View.VISIBLE : View.GONE);
            calculatePrice();
        });

        rgShape.setOnCheckedChangeListener((group, checkedId) -> {
            etCustomShape.setVisibility(checkedId == R.id.rbCustomShape ? View.VISIBLE : View.GONE);
            calculatePrice();
        });

        rgColorType.setOnCheckedChangeListener((group, checkedId) -> calculatePrice());

        AdapterView.OnItemSelectedListener spinnerListener = new AdapterView.OnItemSelectedListener() {
            @Override public void onItemSelected(AdapterView<?> parent, View view, int position, long id) { calculatePrice(); }
            @Override public void onNothingSelected(android.widget.AdapterView<?> parent) {}
        };
        spMaterial.setOnItemSelectedListener(spinnerListener);
        spFinish.setOnItemSelectedListener(spinnerListener);
        spCutType.setOnItemSelectedListener(spinnerListener);

        etQuantity.addTextChangedListener(new TextWatcher() {
            @Override public void beforeTextChanged(CharSequence s, int start, int count, int after) {}
            @Override public void onTextChanged(CharSequence s, int start, int before, int count) { calculatePrice(); }
            @Override public void afterTextChanged(Editable s) {}
        });

        cbUrgent.setOnCheckedChangeListener((buttonView, isChecked) -> calculatePrice());

        rgDelivery.setOnCheckedChangeListener((group, checkedId) -> {
            etDeliveryAddress.setVisibility(checkedId == R.id.rbDelivery ? View.VISIBLE : View.GONE);
            calculatePrice();
        });

        layoutUploadLogo.setOnClickListener(v -> openGallery(logoLauncher));
        layoutUploadDesign.setOnClickListener(v -> openFilePicker(designLauncher));

        btnOrder.setOnClickListener(v -> validateAndProceedToPayment());
    }

    private void calculatePrice() {
        double unitPrice = 5.0; // Base LKR
        int sizeId = rgSize.getCheckedRadioButtonId();
        if (sizeId == R.id.rbSmall) unitPrice = 5.0;
        else if (sizeId == R.id.rbMedium) unitPrice = 10.0;
        else if (sizeId == R.id.rbLarge) unitPrice = 20.0;
        else if (sizeId == R.id.rbCustomSize) unitPrice = 15.0;

        if (rgColorType.getCheckedRadioButtonId() == R.id.rbFullColor) unitPrice += 5.0;

        String material = spMaterial.getSelectedItem().toString();
        if (material.contains("Vinyl")) unitPrice += 10.0;
        else if (material.contains("Holographic")) unitPrice += 20.0;

        if (spFinish.getSelectedItem().toString().contains("Laminated")) unitPrice += 5.0;
        if (spCutType.getSelectedItem().toString().contains("Die cut")) unitPrice += 3.0;

        int qty = 0;
        try {
            String qtyStr = etQuantity.getText().toString().trim();
            if (!qtyStr.isEmpty()) qty = Integer.parseInt(qtyStr);
        } catch (Exception e) {}

        currentTotalPrice = unitPrice * qty;

        if (rgDelivery.getCheckedRadioButtonId() == R.id.rbDelivery) {
            currentTotalPrice += 350;
        }

        if (cbUrgent.isChecked()) {
            currentTotalPrice += 500;
        }

        tvPrice.setText(String.format(Locale.getDefault(), "Estimated Price: Rs %.2f", currentTotalPrice));
    }

    private void openGallery(ActivityResultLauncher<Intent> launcher) {
        Intent intent = new Intent(Intent.ACTION_PICK);
        intent.setType("image/*");
        launcher.launch(intent);
    }

    private void openFilePicker(ActivityResultLauncher<Intent> launcher) {
        Intent intent = new Intent(Intent.ACTION_GET_CONTENT);
        intent.setType("*/*");
        intent.addCategory(Intent.CATEGORY_OPENABLE);
        launcher.launch(intent);
    }

    private void handleImageResult(androidx.activity.result.ActivityResult result, ImageView preview, int type) {
        if (result.getResultCode() == RESULT_OK && result.getData() != null) {
            Uri uri = result.getData().getData();
            if (uri == null) return;

            String mimeType = getContentResolver().getType(uri);
            if (mimeType != null && mimeType.startsWith("image/")) {
                String base64 = encodeImage(uri);
                if (type == 1) logoBase64 = base64;
                else if (type == 2) designBase64 = base64;
                Toast.makeText(this, "Image selected successfully", Toast.LENGTH_SHORT).show();
            } else {
                try {
                    InputStream is = getContentResolver().openInputStream(uri);
                    byte[] bytes = readAllBytes(is);
                    String base64 = Base64.encodeToString(bytes, Base64.DEFAULT);
                    if (type == 2) designBase64 = base64;
                    Toast.makeText(this, "File selected successfully", Toast.LENGTH_SHORT).show();
                } catch (Exception e) {
                    Toast.makeText(this, "Failed to read file", Toast.LENGTH_SHORT).show();
                }
            }
        }
    }

    private byte[] readAllBytes(InputStream inputStream) throws IOException {
        ByteArrayOutputStream byteBuffer = new ByteArrayOutputStream();
        byte[] buffer = new byte[1024];
        int len;
        while ((len = inputStream.read(buffer)) != -1) {
            byteBuffer.write(buffer, 0, len);
        }
        return byteBuffer.toByteArray();
    }

    private String encodeImage(Uri uri) {
        try {
            InputStream is = getContentResolver().openInputStream(uri);
            Bitmap bitmap = BitmapFactory.decodeStream(is);
            if (bitmap == null) return "";
            Bitmap scaled = Bitmap.createScaledBitmap(bitmap, 800, (int) (800.0 * bitmap.getHeight() / bitmap.getWidth()), true);
            ByteArrayOutputStream baos = new ByteArrayOutputStream();
            scaled.compress(Bitmap.CompressFormat.JPEG, 60, baos);
            return Base64.encodeToString(baos.toByteArray(), Base64.DEFAULT);
        } catch (Exception e) { return ""; }
    }

    private void validateAndProceedToPayment() {
        String title = etStickerTitle.getText().toString().trim();
        String deadline = etDeadline.getText().toString().trim();
        String qtyStr = etQuantity.getText().toString().trim();

        if (title.isEmpty() || deadline.isEmpty() || qtyStr.isEmpty()) {
            Toast.makeText(this, "Please fill required fields (Title, Deadline, Quantity)", Toast.LENGTH_SHORT).show();
            return;
        }

        int sizeId = rgSize.getCheckedRadioButtonId();
        if (sizeId == R.id.rbCustomSize && etCustomSize.getText().toString().trim().isEmpty()) {
            Toast.makeText(this, "Please enter your custom size", Toast.LENGTH_SHORT).show();
            return;
        }

        int shapeId = rgShape.getCheckedRadioButtonId();
        if (shapeId == R.id.rbCustomShape && etCustomShape.getText().toString().trim().isEmpty()) {
            Toast.makeText(this, "Please enter your custom shape", Toast.LENGTH_SHORT).show();
            return;
        }

        String size = "Custom";
        if (sizeId == R.id.rbSmall) size = "Small";
        else if (sizeId == R.id.rbMedium) size = "Medium";
        else if (sizeId == R.id.rbLarge) size = "Large";

        String shape = "Custom";
        if (shapeId == R.id.rbSquare) shape = "Square";
        else if (shapeId == R.id.rbRectangle) shape = "Rectangle";
        else if (shapeId == R.id.rbCircle) shape = "Circle";
        else if (shapeId == R.id.rbOval) shape = "Oval";

        String userId = firebaseHelper.getCurrentUser() != null ? firebaseHelper.getCurrentUser().getUid() : "anonymous";
        String orderId = UUID.randomUUID().toString();

        StickerOrder stickerOrder = new StickerOrder(
                orderId, userId, title, spPurpose.getSelectedItem().toString(), spLanguage.getSelectedItem().toString(),
                size, etCustomSize.getText().toString(), shape, etCustomShape.getText().toString(),
                etTextContent.getText().toString(), logoBase64, designBase64,
                spMaterial.getSelectedItem().toString(), spFinish.getSelectedItem().toString(),
                spCutType.getSelectedItem().toString(), 
                rgColorType.getCheckedRadioButtonId() == R.id.rbFullColor ? "Full Color" : "B&W",
                qtyStr, rgUsage.getCheckedRadioButtonId() == R.id.rbIndoor ? "Indoor" : "Outdoor",
                rgDelivery.getCheckedRadioButtonId() == R.id.rbDelivery ? "Delivery" : "Pickup",
                etDeliveryAddress.getText().toString(), deadline, cbUrgent.isChecked(),
                etSpecialInstructions.getText().toString(), System.currentTimeMillis(), currentTotalPrice, "Pending"
        );

        Intent intent = new Intent(this, PaymentBillingActivity.class);
        intent.putExtra("order_data", stickerOrder);
        startActivity(intent);
    }
}
