package com.example.printxpress.Activity;

import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;

import androidx.appcompat.app.AppCompatActivity;
import com.example.printxpress.R;

public class Splashscreen extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);


        SharedPreferences userPrefs = getSharedPreferences("UserPrefs", MODE_PRIVATE);
        boolean isLoggedIn = userPrefs.getBoolean("isLoggedIn", false);

        if (isLoggedIn) {

            Intent intent = new Intent(Splashscreen.this, Dashboard.class);
            startActivity(intent);
            finish();
            return;
        }

        setContentView(R.layout.activity_splashscreen);

        new android.os.Handler().postDelayed(() -> {
            Intent intent = new Intent(Splashscreen.this, LoginActivity.class);
            startActivity(intent);
            finish();
        }, 2000);
    }
}