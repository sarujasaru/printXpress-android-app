package com.example.printxpress.Activity;

import android.content.Intent;
import android.os.Bundle;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.View;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.ScrollView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

import com.example.printxpress.Firebase.FirebaseHelper;
import com.example.printxpress.R;
import com.example.printxpress.models.User;
import com.google.android.material.textfield.TextInputLayout;

public class RegisterActivity extends AppCompatActivity {

    private EditText etUser, etPhone, etAddress, etEmail, etPass, etConfirmPass;
    private TextInputLayout tilUser, tilPhone, tilAddress, tilEmail, tilPass, tilConfirmPass;
    private Button btnSignUp;
    private CheckBox cbTerms;
    private ScrollView registerScrollView;
    private FirebaseHelper firebaseHelper;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_register);

        // LoginActivity-il உள்ளதை போலவே அலைப்பகுதி மறையாமல் இருக்க இந்த பகுதியைச் சேர்த்துள்ளேன்
        View mainView = findViewById(R.id.main);
        if (mainView != null) {
            ViewCompat.setOnApplyWindowInsetsListener(mainView, (v, insets) -> {
                Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
                v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
                return insets;
            });
        }
        
        firebaseHelper = new FirebaseHelper();

        // TextInputLayouts for Error Messages
        tilUser = findViewById(R.id.tilUsername);
        tilPhone = findViewById(R.id.tilPhone);
        tilAddress = findViewById(R.id.tilAddress);
        tilEmail = findViewById(R.id.tilEmail);
        tilPass = findViewById(R.id.tilPassword);
        tilConfirmPass = findViewById(R.id.tilConfirmPassword);

        // EditTexts
        etUser = findViewById(R.id.etUsername);
        etPhone = findViewById(R.id.etPhoneno);
        etAddress = findViewById(R.id.etAddress);
        etEmail = findViewById(R.id.etEmail);
        etPass = findViewById(R.id.etPassword);
        etConfirmPass = findViewById(R.id.etConfirmPassword);

        registerScrollView = findViewById(R.id.registerScrollView);
        btnSignUp = findViewById(R.id.btnSignUp);
        cbTerms = findViewById(R.id.cbTerms);

        // Clear error as user types
        setupTextWatchers();

        btnSignUp.setOnClickListener(v -> {
            if (validateInputs()) {
                performRegistration();
            }
        });

        findViewById(R.id.tvLoginLink).setOnClickListener(v -> {
            startActivity(new Intent(this, LoginActivity.class));
            finish();
        });
    }

    private void setupTextWatchers() {
        etUser.addTextChangedListener(new ErrorCleaner(tilUser));
        etPhone.addTextChangedListener(new ErrorCleaner(tilPhone));
        etAddress.addTextChangedListener(new ErrorCleaner(tilAddress));
        etEmail.addTextChangedListener(new ErrorCleaner(tilEmail));
        etPass.addTextChangedListener(new ErrorCleaner(tilPass));
        etConfirmPass.addTextChangedListener(new ErrorCleaner(tilConfirmPass));
    }

    private boolean validateInputs() {
        boolean isValid = true;

        if (etUser.getText().toString().trim().isEmpty()) {
            tilUser.setError("Username is required");
            isValid = false;
        }
        if (etPhone.getText().toString().trim().isEmpty()) {
            tilPhone.setError("Phone number is required");
            isValid = false;
        }
        if (etAddress.getText().toString().trim().isEmpty()) {
            tilAddress.setError("Address is required");
            isValid = false;
        }
        if (etEmail.getText().toString().trim().isEmpty()) {
            tilEmail.setError("Email is required");
            isValid = false;
        }
        if (etPass.getText().toString().trim().isEmpty()) {
            tilPass.setError("Password is required");
            isValid = false;
        } else if (etPass.getText().toString().length() < 6) {
            tilPass.setError("Password must be at least 6 characters");
            isValid = false;
        }
        if (!etPass.getText().toString().equals(etConfirmPass.getText().toString())) {
            tilConfirmPass.setError("Passwords do not match");
            isValid = false;
        }
        if (!cbTerms.isChecked()) {
            Toast.makeText(this, "Please accept Terms & Conditions", Toast.LENGTH_SHORT).show();
            isValid = false;
        }

        return isValid;
    }

    private void performRegistration() {
        String email = etEmail.getText().toString().trim();
        String pass = etPass.getText().toString().trim();
        String user = etUser.getText().toString().trim();
        String phone = etPhone.getText().toString().trim();
        String address = etAddress.getText().toString().trim();

        firebaseHelper.registerUser(email, pass).addOnCompleteListener(task -> {
            if (task.isSuccessful()) {
                String userId = firebaseHelper.getCurrentUser().getUid();
                User newUser = new User(userId, user, phone, address, email, pass, pass);
                firebaseHelper.saveUserDetails(newUser).addOnCompleteListener(dbTask -> {
                    if (dbTask.isSuccessful()) {
                        Toast.makeText(this, "Registration Successful", Toast.LENGTH_SHORT).show();
                        startActivity(new Intent(this, LoginActivity.class));
                        finish();
                    }
                });
            } else {
                Toast.makeText(this, "Error: " + task.getException().getMessage(), Toast.LENGTH_LONG).show();
            }
        });
    }

    private static class ErrorCleaner implements TextWatcher {
        private final TextInputLayout layout;
        public ErrorCleaner(TextInputLayout layout) { this.layout = layout; }
        @Override public void beforeTextChanged(CharSequence s, int start, int count, int after) {}
        @Override public void onTextChanged(CharSequence s, int start, int before, int count) {
            layout.setError(null);
        }
        @Override public void afterTextChanged(Editable s) {}
    }
}
