package com.example.printxpress.Activity;

import android.os.Bundle;
import android.view.View;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.example.printxpress.Adapter.OrderAdapter;
import com.example.printxpress.Firebase.FirebaseHelper;
import com.example.printxpress.R;
import com.example.printxpress.models.Order;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.ValueEventListener;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

public class OrderHistoryActivity extends AppCompatActivity {

    private RecyclerView rvOrderHistory;
    private OrderAdapter orderAdapter;
    private List<Order> orderList;
    private FirebaseHelper firebaseHelper;
    private LinearLayout layoutNoOrders;
    private ImageView btnBack;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_order_history);

        // Views initialization
        rvOrderHistory = findViewById(R.id.rvOrderHistory);
        layoutNoOrders = findViewById(R.id.tvNoOrders);
        btnBack = findViewById(R.id.btnBack);

        firebaseHelper = new FirebaseHelper();
        orderList = new ArrayList<>();
        orderAdapter = new OrderAdapter(orderList);

        rvOrderHistory.setLayoutManager(new LinearLayoutManager(this));
        rvOrderHistory.setAdapter(orderAdapter);

        btnBack.setOnClickListener(v -> finish());

        loadOrderHistory();
    }

    private void loadOrderHistory() {
        if (firebaseHelper.getCurrentUser() != null) {
            String uid = firebaseHelper.getCurrentUser().getUid();
            firebaseHelper.getOrdersReference(uid).addValueEventListener(new ValueEventListener() {
                @Override
                public void onDataChange(@NonNull DataSnapshot snapshot) {
                    orderList.clear();
                    for (DataSnapshot dataSnapshot : snapshot.getChildren()) {
                        Order order = dataSnapshot.getValue(Order.class);
                        if (order != null) {
                            orderList.add(order);
                        }
                    }
                    
                    // Sort by timestamp: latest orders first
                    Collections.sort(orderList, (o1, o2) -> Long.compare(o2.getTimestamp(), o1.getTimestamp()));
                    
                    if (orderList.isEmpty()) {
                        layoutNoOrders.setVisibility(View.VISIBLE);
                        rvOrderHistory.setVisibility(View.GONE);
                    } else {
                        layoutNoOrders.setVisibility(View.GONE);
                        rvOrderHistory.setVisibility(View.VISIBLE);
                    }
                    orderAdapter.notifyDataSetChanged();
                }

                @Override
                public void onCancelled(@NonNull DatabaseError error) {
                    Toast.makeText(OrderHistoryActivity.this, "Failed to load order history", Toast.LENGTH_SHORT).show();
                }
            });
        }
    }
}
