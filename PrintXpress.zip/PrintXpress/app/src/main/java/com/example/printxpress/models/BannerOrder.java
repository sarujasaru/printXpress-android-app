package com.example.printxpress.models;

public class BannerOrder implements BaseOrder {
    private String orderId;
    private String userId;

    // 1. Basic Info
    private String title;
    private String purpose;
    private String language;

    // 2. Banner Size
    private String size; // e.g., "2ft x 4ft", "3ft x 6ft", "4ft x 8ft", or "Custom: 5x10"

    // 3. Flex Type / Material
    private String materialType; // Flex, Vinyl, Matte, Glossy

    // 4. Content Details
    private String mainHeading;
    private String subHeading;
    private String description;
    private String offerDetails;
    private String dateTime;
    private String address;
    private String contactNumber;

    // 5. Image / Logo (Base64 for simplicity in this project)
    private String companyLogo;
    private String productImages;
    private String personPhoto;

    // 6. Design Preferences
    private String colorTheme;
    private String fontStyle;
    private String exampleDesign;
    private String designNotes;

    // 7. Finishing Options
    private boolean eyelets;
    private boolean rope;
    private boolean stand;

    // 8. Quantity
    private String quantity;

    // 9. Delivery Details
    private String deliveryType; // Pickup / Delivery
    private String deliveryAddress;

    // 10. Deadline
    private String deadline;
    private boolean urgent;

    // 11. Special Instructions
    private String specialInstructions;

    private long timestamp;
    private double totalPrice;
    private String status;

    public BannerOrder() {
    }

    public BannerOrder(String orderId, String userId, String title, String purpose, String language, String size, String materialType, String mainHeading, String subHeading, String description, String offerDetails, String dateTime, String address, String contactNumber, String companyLogo, String productImages, String personPhoto, String colorTheme, String fontStyle, String exampleDesign, String designNotes, boolean eyelets, boolean rope, boolean stand, String quantity, String deliveryType, String deliveryAddress, String deadline, boolean urgent, String specialInstructions, long timestamp, double totalPrice, String status) {
        this.orderId = orderId;
        this.userId = userId;
        this.title = title;
        this.purpose = purpose;
        this.language = language;
        this.size = size;
        this.materialType = materialType;
        this.mainHeading = mainHeading;
        this.subHeading = subHeading;
        this.description = description;
        this.offerDetails = offerDetails;
        this.dateTime = dateTime;
        this.address = address;
        this.contactNumber = contactNumber;
        this.companyLogo = companyLogo;
        this.productImages = productImages;
        this.personPhoto = personPhoto;
        this.colorTheme = colorTheme;
        this.fontStyle = fontStyle;
        this.exampleDesign = exampleDesign;
        this.designNotes = designNotes;
        this.eyelets = eyelets;
        this.rope = rope;
        this.stand = stand;
        this.quantity = quantity;
        this.deliveryType = deliveryType;
        this.deliveryAddress = deliveryAddress;
        this.deadline = deadline;
        this.urgent = urgent;
        this.specialInstructions = specialInstructions;
        this.timestamp = timestamp;
        this.totalPrice = totalPrice;
        this.status = status;
    }

    @Override
    public String getProductType() { return "Banner: " + title; }

    @Override
    public String getOrderSummary() {
        return "Size: " + size + " | Material: " + materialType + " | Qty: " + quantity;
    }

    @Override
    public String getPhotoUrl() { return null; }

    @Override
    public String getBase64Image() {
        if (productImages != null && !productImages.isEmpty()) return productImages;
        if (companyLogo != null && !companyLogo.isEmpty()) return companyLogo;
        if (personPhoto != null && !personPhoto.isEmpty()) return personPhoto;
        return null;
    }

    // Getters and Setters
    public String getOrderId() { return orderId; }
    public void setOrderId(String orderId) { this.orderId = orderId; }
    public String getUserId() { return userId; }
    public void setUserId(String userId) { this.userId = userId; }
    public String getTitle() { return title; }
    public void setTitle(String title) { this.title = title; }
    public String getPurpose() { return purpose; }
    public void setPurpose(String purpose) { this.purpose = purpose; }
    public String getLanguage() { return language; }
    public void setLanguage(String language) { this.language = language; }
    public String getSize() { return size; }
    public void setSize(String size) { this.size = size; }
    public String getMaterialType() { return materialType; }
    public void setMaterialType(String materialType) { this.materialType = materialType; }
    public String getMainHeading() { return mainHeading; }
    public void setMainHeading(String mainHeading) { this.mainHeading = mainHeading; }
    public String getSubHeading() { return subHeading; }
    public void setSubHeading(String subHeading) { this.subHeading = subHeading; }
    public String getDescription() { return description; }
    public void setDescription(String description) { this.description = description; }
    public String getOfferDetails() { return offerDetails; }
    public void setOfferDetails(String offerDetails) { this.offerDetails = offerDetails; }
    public String getDateTime() { return dateTime; }
    public void setDateTime(String dateTime) { this.dateTime = dateTime; }
    public String getAddress() { return address; }
    public void setAddress(String address) { this.address = address; }
    public String getContactNumber() { return contactNumber; }
    public void setContactNumber(String contactNumber) { this.contactNumber = contactNumber; }
    public String getCompanyLogo() { return companyLogo; }
    public void setCompanyLogo(String companyLogo) { this.companyLogo = companyLogo; }
    public String getProductImages() { return productImages; }
    public void setProductImages(String productImages) { this.productImages = productImages; }
    public String getPersonPhoto() { return personPhoto; }
    public void setPersonPhoto(String personPhoto) { this.personPhoto = personPhoto; }
    public String getColorTheme() { return colorTheme; }
    public void setColorTheme(String colorTheme) { this.colorTheme = colorTheme; }
    public String getFontStyle() { return fontStyle; }
    public void setFontStyle(String fontStyle) { this.fontStyle = fontStyle; }
    public String getExampleDesign() { return exampleDesign; }
    public void setExampleDesign(String exampleDesign) { this.exampleDesign = exampleDesign; }
    public String getDesignNotes() { return designNotes; }
    public void setDesignNotes(String designNotes) { this.designNotes = designNotes; }
    public boolean isEyelets() { return eyelets; }
    public void setEyelets(boolean eyelets) { this.eyelets = eyelets; }
    public boolean isRope() { return rope; }
    public void setRope(boolean rope) { this.rope = rope; }
    public boolean isStand() { return stand; }
    public void setStand(boolean stand) { this.stand = stand; }
    public String getQuantity() { return quantity; }
    public void setQuantity(String quantity) { this.quantity = quantity; }
    public String getDeliveryType() { return deliveryType; }
    public void setDeliveryType(String deliveryType) { this.deliveryType = deliveryType; }
    public String getDeliveryAddress() { return deliveryAddress; }
    public void setDeliveryAddress(String deliveryAddress) { this.deliveryAddress = deliveryAddress; }
    public String getDeadline() { return deadline; }
    public void setDeadline(String deadline) { this.deadline = deadline; }
    public boolean isUrgent() { return urgent; }
    public void setUrgent(boolean urgent) { this.urgent = urgent; }
    public String getSpecialInstructions() { return specialInstructions; }
    public void setSpecialInstructions(String specialInstructions) { this.specialInstructions = specialInstructions; }
    public long getTimestamp() { return timestamp; }
    public void setTimestamp(long timestamp) { this.timestamp = timestamp; }
    public double getTotalPrice() { return totalPrice; }
    public void setTotalPrice(double totalPrice) { this.totalPrice = totalPrice; }
    public String getStatus() { return status; }
    public void setStatus(String status) { this.status = status; }
}
