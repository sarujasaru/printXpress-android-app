package com.example.printxpress.Activity;

import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.content.Context;
import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.os.Build;
import android.os.Bundle;
import android.util.Base64;
import android.view.View;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.RadioGroup;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;
import androidx.core.app.NotificationCompat;

import com.bumptech.glide.Glide;
import com.example.printxpress.R;
import com.example.printxpress.models.BaseOrder;
import com.example.printxpress.models.Notification;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;

public class PaymentBillingActivity extends AppCompatActivity {

    private Toolbar toolbar;
    private ImageView ivProductPreview;
    private TextView tvProductName, tvOrderDetails, tvItemPrice, tvPrintingCost, tvDeliveryCharge, tvDiscount, tvTotalAmount, tvDeliveryEstimate;
    private EditText etPromoCode, etFullName, etPhone, etBillingAddress;
    private EditText etCardNumber, etExpiry, etCVV;
    private Button btnApplyCoupon, btnConfirmOrder;
    private CheckBox cbSameAsDelivery, cbTerms;
    private RadioGroup rgDeliveryMethod, rgPaymentMethod;
    private LinearLayout layoutCardDetails;

    private BaseOrder order;
    private double itemPrice, printingCost = 0.0, deliveryCharge = 0.0, discount = 0.0, totalAmount;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_payment_billing);

        order = (BaseOrder) getIntent().getSerializableExtra("order_data");

        initViews();
        setupToolbar();
        displayOrderData();
        setupListeners();
    }

    private void initViews() {
        toolbar = findViewById(R.id.toolbar);
        ivProductPreview = findViewById(R.id.ivProductPreview);
        tvProductName = findViewById(R.id.tvProductName);
        tvOrderDetails = findViewById(R.id.tvOrderDetails);
        tvItemPrice = findViewById(R.id.tvItemPrice);
        tvPrintingCost = findViewById(R.id.tvPrintingCost);
        tvDeliveryCharge = findViewById(R.id.tvDeliveryCharge);
        tvDiscount = findViewById(R.id.tvDiscount);
        tvTotalAmount = findViewById(R.id.tvTotalAmount);
        tvDeliveryEstimate = findViewById(R.id.tvDeliveryEstimate);

        etPromoCode = findViewById(R.id.etPromoCode);
        etFullName = findViewById(R.id.etFullName);
        etPhone = findViewById(R.id.etPhone);
        etBillingAddress = findViewById(R.id.etBillingAddress);
        
        etCardNumber = findViewById(R.id.etCardNumber);
        etExpiry = findViewById(R.id.etExpiry);
        etCVV = findViewById(R.id.etCVV);

        btnApplyCoupon = findViewById(R.id.btnApplyCoupon);
        btnConfirmOrder = findViewById(R.id.btnConfirmOrder);

        cbSameAsDelivery = findViewById(R.id.cbSameAsDelivery);
        cbTerms = findViewById(R.id.cbTerms);

        rgDeliveryMethod = findViewById(R.id.rgDeliveryMethod);
        rgPaymentMethod = findViewById(R.id.rgPaymentMethod);
        layoutCardDetails = findViewById(R.id.layoutCardDetails);
    }

    private void setupToolbar() {
        setSupportActionBar(toolbar);
        if (getSupportActionBar() != null) {
            getSupportActionBar().setDisplayHomeAsUpEnabled(true);
        }
        toolbar.setNavigationOnClickListener(v -> finish());
    }

    private void displayOrderData() {
        if (order != null) {
            String productType = order.getProductType();
            tvProductName.setText(productType);
            tvOrderDetails.setText(order.getOrderSummary());
            
            totalAmount = order.getTotalPrice();
            
            if (productType.equalsIgnoreCase("Business Card")) {
                printingCost = 0.0;
            } else {
                printingCost = totalAmount > 100 ? 50.0 : 0.0;
            }
            
            itemPrice = totalAmount - printingCost;
            if (itemPrice < 0) {
                itemPrice = totalAmount;
                printingCost = 0;
            }

            tvItemPrice.setText("Rs " + String.format("%.2f", itemPrice));
            tvPrintingCost.setText("Rs " + String.format("%.2f", printingCost));
            tvDeliveryCharge.setText("Rs " + String.format("%.2f", deliveryCharge));
            tvTotalAmount.setText("Rs " + String.format("%.2f", totalAmount));

            etBillingAddress.setText(order.getAddress());
            
            if (order.getPhotoUrl() != null && !order.getPhotoUrl().isEmpty()) {
                Glide.with(this).load(order.getPhotoUrl()).into(ivProductPreview);
            } else if (order.getBase64Image() != null && !order.getBase64Image().isEmpty()) {
                try {
                    byte[] decodedString = Base64.decode(order.getBase64Image(), Base64.DEFAULT);
                    Bitmap decodedByte = BitmapFactory.decodeByteArray(decodedString, 0, decodedString.length);
                    ivProductPreview.setImageBitmap(decodedByte);
                } catch (Exception e) {
                    ivProductPreview.setImageResource(getDefaultImage(productType));
                }
            } else {
                ivProductPreview.setImageResource(getDefaultImage(productType));
            }
        }
    }

    private int getDefaultImage(String productType) {
        if (productType == null) return R.drawable.key;
        String type = productType.toLowerCase();
        if (type.contains("t-shirt")) return R.drawable.tshirt;
        if (type.contains("mug")) return R.drawable.mug;
        if (type.contains("cap")) return R.drawable.cap;
        if (type.contains("sticker")) return R.drawable.sticker;
        if (type.contains("flyer")) return R.drawable.flyers;
        if (type.contains("banner")) return R.drawable.banner;
        if (type.contains("poster")) return R.drawable.posters;
        if (type.contains("frame")) return R.drawable.frame;
        if (type.contains("business card")) return R.drawable.businesscard;
        return R.drawable.key;
    }

    private void setupListeners() {
        cbSameAsDelivery.setOnCheckedChangeListener((buttonView, isChecked) -> {
            if (isChecked && order != null) {
                etBillingAddress.setText(order.getAddress());
            } else {
                etBillingAddress.setText("");
            }
        });

        rgDeliveryMethod.setOnCheckedChangeListener((group, checkedId) -> {
            if (checkedId == R.id.rbPickup) {
                deliveryCharge = 0.0;
                tvDeliveryEstimate.setText("Estimated Pickup: 1-2 Days");
            } else {
                deliveryCharge = 50.0;
                tvDeliveryEstimate.setText("Estimated Delivery: 3-5 Days");
            }
            updateTotal();
        });

        rgPaymentMethod.setOnCheckedChangeListener((group, checkedId) -> {
            if (checkedId == R.id.rbCard) {
                layoutCardDetails.setVisibility(View.VISIBLE);
            } else {
                layoutCardDetails.setVisibility(View.GONE);
            }
        });

        btnApplyCoupon.setOnClickListener(v -> {
            String code = etPromoCode.getText().toString().trim();
            if (code.equalsIgnoreCase("PRINT10")) {
                discount = totalAmount * 0.1;
                Toast.makeText(this, "Promo code applied!", Toast.LENGTH_SHORT).show();
                updateTotal();
            } else {
                Toast.makeText(this, "Invalid promo code", Toast.LENGTH_SHORT).show();
            }
        });

        btnConfirmOrder.setOnClickListener(v -> validateAndPlaceOrder());
    }

    private void updateTotal() {
        double currentTotal = itemPrice + printingCost + deliveryCharge - discount;
        tvDeliveryCharge.setText("Rs " + String.format("%.2f", deliveryCharge));
        tvDiscount.setText("-Rs " + String.format("%.2f", discount));
        tvTotalAmount.setText("Rs " + String.format("%.2f", currentTotal));
    }

    private void validateAndPlaceOrder() {
        if (etFullName.getText().toString().isEmpty() || etPhone.getText().toString().isEmpty()) {
            Toast.makeText(this, "Please fill in all customer details", Toast.LENGTH_SHORT).show();
            return;
        }

        if (rgPaymentMethod.getCheckedRadioButtonId() == R.id.rbCard) {
            if (etCardNumber.getText().toString().isEmpty() || etExpiry.getText().toString().isEmpty() || etCVV.getText().toString().isEmpty()) {
                Toast.makeText(this, "Please enter card details", Toast.LENGTH_SHORT).show();
                return;
            }
        }

        if (!cbTerms.isChecked()) {
            Toast.makeText(this, "Please agree to the terms & conditions", Toast.LENGTH_SHORT).show();
            return;
        }

        placeOrder();
    }

    private void placeOrder() {
        btnConfirmOrder.setEnabled(false);
        DatabaseReference ref = FirebaseDatabase.getInstance().getReference("Orders").child(order.getOrderId());
        
        double finalAmount = itemPrice + printingCost + deliveryCharge - discount;
        order.setTotalPrice(finalAmount);
        order.setStatus("Confirmed");
        order.setAddress(etBillingAddress.getText().toString().trim());

        ref.setValue(order).addOnSuccessListener(aVoid -> {
            sendNotification(order.getOrderId());
            Toast.makeText(this, "Order Confirmed Successfully!", Toast.LENGTH_LONG).show();
            Intent intent = new Intent(this, Dashboard.class);
            intent.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP | Intent.FLAG_ACTIVITY_NEW_TASK);
            startActivity(intent);
            finish();
        }).addOnFailureListener(e -> {
            btnConfirmOrder.setEnabled(true);
            Toast.makeText(this, "Failed: " + e.getMessage(), Toast.LENGTH_SHORT).show();
        });
    }

    private void sendNotification(String orderId) {
        String title = "Order Confirmed! ✅";
        String msg = "Your order " + orderId + " has been confirmed.";
        DatabaseReference nRef = FirebaseDatabase.getInstance().getReference("Notification");
        String nid = nRef.push().getKey();
        String userId = FirebaseAuth.getInstance().getCurrentUser().getUid();
        Notification notification = new Notification(nid, title, msg, System.currentTimeMillis(), "ORDER", userId);
        if (nid != null) nRef.child(nid).setValue(notification);

        NotificationManager nm = (NotificationManager) getSystemService(Context.NOTIFICATION_SERVICE);
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            NotificationChannel channel = new NotificationChannel("order_status", "Order Status", NotificationManager.IMPORTANCE_DEFAULT);
            if (nm != null) nm.createNotificationChannel(channel);
        }
        NotificationCompat.Builder builder = new NotificationCompat.Builder(this, "order_status")
                .setSmallIcon(R.drawable.baseline_notifications_24)
                .setContentTitle(title)
                .setContentText(msg)
                .setAutoCancel(true);
        if (nm != null) nm.notify((int) System.currentTimeMillis(), builder.build());
    }
}
