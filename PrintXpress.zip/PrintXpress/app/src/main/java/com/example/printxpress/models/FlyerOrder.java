package com.example.printxpress.models;

public class FlyerOrder implements BaseOrder {
    private String orderId;
    private String userId;

    private String title;
    private String purpose;
    private String language;
    private String size; 
    private String orientation; 
    private String mainHeading;
    private String subHeading;
    private String description;
    private String offerDetails;
    private String dateTime;
    private String address;
    private String contactNumber;
    private String companyLogo;
    private String productImages;
    private String backgroundImage;
    private String colorTheme;
    private String style; 
    private String fontStyle;
    private String layoutPreference; 
    private String printType; 
    private String paperType; 
    private String quantity;
    private String distributionPurpose;
    private String deliveryType; 
    private String deliveryAddress;
    private String deadline;
    private boolean urgent;
    private String specialInstructions;
    private long timestamp;
    private double totalPrice;
    private String status;

    public FlyerOrder() {}

    public FlyerOrder(String orderId, String userId, String title, String purpose, String language, String size, String orientation, String mainHeading, String subHeading, String description, String offerDetails, String dateTime, String address, String contactNumber, String companyLogo, String productImages, String backgroundImage, String colorTheme, String style, String fontStyle, String layoutPreference, String printType, String paperType, String quantity, String distributionPurpose, String deliveryType, String deliveryAddress, String deadline, boolean urgent, String specialInstructions, long timestamp, double totalPrice, String status) {
        this.orderId = orderId;
        this.userId = userId;
        this.title = title;
        this.purpose = purpose;
        this.language = language;
        this.size = size;
        this.orientation = orientation;
        this.mainHeading = mainHeading;
        this.subHeading = subHeading;
        this.description = description;
        this.offerDetails = offerDetails;
        this.dateTime = dateTime;
        this.address = address;
        this.contactNumber = contactNumber;
        this.companyLogo = companyLogo;
        this.productImages = productImages;
        this.backgroundImage = backgroundImage;
        this.colorTheme = colorTheme;
        this.style = style;
        this.fontStyle = fontStyle;
        this.layoutPreference = layoutPreference;
        this.printType = printType;
        this.paperType = paperType;
        this.quantity = quantity;
        this.distributionPurpose = distributionPurpose;
        this.deliveryType = deliveryType;
        this.deliveryAddress = deliveryAddress;
        this.deadline = deadline;
        this.urgent = urgent;
        this.specialInstructions = specialInstructions;
        this.timestamp = timestamp;
        this.totalPrice = totalPrice;
        this.status = status;
    }

    @Override
    public String getProductType() { return "Flyer: " + title; }

    @Override
    public String getOrderSummary() {
        return "Size: " + size + " | Qty: " + quantity + " | Paper: " + paperType;
    }

    @Override
    public String getPhotoUrl() { return null; }

    @Override
    public String getBase64Image() {
        if (productImages != null && !productImages.isEmpty()) return productImages;
        if (companyLogo != null && !companyLogo.isEmpty()) return companyLogo;
        return null;
    }

    public String getOrderId() { return orderId; }
    public void setOrderId(String orderId) { this.orderId = orderId; }
    public String getUserId() { return userId; }
    public void setUserId(String userId) { this.userId = userId; }
    public String getTitle() { return title; }
    public void setTitle(String title) { this.title = title; }
    public String getPurpose() { return purpose; }
    public void setPurpose(String purpose) { this.purpose = purpose; }
    public String getLanguage() { return language; }
    public void setLanguage(String language) { this.language = language; }
    public String getSize() { return size; }
    public void setSize(String size) { this.size = size; }
    public String getOrientation() { return orientation; }
    public void setOrientation(String orientation) { this.orientation = orientation; }
    public String getMainHeading() { return mainHeading; }
    public void setMainHeading(String mainHeading) { this.mainHeading = mainHeading; }
    public String getSubHeading() { return subHeading; }
    public void setSubHeading(String subHeading) { this.subHeading = subHeading; }
    public String getDescription() { return description; }
    public void setDescription(String description) { this.description = description; }
    public String getOfferDetails() { return offerDetails; }
    public void setOfferDetails(String offerDetails) { this.offerDetails = offerDetails; }
    public String getDateTime() { return dateTime; }
    public void setDateTime(String dateTime) { this.dateTime = dateTime; }
    public String getAddress() { return address; }
    public void setAddress(String address) { this.address = address; }
    public String getContactNumber() { return contactNumber; }
    public void setContactNumber(String contactNumber) { this.contactNumber = contactNumber; }
    public String getCompanyLogo() { return companyLogo; }
    public void setCompanyLogo(String companyLogo) { this.companyLogo = companyLogo; }
    public String getProductImages() { return productImages; }
    public void setProductImages(String productImages) { this.productImages = productImages; }
    public String getBackgroundImage() { return backgroundImage; }
    public void setBackgroundImage(String backgroundImage) { this.backgroundImage = backgroundImage; }
    public String getColorTheme() { return colorTheme; }
    public void setColorTheme(String colorTheme) { this.colorTheme = colorTheme; }
    public String getStyle() { return style; }
    public void setStyle(String style) { this.style = style; }
    public String getFontStyle() { return fontStyle; }
    public void setFontStyle(String fontStyle) { this.fontStyle = fontStyle; }
    public String getLayoutPreference() { return layoutPreference; }
    public void setLayoutPreference(String layoutPreference) { this.layoutPreference = layoutPreference; }
    public String getPrintType() { return printType; }
    public void setPrintType(String printType) { this.printType = printType; }
    public String getPaperType() { return paperType; }
    public void setPaperType(String paperType) { this.paperType = paperType; }
    public String getQuantity() { return quantity; }
    public void setQuantity(String quantity) { this.quantity = quantity; }
    public String getDistributionPurpose() { return distributionPurpose; }
    public void setDistributionPurpose(String distributionPurpose) { this.distributionPurpose = distributionPurpose; }
    public String getDeliveryType() { return deliveryType; }
    public void setDeliveryType(String deliveryType) { this.deliveryType = deliveryType; }
    public String getDeliveryAddress() { return deliveryAddress; }
    public void setDeliveryAddress(String deliveryAddress) { this.deliveryAddress = deliveryAddress; }
    public String getDeadline() { return deadline; }
    public void setDeadline(String deadline) { this.deadline = deadline; }
    public boolean isUrgent() { return urgent; }
    public void setUrgent(boolean urgent) { this.urgent = urgent; }
    public String getSpecialInstructions() { return specialInstructions; }
    public void setSpecialInstructions(String specialInstructions) { this.specialInstructions = specialInstructions; }
    public long getTimestamp() { return timestamp; }
    public void setTimestamp(long timestamp) { this.timestamp = timestamp; }
    public double getTotalPrice() { return totalPrice; }
    public void setTotalPrice(double totalPrice) { this.totalPrice = totalPrice; }
    public String getStatus() { return status; }
    public void setStatus(String status) { this.status = status; }
}
