package com.example.printxpress.models;

public class BusinessCardOrder implements BaseOrder {
    private String id;
    private String userId;
    
    // 1. Basic Information
    private String fullName;
    private String jobTitle;
    private String companyName;
    
    // 2. Contact Details
    private String phoneNumber;
    private String emailAddress;
    private String website;
    private String officeAddress;
    
    // 3. Card Content Layout
    private String sideOption; // Single side / Double side
    private String textAlignment; // Left / Center / Right
    private boolean qrCode;
    
    // 4. Logo & Image Upload (Base64)
    private String companyLogo;
    private String profilePhoto;
    
    // 5. Design Preferences
    private String colorTheme; // dark / light / custom
    private String fontStyle; // modern / classic / bold
    private String designStyle; // Minimal / creative / corporate
    
    // 6. Card Size & Shape
    private String cardSize; // Standard / Square
    private String cardShape; // Standard / Rounded corners
    
    // 7. Material & Finish
    private String paperType; // Matte / Glossy / Textured
    private String specialFinish; // Lamination / Emboss / Spot UV
    
    // 8. Quantity
    private String quantity;
    
    // 9. Delivery Details
    private String deliveryType; // Pickup / Delivery
    private String deliveryAddress;
    
    // 10. Deadline
    private String deadlineDate;
    private boolean urgent;
    
    // 11. Social Media
    private String linkedIn;
    private String facebook;
    private String instagram;
    
    // 12. Special Instructions
    private String specialInstructions;
    
    private long timestamp;
    private double totalPrice;
    private String status;

    public BusinessCardOrder() {
    }

    public BusinessCardOrder(String id, String userId, String fullName, String jobTitle, String companyName, String phoneNumber, String emailAddress, String website, String officeAddress, String sideOption, String textAlignment, boolean qrCode, String companyLogo, String profilePhoto, String colorTheme, String fontStyle, String designStyle, String cardSize, String cardShape, String paperType, String specialFinish, String quantity, String deliveryType, String deliveryAddress, String deadlineDate, boolean urgent, String linkedIn, String facebook, String instagram, String specialInstructions, long timestamp, double totalPrice, String status) {
        this.id = id;
        this.userId = userId;
        this.fullName = fullName;
        this.jobTitle = jobTitle;
        this.companyName = companyName;
        this.phoneNumber = phoneNumber;
        this.emailAddress = emailAddress;
        this.website = website;
        this.officeAddress = officeAddress;
        this.sideOption = sideOption;
        this.textAlignment = textAlignment;
        this.qrCode = qrCode;
        this.companyLogo = companyLogo;
        this.profilePhoto = profilePhoto;
        this.colorTheme = colorTheme;
        this.fontStyle = fontStyle;
        this.designStyle = designStyle;
        this.cardSize = cardSize;
        this.cardShape = cardShape;
        this.paperType = paperType;
        this.specialFinish = specialFinish;
        this.quantity = quantity;
        this.deliveryType = deliveryType;
        this.deliveryAddress = deliveryAddress;
        this.deadlineDate = deadlineDate;
        this.urgent = urgent;
        this.linkedIn = linkedIn;
        this.facebook = facebook;
        this.instagram = instagram;
        this.specialInstructions = specialInstructions;
        this.timestamp = timestamp;
        this.totalPrice = totalPrice;
        this.status = status;
    }

    @Override
    public String getOrderId() { return id; }

    @Override
    public void setOrderId(String orderId) { this.id = orderId; }

    @Override
    public String getProductType() { return "Business Card"; }

    @Override
    public String getOrderSummary() {
        return "Type: " + sideOption + " | Qty: " + quantity;
    }

    @Override
    public String getPhotoUrl() { return null; }

    @Override
    public String getBase64Image() {
        if (companyLogo != null && !companyLogo.isEmpty()) return companyLogo;
        if (profilePhoto != null && !profilePhoto.isEmpty()) return profilePhoto;
        return null;
    }

    @Override
    public String getAddress() { return deliveryAddress; }

    @Override
    public void setAddress(String address) { this.deliveryAddress = address; }

    // Getters and Setters
    public String getId() { return id; }
    public void setId(String id) { this.id = id; }
    public String getUserId() { return userId; }
    public void setUserId(String userId) { this.userId = userId; }
    public String getFullName() { return fullName; }
    public void setFullName(String fullName) { this.fullName = fullName; }
    public String getJobTitle() { return jobTitle; }
    public void setJobTitle(String jobTitle) { this.jobTitle = jobTitle; }
    public String getCompanyName() { return companyName; }
    public void setCompanyName(String companyName) { this.companyName = companyName; }
    public String getPhoneNumber() { return phoneNumber; }
    public void setPhoneNumber(String phoneNumber) { this.phoneNumber = phoneNumber; }
    public String getEmailAddress() { return emailAddress; }
    public void setEmailAddress(String emailAddress) { this.emailAddress = emailAddress; }
    public String getWebsite() { return website; }
    public void setWebsite(String website) { this.website = website; }
    public String getOfficeAddress() { return officeAddress; }
    public void setOfficeAddress(String officeAddress) { this.officeAddress = officeAddress; }
    public String getSideOption() { return sideOption; }
    public void setSideOption(String sideOption) { this.sideOption = sideOption; }
    public String getTextAlignment() { return textAlignment; }
    public void setTextAlignment(String textAlignment) { this.textAlignment = textAlignment; }
    public boolean isQrCode() { return qrCode; }
    public void setQrCode(boolean qrCode) { this.qrCode = qrCode; }
    public String getCompanyLogo() { return companyLogo; }
    public void setCompanyLogo(String companyLogo) { this.companyLogo = companyLogo; }
    public String getProfilePhoto() { return profilePhoto; }
    public void setProfilePhoto(String profilePhoto) { this.profilePhoto = profilePhoto; }
    public String getColorTheme() { return colorTheme; }
    public void setColorTheme(String colorTheme) { this.colorTheme = colorTheme; }
    public String getFontStyle() { return fontStyle; }
    public void setFontStyle(String fontStyle) { this.fontStyle = fontStyle; }
    public String getDesignStyle() { return designStyle; }
    public void setDesignStyle(String designStyle) { this.designStyle = designStyle; }
    public String getCardSize() { return cardSize; }
    public void setCardSize(String cardSize) { this.cardSize = cardSize; }
    public String getCardShape() { return cardShape; }
    public void setCardShape(String cardShape) { this.cardShape = cardShape; }
    public String getPaperType() { return paperType; }
    public void setPaperType(String paperType) { this.paperType = paperType; }
    public String getSpecialFinish() { return specialFinish; }
    public void setSpecialFinish(String specialFinish) { this.specialFinish = specialFinish; }
    public String getQuantity() { return quantity; }
    public void setQuantity(String quantity) { this.quantity = quantity; }
    public String getDeliveryType() { return deliveryType; }
    public void setDeliveryType(String deliveryType) { this.deliveryType = deliveryType; }
    public String getDeliveryAddress() { return deliveryAddress; }
    public void setDeliveryAddress(String deliveryAddress) { this.deliveryAddress = deliveryAddress; }
    public String getDeadlineDate() { return deadlineDate; }
    public void setDeadlineDate(String deadlineDate) { this.deadlineDate = deadlineDate; }
    public boolean isUrgent() { return urgent; }
    public void setUrgent(boolean urgent) { this.urgent = urgent; }
    public String getLinkedIn() { return linkedIn; }
    public void setLinkedIn(String linkedIn) { this.linkedIn = linkedIn; }
    public String getFacebook() { return facebook; }
    public void setFacebook(String facebook) { this.facebook = facebook; }
    public String getInstagram() { return instagram; }
    public void setInstagram(String instagram) { this.instagram = instagram; }
    public String getSpecialInstructions() { return specialInstructions; }
    public void setSpecialInstructions(String specialInstructions) { this.specialInstructions = specialInstructions; }
    public long getTimestamp() { return timestamp; }
    public void setTimestamp(long timestamp) { this.timestamp = timestamp; }
    public double getTotalPrice() { return totalPrice; }
    public void setTotalPrice(double totalPrice) { this.totalPrice = totalPrice; }
    public String getStatus() { return status; }
    public void setStatus(String status) { this.status = status; }
}
