package com.example.printxpress.Activity;

import android.content.Intent;
import android.os.Bundle;
import android.widget.ImageView;
import androidx.appcompat.app.AppCompatActivity;
import com.example.printxpress.R;
import com.google.android.material.card.MaterialCardView;

public class CustomizedSelectionActivity extends AppCompatActivity {

    private MaterialCardView cardTshirt, cardMug, cardCap, cardFrame, cardKeychain;
    private ImageView ivBack;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_customized_selection);

        initViews();
        setupListeners();
    }

    private void initViews() {
        ivBack = findViewById(R.id.ivBack);
        cardTshirt = findViewById(R.id.cardTshirt);
        cardMug = findViewById(R.id.cardMug);
        cardCap = findViewById(R.id.cardCap);
        cardFrame = findViewById(R.id.cardFrame);
        cardKeychain = findViewById(R.id.cardKeychain);
    }

    private void setupListeners() {
        ivBack.setOnClickListener(v -> finish());

        cardTshirt.setOnClickListener(v -> {
            Intent intent = new Intent(CustomizedSelectionActivity.this, TshirtOrderActivity.class);
            startActivity(intent);
        });

        cardMug.setOnClickListener(v -> {
            Intent intent = new Intent(CustomizedSelectionActivity.this, MugOrderActivity.class);
            startActivity(intent);
        });

        cardCap.setOnClickListener(v -> {
            Intent intent = new Intent(CustomizedSelectionActivity.this, CapOrderActivity.class);
            startActivity(intent);
        });

        cardFrame.setOnClickListener(v -> {
            Intent intent = new Intent(CustomizedSelectionActivity.this, FrameOrderActivity.class);
            startActivity(intent);
        });

        cardKeychain.setOnClickListener(v -> {
            Intent intent = new Intent(CustomizedSelectionActivity.this, KeychainOrderActivity.class);
            startActivity(intent);
        });
    }
}
