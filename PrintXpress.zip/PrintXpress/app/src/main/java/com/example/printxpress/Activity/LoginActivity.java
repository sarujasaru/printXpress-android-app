package com.example.printxpress.Activity;

import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

import com.example.printxpress.Firebase.FirebaseHelper;
import com.example.printxpress.R;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.Query;
import com.google.firebase.database.ValueEventListener;

public class LoginActivity extends AppCompatActivity {

    private static final String TAG = "LoginActivity";
    private EditText etLoginUser, etLoginPassword;
    private Button btnLogin;
    private FirebaseHelper firebaseHelper;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);
        
        View mainView = findViewById(R.id.main);
        if (mainView != null) {
            ViewCompat.setOnApplyWindowInsetsListener(mainView, (v, insets) -> {
                Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
                v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
                return insets;
            });
        }

        firebaseHelper = new FirebaseHelper();
        etLoginUser = findViewById(R.id.etLoginUser);
        etLoginPassword = findViewById(R.id.etLoginPassword);
        btnLogin = findViewById(R.id.login);

        btnLogin.setOnClickListener(v -> {
            String input = etLoginUser.getText().toString().trim();
            String password = etLoginPassword.getText().toString().trim();

            if (input.isEmpty() || password.isEmpty()) {
                Toast.makeText(this, "Please enter all fields", Toast.LENGTH_SHORT).show();
                return;
            }

            // Email-il @ symbol இருக்கும் என்பதால் அதை வைத்து கண்டுபிடிக்கலாம்
            if (input.contains("@")) {
                loginWithEmail(input, password);
            } else {
                loginWithPhone(input, password);
            }
        });

        TextView tvSignUpLink = findViewById(R.id.tvSignUpLink);
        tvSignUpLink.setOnClickListener(v -> startActivity(new Intent(this, RegisterActivity.class)));

        TextView tvForgotPassword = findViewById(R.id.tvForgotPassword);
        if (tvForgotPassword != null) {
            tvForgotPassword.setOnClickListener(v -> startActivity(new Intent(this, ForgotPasswordActivity.class)));
        }
    }

    private void loginWithEmail(String email, String password) {
        firebaseHelper.loginUser(email, password).addOnCompleteListener(task -> {
            if (task.isSuccessful()) {
                saveSessionAndGoMain();
            } else {
                String error = task.getException() != null ? task.getException().getMessage() : "Unknown error";
                Log.e(TAG, "Login Failed: " + error);
                Toast.makeText(this, "Login Failed: " + error, Toast.LENGTH_SHORT).show();
            }
        });
    }

    private void loginWithPhone(String phone, String password) {
        // Database-il 'phoneno' என்ற பெயரில் சேமிக்கப்பட்டுள்ளதால் அதையே தேடுகிறோம்
        Query query = firebaseHelper.getUsersRootReference().orderByChild("phoneno").equalTo(phone);

        query.addListenerForSingleValueEvent(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot snapshot) {
                if (snapshot.exists()) {
                    boolean userFound = false;
                    for (DataSnapshot ds : snapshot.getChildren()) {
                        String email = ds.child("email").getValue(String.class);
                        if (email != null) {
                            userFound = true;
                            // Phone number-க்குரிய Email-ஐ கண்டுபிடித்து அதன் மூலம் Login செய்கிறோம்
                            loginWithEmail(email, password);
                            return;
                        }
                    }
                    if (!userFound) {
                        Toast.makeText(LoginActivity.this, "Email mapping not found", Toast.LENGTH_SHORT).show();
                    }
                } else {
                    Toast.makeText(LoginActivity.this, "Phone number not registered", Toast.LENGTH_SHORT).show();
                }
            }

            @Override
            public void onCancelled(@NonNull DatabaseError error) {
                // இங்கே வரும் error-ஐ கவனித்து Firebase Rules-ஐ சரிசெய்யவும்
                Log.e(TAG, "Database Error: " + error.getMessage());
                Toast.makeText(LoginActivity.this, "Database Error: " + error.getMessage(), Toast.LENGTH_LONG).show();
            }
        });
    }

    private void saveSessionAndGoMain() {
        SharedPreferences.Editor editor = getSharedPreferences("UserPrefs", MODE_PRIVATE).edit();
        editor.putBoolean("isLoggedIn", true);
        editor.apply();
        startActivity(new Intent(LoginActivity.this, Dashboard.class));
        finish();
    }
}
