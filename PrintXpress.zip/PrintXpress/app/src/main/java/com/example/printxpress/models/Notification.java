package com.example.printxpress.models;

import com.google.firebase.database.PropertyName;

public class Notification {
    private String id;
    private String title;
    private String message;
    private long timestamp;
    private String type; // e.g., "ORDER", "OFFER", "ADMIN"
    private String uid; // Changed from userId to uid to match Firebase screenshot
    private boolean read;

    public Notification() {
        // Default constructor for Firebase
    }

    public Notification(String id, String title, String message, long timestamp, String type, String uid) {
        this.id = id;
        this.title = title;
        this.message = message;
        this.timestamp = timestamp;
        this.type = type;
        this.uid = uid;
        this.read = false;
    }

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public String getMessage() {
        return message;
    }

    public void setMessage(String message) {
        this.message = message;
    }

    public long getTimestamp() {
        return timestamp;
    }

    public void setTimestamp(long timestamp) {
        this.timestamp = timestamp;
    }

    public String getType() {
        return type;
    }

    public void setType(String type) {
        this.type = type;
    }

    public String getUid() {
        return uid;
    }

    public void setUid(String uid) {
        this.uid = uid;
    }

    @PropertyName("read")
    public boolean isRead() {
        return read;
    }

    @PropertyName("read")
    public void setRead(boolean read) {
        this.read = read;
    }
}
