package com.example.printxpress.models;

public class MugOrder implements BaseOrder {
    private String orderId;
    private String userId;
    private String product;
    private int quantity;
    private String usage;
    private String mugType;
    private String mugSize;
    private String mugColor;
    private String printText;
    private String designStyle;
    private String placement;
    private String printType;
    private String backgroundColor;
    private String packaging;
    private String deliveryType;
    private String address;
    private String deadline;
    private boolean isUrgent;
    private String specialInstructions;
    private String status;
    private long timestamp;
    private String designUrl;
    private double totalPrice;

    public MugOrder() {
        // Required for Firebase
    }

    public MugOrder(String orderId, String userId, String product, int quantity, String usage, String mugType, String mugSize, String mugColor, String printText, String designStyle, String placement, String printType, String backgroundColor, String packaging, String deliveryType, String address, String deadline, boolean isUrgent, String specialInstructions, String status, long timestamp) {
        this.orderId = orderId;
        this.userId = userId;
        this.product = product;
        this.quantity = quantity;
        this.usage = usage;
        this.mugType = mugType;
        this.mugSize = mugSize;
        this.mugColor = mugColor;
        this.printText = printText;
        this.designStyle = designStyle;
        this.placement = placement;
        this.printType = printType;
        this.backgroundColor = backgroundColor;
        this.packaging = packaging;
        this.deliveryType = deliveryType;
        this.address = address;
        this.deadline = deadline;
        this.isUrgent = isUrgent;
        this.specialInstructions = specialInstructions;
        this.status = status;
        this.timestamp = timestamp;
    }

    @Override
    public String getProductType() { return "Mug"; }

    @Override
    public String getOrderSummary() {
        return "Type: " + mugType + " | Size: " + mugSize + " | Qty: " + quantity;
    }

    @Override
    public String getPhotoUrl() { return designUrl; }

    @Override
    public String getBase64Image() { return null; }

    // Getters and Setters
    public String getOrderId() { return orderId; }
    public void setOrderId(String orderId) { this.orderId = orderId; }
    public String getUserId() { return userId; }
    public void setUserId(String userId) { this.userId = userId; }
    public String getProduct() { return product; }
    public void setProduct(String product) { this.product = product; }
    public int getQuantity() { return quantity; }
    public void setQuantity(int quantity) { this.quantity = quantity; }
    public String getUsage() { return usage; }
    public void setUsage(String usage) { this.usage = usage; }
    public String getMugType() { return mugType; }
    public void setMugType(String mugType) { this.mugType = mugType; }
    public String getMugSize() { return mugSize; }
    public void setMugSize(String mugSize) { this.mugSize = mugSize; }
    public String getMugColor() { return mugColor; }
    public void setMugColor(String mugColor) { this.mugColor = mugColor; }
    public String getPrintText() { return printText; }
    public void setPrintText(String printText) { this.printText = printText; }
    public String getDesignStyle() { return designStyle; }
    public void setDesignStyle(String designStyle) { this.designStyle = designStyle; }
    public String getPlacement() { return placement; }
    public void setPlacement(String placement) { this.placement = placement; }
    public String getPrintType() { return printType; }
    public void setPrintType(String printType) { this.printType = printType; }
    public String getBackgroundColor() { return backgroundColor; }
    public void setBackgroundColor(String backgroundColor) { this.backgroundColor = backgroundColor; }
    public String getPackaging() { return packaging; }
    public void setPackaging(String packaging) { this.packaging = packaging; }
    public String getDeliveryType() { return deliveryType; }
    public void setDeliveryType(String deliveryType) { this.deliveryType = deliveryType; }
    public String getAddress() { return address; }
    public void setAddress(String address) { this.address = address; }
    public String getDeadline() { return deadline; }
    public void setDeadline(String deadline) { this.deadline = deadline; }
    public boolean isUrgent() { return isUrgent; }
    public void setUrgent(boolean urgent) { isUrgent = urgent; }
    public String getSpecialInstructions() { return specialInstructions; }
    public void setSpecialInstructions(String specialInstructions) { this.specialInstructions = specialInstructions; }
    public String getStatus() { return status; }
    public void setStatus(String status) { this.status = status; }
    public long getTimestamp() { return timestamp; }
    public void setTimestamp(long timestamp) { this.timestamp = timestamp; }
    public String getDesignUrl() { return designUrl; }
    public void setDesignUrl(String designUrl) { this.designUrl = designUrl; }
    public double getTotalPrice() { return totalPrice; }
    public void setTotalPrice(double totalPrice) { this.totalPrice = totalPrice; }
}
