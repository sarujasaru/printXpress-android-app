package com.example.printxpress.models;

import java.util.List;

public class CapOrder implements BaseOrder {
    private String orderId;
    private String userId;
    private String product;
    private int quantity;
    private String usage;
    private String capType;
    private String capSize;
    private String capColor;
    private String printText;
    private String printType;
    private List<String> placement;
    private String designSize;
    private String styleOption;
    private String closureType;
    private String packaging;
    private String deliveryType;
    private String address;
    private String deadline;
    private boolean isUrgent;
    private String specialInstructions;
    private String status;
    private long timestamp;
    private String logoUrl;
    private double totalPrice;

    public CapOrder() {
        // Required for Firebase
    }

    public CapOrder(String orderId, String userId, String product, int quantity, String usage, String capType, String capSize, String capColor, String printText, String printType, List<String> placement, String designSize, String styleOption, String closureType, String packaging, String deliveryType, String address, String deadline, boolean isUrgent, String specialInstructions, String status, long timestamp) {
        this.orderId = orderId;
        this.userId = userId;
        this.product = product;
        this.quantity = quantity;
        this.usage = usage;
        this.capType = capType;
        this.capSize = capSize;
        this.capColor = capColor;
        this.printText = printText;
        this.printType = printType;
        this.placement = placement;
        this.designSize = designSize;
        this.styleOption = styleOption;
        this.closureType = closureType;
        this.packaging = packaging;
        this.deliveryType = deliveryType;
        this.address = address;
        this.deadline = deadline;
        this.isUrgent = isUrgent;
        this.specialInstructions = specialInstructions;
        this.status = status;
        this.timestamp = timestamp;
    }

    @Override
    public String getProductType() { return "Cap"; }

    @Override
    public String getOrderSummary() {
        return "Type: " + capType + " | Qty: " + quantity;
    }

    @Override
    public String getPhotoUrl() { return logoUrl; }

    @Override
    public String getBase64Image() { return null; }

    // Getters and Setters
    public String getOrderId() { return orderId; }
    public void setOrderId(String orderId) { this.orderId = orderId; }

    public String getUserId() { return userId; }
    public void setUserId(String userId) { this.userId = userId; }

    public String getProduct() { return product; }
    public void setProduct(String product) { this.product = product; }

    public int getQuantity() { return quantity; }
    public void setQuantity(int quantity) { this.quantity = quantity; }

    public String getUsage() { return usage; }
    public void setUsage(String usage) { this.usage = usage; }

    public String getCapType() { return capType; }
    public void setCapType(String capType) { this.capType = capType; }

    public String getCapSize() { return capSize; }
    public void setCapSize(String capSize) { this.capSize = capSize; }

    public String getCapColor() { return capColor; }
    public void setCapColor(String capColor) { this.capColor = capColor; }

    public String getPrintText() { return printText; }
    public void setPrintText(String printText) { this.printText = printText; }

    public String getPrintType() { return printType; }
    public void setPrintType(String printType) { this.printType = printType; }

    public List<String> getPlacement() { return placement; }
    public void setPlacement(List<String> placement) { this.placement = placement; }

    public String getDesignSize() { return designSize; }
    public void setDesignSize(String designSize) { this.designSize = designSize; }

    public String getStyleOption() { return styleOption; }
    public void setStyleOption(String styleOption) { this.styleOption = styleOption; }

    public String getClosureType() { return closureType; }
    public void setClosureType(String closureType) { this.closureType = closureType; }

    public String getPackaging() { return packaging; }
    public void setPackaging(String packaging) { this.packaging = packaging; }

    public String getDeliveryType() { return deliveryType; }
    public void setDeliveryType(String deliveryType) { this.deliveryType = deliveryType; }

    public String getAddress() { return address; }
    public void setAddress(String address) { this.address = address; }

    public String getDeadline() { return deadline; }
    public void setDeadline(String deadline) { this.deadline = deadline; }

    public boolean isUrgent() { return isUrgent; }
    public void setUrgent(boolean urgent) { isUrgent = urgent; }

    public String getSpecialInstructions() { return specialInstructions; }
    public void setSpecialInstructions(String specialInstructions) { this.specialInstructions = specialInstructions; }

    public String getStatus() { return status; }
    public void setStatus(String status) { this.status = status; }

    public long getTimestamp() { return timestamp; }
    public void setTimestamp(long timestamp) { this.timestamp = timestamp; }

    public String getLogoUrl() { return logoUrl; }
    public void setLogoUrl(String logoUrl) { this.logoUrl = logoUrl; }
    public double getTotalPrice() { return totalPrice; }
    public void setTotalPrice(double totalPrice) { this.totalPrice = totalPrice; }
}
