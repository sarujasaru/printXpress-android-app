package com.example.printxpress.Adapter;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.LinearLayout;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.example.printxpress.R;
import com.example.printxpress.models.Comment;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;
import java.util.Locale;

public class CommentAdapter extends RecyclerView.Adapter<CommentAdapter.CommentViewHolder> {

    private List<Comment> commentList;
    private OnCommentClickListener listener;

    public interface OnCommentClickListener {
        void onCommentClick(Comment comment);
    }

    public CommentAdapter(List<Comment> commentList) {
        this.commentList = commentList;
    }

    public CommentAdapter(List<Comment> commentList, OnCommentClickListener listener) {
        this.commentList = commentList;
        this.listener = listener;
    }

    @NonNull
    @Override
    public CommentViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.item_comment, parent, false);
        return new CommentViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull CommentViewHolder holder, int position) {
        Comment comment = commentList.get(position);
        holder.tvCommentUser.setText(comment.getUserName());
        holder.tvCommentText.setText(comment.getCommentText());

        // Display Date and Time for User Comment
        SimpleDateFormat sdf = new SimpleDateFormat("dd/MM/yyyy hh:mm a", Locale.getDefault());
        String timeStr = sdf.format(new Date(comment.getTimestamp()));
        holder.tvCommentTime.setText(timeStr);

        // Handle Admin Reply
        if (comment.getAdminReply() != null && !comment.getAdminReply().isEmpty()) {
            holder.layoutAdminReply.setVisibility(View.VISIBLE);
            holder.tvAdminReplyText.setText(comment.getAdminReply());
            
            // Display Date and Time for Admin Reply
            String replyTimeStr = sdf.format(new Date(comment.getReplyTimestamp()));
            holder.tvReplyTime.setText(replyTimeStr);
        } else {
            holder.layoutAdminReply.setVisibility(View.GONE);
        }

        holder.itemView.setOnClickListener(v -> {
            if (listener != null) {
                listener.onCommentClick(comment);
            }
        });
    }

    @Override
    public int getItemCount() {
        return commentList.size();
    }

    public static class CommentViewHolder extends RecyclerView.ViewHolder {
        TextView tvCommentUser, tvCommentText, tvCommentTime;
        LinearLayout layoutAdminReply;
        TextView tvAdminReplyText, tvReplyTime;

        public CommentViewHolder(@NonNull View itemView) {
            super(itemView);
            tvCommentUser = itemView.findViewById(R.id.tvCommentUser);
            tvCommentText = itemView.findViewById(R.id.tvCommentText);
            tvCommentTime = itemView.findViewById(R.id.tvCommentTime);
            layoutAdminReply = itemView.findViewById(R.id.layoutAdminReply);
            tvAdminReplyText = itemView.findViewById(R.id.tvAdminReplyText);
            tvReplyTime = itemView.findViewById(R.id.tvReplyTime);
        }
    }
}
