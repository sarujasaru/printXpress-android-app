package com.example.printxpress.models;

public class PosterOrder implements BaseOrder {
    private String orderId;
    private String userId;
    
    // 1. Basic Details
    private String title;
    private String purpose;

    // 2. Size & Format
    private String size;
    private String orientation;
    private String printType;

    // 3. Content Details
    private String mainText;
    private String subText;
    private String date;
    private String time;
    private String location;
    private String contactNumber;
    private String socialMediaLinks;

    // 4. Image / Logo (URLs/Paths)
    private String companyLogo;
    private String customImages;
    private String backgroundImage;

    // 5. Design Preferences
    private String colorTheme;
    private String fontStyle;
    private String exampleDesign;
    private String language;

    // 6. Quantity & Delivery
    private String quantity;
    private String deliveryType;
    private String deliveryAddress;

    // 7. Deadline
    private String deadlineDate;
    private boolean urgent;
    private String specialInstructions;
    
    private long timestamp;
    private double totalPrice;
    private String status;

    public PosterOrder() {
    }

    public PosterOrder(String orderId, String userId, String title, String purpose, String size, String orientation, String printType, String mainText, String subText, String date, String time, String location, String contactNumber, String socialMediaLinks, String companyLogo, String customImages, String backgroundImage, String colorTheme, String fontStyle, String exampleDesign, String language, String quantity, String deliveryType, String deliveryAddress, String deadlineDate, boolean urgent, String specialInstructions, long timestamp, double totalPrice, String status) {
        this.orderId = orderId;
        this.userId = userId;
        this.title = title;
        this.purpose = purpose;
        this.size = size;
        this.orientation = orientation;
        this.printType = printType;
        this.mainText = mainText;
        this.subText = subText;
        this.date = date;
        this.time = time;
        this.location = location;
        this.contactNumber = contactNumber;
        this.socialMediaLinks = socialMediaLinks;
        this.companyLogo = companyLogo;
        this.customImages = customImages;
        this.backgroundImage = backgroundImage;
        this.colorTheme = colorTheme;
        this.fontStyle = fontStyle;
        this.exampleDesign = exampleDesign;
        this.language = language;
        this.quantity = quantity;
        this.deliveryType = deliveryType;
        this.deliveryAddress = deliveryAddress;
        this.deadlineDate = deadlineDate;
        this.urgent = urgent;
        this.specialInstructions = specialInstructions;
        this.timestamp = timestamp;
        this.totalPrice = totalPrice;
        this.status = status;
    }

    @Override
    public String getProductType() { return "Poster: " + title; }

    @Override
    public String getOrderSummary() {
        return "Size: " + size + " | Qty: " + quantity;
    }

    @Override
    public String getPhotoUrl() { return null; }

    @Override
    public String getBase64Image() {
        if (customImages != null && !customImages.isEmpty()) return customImages;
        if (companyLogo != null && !companyLogo.isEmpty()) return companyLogo;
        return null;
    }

    @Override
    public String getAddress() { return deliveryAddress; }

    @Override
    public void setAddress(String address) { this.deliveryAddress = address; }

    // Getters and Setters
    public String getOrderId() { return orderId; }
    public void setOrderId(String orderId) { this.orderId = orderId; }
    public String getUserId() { return userId; }
    public void setUserId(String userId) { this.userId = userId; }
    public String getTitle() { return title; }
    public void setTitle(String title) { this.title = title; }
    public String getPurpose() { return purpose; }
    public void setPurpose(String purpose) { this.purpose = purpose; }
    public String getSize() { return size; }
    public void setSize(String size) { this.size = size; }
    public String getOrientation() { return orientation; }
    public void setOrientation(String orientation) { this.orientation = orientation; }
    public String getPrintType() { return printType; }
    public void setPrintType(String printType) { this.printType = printType; }
    public String getMainText() { return mainText; }
    public void setMainText(String mainText) { this.mainText = mainText; }
    public String getSubText() { return subText; }
    public void setSubText(String subText) { this.subText = subText; }
    public String getDate() { return date; }
    public void setDate(String date) { this.date = date; }
    public String getTime() { return time; }
    public void setTime(String time) { this.time = time; }
    public String getLocation() { return location; }
    public void setLocation(String location) { this.location = location; }
    public String getContactNumber() { return contactNumber; }
    public void setContactNumber(String contactNumber) { this.contactNumber = contactNumber; }
    public String getSocialMediaLinks() { return socialMediaLinks; }
    public void setSocialMediaLinks(String socialMediaLinks) { this.socialMediaLinks = socialMediaLinks; }
    public String getCompanyLogo() { return companyLogo; }
    public void setCompanyLogo(String companyLogo) { this.companyLogo = companyLogo; }
    public String getCustomImages() { return customImages; }
    public void setCustomImages(String customImages) { this.customImages = customImages; }
    public String getBackgroundImage() { return backgroundImage; }
    public void setBackgroundImage(String backgroundImage) { this.backgroundImage = backgroundImage; }
    public String getColorTheme() { return colorTheme; }
    public void setColorTheme(String colorTheme) { this.colorTheme = colorTheme; }
    public String getFontStyle() { return fontStyle; }
    public void setFontStyle(String fontStyle) { this.fontStyle = fontStyle; }
    public String getExampleDesign() { return exampleDesign; }
    public void setExampleDesign(String exampleDesign) { this.exampleDesign = exampleDesign; }
    public String getLanguage() { return language; }
    public void setLanguage(String language) { this.language = language; }
    public String getQuantity() { return quantity; }
    public void setQuantity(String quantity) { this.quantity = quantity; }
    public String getDeliveryType() { return deliveryType; }
    public void setDeliveryType(String deliveryType) { this.deliveryType = deliveryType; }
    public String getDeliveryAddress() { return deliveryAddress; }
    public void setDeliveryAddress(String deliveryAddress) { this.deliveryAddress = deliveryAddress; }
    public String getDeadlineDate() { return deadlineDate; }
    public void setDeadlineDate(String deadlineDate) { this.deadlineDate = deadlineDate; }
    public boolean isUrgent() { return urgent; }
    public void setUrgent(boolean urgent) { this.urgent = urgent; }
    public String getSpecialInstructions() { return specialInstructions; }
    public void setSpecialInstructions(String specialInstructions) { this.specialInstructions = specialInstructions; }
    public long getTimestamp() { return timestamp; }
    public void setTimestamp(long timestamp) { this.timestamp = timestamp; }
    public double getTotalPrice() { return totalPrice; }
    public void setTotalPrice(double totalPrice) { this.totalPrice = totalPrice; }
    public String getStatus() { return status; }
    public void setStatus(String status) { this.status = status; }
}
