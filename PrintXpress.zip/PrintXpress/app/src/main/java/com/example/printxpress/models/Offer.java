package com.example.printxpress.models;

public class Offer {
    private String imageUrl;

    public Offer() {
        // Required for Firebase
    }

    public Offer(String imageUrl) {
        this.imageUrl = imageUrl;
    }

    public String getImageUrl() {
        return imageUrl;
    }

    public void setImageUrl(String imageUrl) {
        this.imageUrl = imageUrl;
    }
}
