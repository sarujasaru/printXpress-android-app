package com.example.printxpress.models;

import com.google.firebase.database.IgnoreExtraProperties;

@IgnoreExtraProperties
public class Order {
    private String orderId;
    private String id;
    private String productName;
    private String productType;
    private String product; // For T-Shirt orders
    private String title; // For Banners/Posters
    private String fullName; // For Business Cards
    private Object quantity;
    private int totalQty; // For T-Shirts
    private double totalPrice;
    private String orderDate;
    private long timestamp;
    private String userId;
    private String status;
    private String address;
    private String deliveryAddress;

    // Summary fields
    private String size;
    private String materialType;
    private String frameSize;
    private String frameType;
    private String cardSize;
    private String orderSummary;
    private String tshirtSize;

    public Order() {}

    public String getDisplayName() {
        if (title != null && !title.isEmpty()) return "Banner: " + title;
        if (productName != null && !productName.isEmpty()) return productName;
        if (product != null && !product.isEmpty()) return product;
        if (productType != null && !productType.isEmpty()) return productType;
        if (fullName != null && !fullName.isEmpty()) return "Business Card: " + fullName;
        return "Printing Order";
    }

    public String getDisplaySummary() {
        if (orderSummary != null && !orderSummary.isEmpty()) return orderSummary;
        StringBuilder sb = new StringBuilder();
        if (size != null) sb.append("Size: ").append(size).append(" | ");
        if (tshirtSize != null) sb.append("Size: ").append(tshirtSize).append(" | ");
        if (frameSize != null) sb.append("Size: ").append(frameSize).append(" | ");
        if (materialType != null) sb.append("Material: ").append(materialType).append(" | ");
        
        String res = sb.toString();
        return res.endsWith(" | ") ? res.substring(0, res.length() - 3) : "Detailed printing request";
    }

    public String getDisplayQuantity() {
        if (totalQty > 0) return String.valueOf(totalQty);
        return quantity != null ? String.valueOf(quantity) : "1";
    }

    public String getDisplayAddress() {
        if (deliveryAddress != null && !deliveryAddress.isEmpty()) return deliveryAddress;
        if (address != null && !address.isEmpty()) return address;
        return "N/A";
    }

    // Getters and Setters
    public String getOrderId() { return orderId != null ? orderId : id; }
    public void setOrderId(String orderId) { this.orderId = orderId; }
    public String getId() { return id; }
    public void setId(String id) { this.id = id; }
    public String getProductName() { return productName; }
    public void setProductName(String productName) { this.productName = productName; }
    public String getProductType() { return productType; }
    public void setProductType(String productType) { this.productType = productType; }
    public String getProduct() { return product; }
    public void setProduct(String product) { this.product = product; }
    public String getTitle() { return title; }
    public void setTitle(String title) { this.title = title; }
    public String getFullName() { return fullName; }
    public void setFullName(String fullName) { this.fullName = fullName; }
    public Object getQuantity() { return quantity; }
    public void setQuantity(Object quantity) { this.quantity = quantity; }
    public int getTotalQty() { return totalQty; }
    public void setTotalQty(int totalQty) { this.totalQty = totalQty; }
    public double getTotalPrice() { return totalPrice; }
    public void setTotalPrice(double totalPrice) { this.totalPrice = totalPrice; }
    public String getOrderDate() { return orderDate; }
    public void setOrderDate(String orderDate) { this.orderDate = orderDate; }
    public long getTimestamp() { return timestamp; }
    public void setTimestamp(long timestamp) { this.timestamp = timestamp; }
    public String getUserId() { return userId; }
    public void setUserId(String userId) { this.userId = userId; }
    public String getStatus() { return status; }
    public void setStatus(String status) { this.status = status; }
    public String getAddress() { return address; }
    public void setAddress(String address) { this.address = address; }
    public String getDeliveryAddress() { return deliveryAddress; }
    public void setDeliveryAddress(String deliveryAddress) { this.deliveryAddress = deliveryAddress; }
    public String getSize() { return size; }
    public void setSize(String size) { this.size = size; }
    public String getMaterialType() { return materialType; }
    public void setMaterialType(String materialType) { this.materialType = materialType; }
    public String getFrameSize() { return frameSize; }
    public void setFrameSize(String frameSize) { this.frameSize = frameSize; }
    public String getFrameType() { return frameType; }
    public void setFrameType(String frameType) { this.frameType = frameType; }
    public String getCardSize() { return cardSize; }
    public void setCardSize(String cardSize) { this.cardSize = cardSize; }
    public String getOrderSummary() { return orderSummary; }
    public void setOrderSummary(String orderSummary) { this.orderSummary = orderSummary; }
    public String getTshirtSize() { return tshirtSize; }
    public void setTshirtSize(String tshirtSize) { this.tshirtSize = tshirtSize; }
}
